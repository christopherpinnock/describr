<?php
$htmlform_avatar_key = $plugin . '_avatar';

if ( ! empty( $_FILES[ $htmlform_avatar_key ]['name'] ) && current_user_can( 'upload_files' ) ) {            
    $file     = $_FILES[ $htmlform_avatar_key ];
    $filename = $file['name'];

    if ( $this->is_image( $filename ) ) {
        //Support for files being uploaded from front-end
        if ( ! function_exists( 'media_handle_upload' ) ) {
            require_once ( ABSPATH . 'wp-admin/includes/media.php' );
        }

        //Override default maximum upload file size if necessary
        add_filter( 'upload_size_limit', array( $this, 'upload_size_limit' ) );
                
        $this->upload_avatar_user_id = $user_id; 
        
        //Avatar uploaded by WordPress' "media_handle_upload" function.
        $avatar_id = media_handle_upload(
            $htmlform_avatar_key,
            0,
            array(),
            array(
            'mimes' => array(
                'jpg|jpeg|jpe' => 'image/jpeg',
                'gif'          => 'image/gif',
                'png'          => 'image/png',
            ),
            'test_form'                => false,
            'unique_filename_callback' => array( $this, 'unique_filename_callback' ),
            'upload_error_strings'     => $this->upload_error_strings(),
            )
        );//"media_handle_upload" function ends here.
                
        //Remove the plugin's image-sized filter
        remove_filter( 'upload_size_limit', array( $this, 'upload_size_limit' ) );
                
        //Alerts user of errors if any.
        if ( is_wp_error( $avatar_id ) ) {
            $this->profile_update_errors['avatar_errors'] = $avatar_id->get_error_message();
        } else{
            //Assigns uploaded avatar to user in database.
            $this->assign_avatar( $avatar_id, $user_id );
        }
    } else {
        $this->profile_update_errors['avatar_errors'] = $this->unsupported_imagefile_message( $filename );
    }
}//if ( ! empty( $_FILES[ $htmlform_avatar_key ]['name'] ) && current_user_can( 'upload_files' ) )


