<?php
class DESCRIBR {
    /**
	 * Plugin's name, capitalized
     *
	 * @var string
	 */
	private $plugin_name;

	/**
     * Plugin's root url
     *
     * @var string
     */
    private $plugin_url;
    
    /**
     * Stores errors that may arise while updating user profile
     *
     * @var array
     */
    private $profile_update_errors = array();
    
    /**
     * Stores avatar permissions
     *
     * @var array
     */
    private $avatar_permissions;

    /**
     * User ID to whom the uploaded avatar belongs
     *
     * @var int
     */
    private $upload_avatar_user_id;

    /**
     * Default avatar
     *
     * @var string
     */
    private $default_avatar;
    
    /**
     * Commonly used array keys used to save data in the database
     * 
     * @var array
     */
    private $array_keys = array( 
        'media_id', 
        'approved', 
        'visibility', 
        'full', 
        'updated_by',
    );
    
    /**
     * User input integers
     * 
     * @var array
     */
    private $user_int = array( 
        1, 
        0, 
    );

	public function __construct() {
        $this->default_avatar     = $this->get_default_avatar();
        $this->avatar_permissions = ( array ) get_option( 'describr_avatars' );
		$this->plugin_name        = 'Describr';
		$this->plugin_url         = plugin_dir_url( __FILE__ );
                
        $this->add_hooks();
	}

    /**
     * Adds callback functions to action hooks
     */
    private function add_hooks () {
        add_action( 'user_register', array( $this, 'user_register'), 10, 2 );
        add_action( 'delete_user', array( $this, 'delete_user' ), 10, 1 );

        add_action( 'init', array( $this, 'load_textdomain' ) );
        add_action( 'admin_init', array( $this, 'admin_init' ) );
        
        add_action( 'admin_notices', array( $this, 'admin_notices' ) );

        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts') );
        
        add_action( 'wp_ajax_describr-remove-avatar', array( $this, 'action_remove_avatar' ) );
        add_action( 'wp_ajax_describr-assign-avatar', array( $this, 'action_assign_avatar' ) );

        add_action( 'rest_api_init', array( $this, 'rest_api_init' ) );
        
        add_action( 'show_user_profile', array( $this, 'show_user_profile' ), 10, 1 );
        add_action( 'edit_user_profile', array( $this, 'show_user_profile' ), 10, 1 );
        
        add_action( 'personal_options_update', array( $this, 'edit_user_profile' ), 10, 1 );
        add_action( 'edit_user_profile_update', array( $this, 'edit_user_profile' ), 10, 1 );
        add_action( 'user_profile_update_errors', array( $this, 'user_profile_update_errors' ), 10, 1 );
        
        add_action( 'wp_login', array( $this, 'logged_in' ), 101, 2 );
        
        add_action( 'user_edit_form_tag', array( $this, 'user_avatar_edit_form_tag' ) );

        add_filter( 'bulk_actions-users', array( $this, 'bulk_actions' ), 10, 1 );
        add_filter( 'handle_bulk_actions-users', array( $this, 'bulk_actions_handler' ), 10, 3 );
        
        add_filter( 'manage_users_columns', array( $this, 'customize_user_columns'), 10, 1 );
        add_filter( 'manage_users_custom_column', array( $this, 'costumize_user_columns_data' ), 10, 3 );
        add_filter( 'manage_users_sortable_columns', array( $this, 'users_sortable_columns' ), 10, 1 );

        add_filter( 'pre_get_avatar_data', array( $this, 'get_avatar_data' ), 10, 2 );
    }  

    /**
     * Enqueues admin/front-end scripts
     *
     * @param string $hook_suffix File name of the currently executing script
     */
	public function enqueue_scripts ( $hook_suffix ) {
        $screens = apply_filters( 'describr_enqueue_scripts', array( 'profile.php', 'user-edit.php', 'users.php' ) );
        
        if ( in_array( $hook_suffix, $screens, true ) ) {
            $arr = array();

            $plugin = strtolower( $this->plugin_name );

            $handle_js  = $plugin . '-js-';
            $handle_css = $plugin . '-css-';

            $filepath_js  = $this->plugin_url . 'js/';
            $filepath_css = $this->plugin_url . 'css/';
                
            $handle_main_js = $handle_js . 'main';

            $can_upload = $this->can_upload_files();

            $current_user = ( int ) get_current_user_id();

            if ( isset( $_GET['user_id'] ) ) {
                $user_id = absint( $_GET['user_id'] );
            } else {
                $user_id = $current_user;
            }
                
            if ( $can_upload ) {
                //Allow users to select and delete avatar using WordPress media library
                wp_enqueue_media();
            }
                
            $object_js = array(
                'isMobile'   => wp_is_mobile(),
                'avatarPerm' => isset( $this->avatar_permissions['only'] ) ? ( int ) $this->avatar_permissions['only'] : 0,
                'pluginName'  => $this->plugin_name,
                'isEditor'    => $this->can_edit_profiles(),
                'canUpload'   => $can_upload,
                'loadMedia'   => did_action( 'wp_enqueue_media' ),
                'curUser'     => $current_user,
                'adminurl'    => get_admin_url(),
                'ajaxurl'     => admin_url( 'admin-ajax.php' ),
                'noncerest'   => wp_create_nonce( 'wp_rest' ),
                'resturl'     => rest_url( 'describr/v1/partner' ),
                'tagline_len' => $this->maxlen()['tagline'],
                'textarea_LG' => $this->maxlen()['textarea_LG'],
                'textarea_SM' => $this->maxlen()['textarea_SM'],
            );

            if ( $can_upload ) {
                $upload_size_limit = $this->upload_size_limit();
                
                $object_js['avatar'] = array(
                    'userId'        => $user_id,
                    'deleteNonce'   => wp_create_nonce( 'describr_remove_avatar_nonce' ),
                    'updateNonce'   => wp_create_nonce( 'describr_assign_from_media_library_avatar_nonce' ),
                    'fileSpecs'     => array(
                        'types'      => $this->supported_image_types(),
                        'sizeLimit'  => $upload_size_limit,
                        'sizeFormat' => size_format( $upload_size_limit ),
                    ),
                );
            }

            $user_info = get_userdata( $user_id );
    
            if ( $user_info ) {
                $profile = $this->plugin_user_profile( $user_info );
            } else {
                $profile = $this->plugin_user_profile();
            }
                
            $object_js['profile'] = $profile;

            //CSS for jQuery UI components
            wp_enqueue_style( $handle_css . 'jquery-ui', $filepath_css . 'jquery-ui/jquery-ui.min.css', $arr, DESCRIBR_VERSION );
            wp_enqueue_style( $handle_css . 'jquery-ui-structure', $filepath_css . 'jquery-ui/jquery-ui.structure.min.css', $arr, DESCRIBR_VERSION );
            wp_enqueue_style( $handle_css . 'jquery-ui-theme', $filepath_css . 'jquery-ui/jquery-ui.theme.min.css', $arr, DESCRIBR_VERSION );

            //Load both autocomplete and selectmenu jQuery UI methods
            wp_enqueue_script( 'jquery-ui-autocomplete' );
            wp_enqueue_script( 'jquery-ui-selectmenu' );

            //Dompurify
            wp_enqueue_script( $handle_js . 'dompurify', $filepath_js . 'dompurify.js', $arr, DESCRIBR_VERSION, true );

            //The libphonenumber library enables the verifying of phone numbers
            wp_enqueue_script( $handle_js . 'libphonenumber', $filepath_js . 'libphonenumber.js', $arr, DESCRIBR_VERSION, true );
             
            //Languages
            wp_enqueue_script( $handle_js . 'langs', $filepath_js . 'langs.js', $arr, DESCRIBR_VERSION, true );

            //Time zones
            wp_enqueue_script( $handle_js . 'timezone', $filepath_js . 'timezone.js', $arr, DESCRIBR_VERSION, true );
            
            //All cities in the world
            wp_enqueue_script( $handle_js . 'cities', $filepath_js . 'cities.js', $arr, DESCRIBR_VERSION, true );

            //All countries and states in the world
            wp_enqueue_script( $handle_js . 'country-state', $filepath_js . 'country-state.js', $arr, DESCRIBR_VERSION, true );
                
            //Main JavaScript
            wp_enqueue_script( $handle_main_js, $filepath_js . 'main-script.js', array( 'jquery', 'wp-i18n' ), filemtime( plugin_dir_path( __FILE__ ) . 'js/main-script.js' ), true );
               
            wp_localize_script( $handle_main_js, $plugin, $object_js );
                
            //JavaScript object containing translated texts
            wp_localize_script( $handle_main_js, $plugin . 'i18n', describr_translated_texts() );
                        
            //Main CSS
            wp_enqueue_style( $handle_css . 'main', $filepath_css . 'styles.css', $arr, filemtime( plugin_dir_path( __FILE__ ) . 'css/styles.css' ) );
        }
    }

	/**
	 * Sets option during plugin activation by the way of register_activation_hook()
     * 
     * Credit to Akismet
	 *
     * @static
	 */
	public static function plugin_activation () {
        if ( ! empty( $_SERVER['SCRIPT_NAME'] ) && false !== strpos( $_SERVER['SCRIPT_NAME'], '/wp-admin/plugins.php' ) ) {
            //This option is get in the admin_init callback to verify that activation of the plugin is completed
            add_option( 'describr_is_activated', true );
        }
	}

    /**
     * Removes plugin's options and user meta from the database during plugin deactivation
     * 
     * @static
     */
    public static function plugin_deactivation () {
        global $wpdb;
        
        if ( ! self::is_wpdb_prefix() ) {
            return;
        }

        delete_option( 'describr_avatars' );
        
        $users = get_users();
        
        if ( $users ) {
            $describr = new DESCRIBR;

            foreach ( $users as  $user ) {
                delete_user_meta( $user->ID, 'describr' );
                delete_user_meta( $user->ID, 'describr_last_login' );
                delete_user_meta( $user->ID, 'describr_published' );

                $describr->plugin_deactivaton_delete_avatar( $user->ID );
            }
        }
    }
    
    /**
     * Updates the plugin's user meta upon user registration or plugin activation
     * 
     * @param int   $user_id User ID
     * @param array $user    User data
     */
    private function plugin_add_user_meta ( $user_id, $user = array() ) {
        if ( is_array( $user ) && count( $user ) ) {
            $user = ( object ) $user;
        } else {
            $user = get_userdata( ( int ) $user_id );
        
            if ( ! $user ) {
                return;
            }
        }

        $maxlen = $this->maxlen();

        $approval_key                 = $this->array_keys[1];      
        $privacy_key                  = $this->array_keys[2];
        $event_log_key                = $this->array_keys[4];
        $badge_key                    = 'badge';
        $timezone_key                 = 'timezone';
        $event_user_id_and_time       = ( ( int ) get_current_user_id() ) . '__' . $this->time();
        $event_user_id_and_time_array = array( $event_user_id_and_time );
        $describr_user_profile        = array();
        
        $timezone = get_option( 'timezone_string' );
           
        if ( ! $timezone ) {
            $timezone = get_option( 'gmt_offset' );
        }
        
        if ( $this->is_string_or_numeric( $timezone ) && ! $this->empty( $timezone ) ) {
            $describr_user_profile[ $timezone_key ]['name']           = $timezone;
            $describr_user_profile[ $timezone_key ][ $privacy_key ]   = 1;
            $describr_user_profile[ $timezone_key ][ $approval_key ]  = 1;
            $describr_user_profile[ $timezone_key ][ $event_log_key ] = $event_user_id_and_time_array;
        }
        
        if ( isset( $user->first_name ) && $this->is_string_or_numeric( $user->first_name ) && ! $this->empty( $user->first_name ) && $maxlen['textbox'] >= mb_strlen( ( string ) $user->first_name ) ) {
            $describr_user_profile[ $badge_key ]['first_name'] = $user->first_name;
        } elseif ( isset( $user->display_name ) && $this->is_string_or_numeric( $user->display_name ) && ! $this->empty( $user->display_name ) && $maxlen['textbox'] >= mb_strlen( ( string ) $user->display_name ) ) {
            $describr_user_profile[ $badge_key ]['first_name'] = $user->display_name;
        } elseif ( isset( $user->user_nicename ) && $this->is_string_or_numeric( $user->user_nicename ) && ! $this->empty( $user->user_nicename ) && $maxlen['textbox'] >= mb_strlen( ( string ) $user->user_nicename ) ) {
            $describr_user_profile[ $badge_key ]['first_name'] = $user->user_nicename;
        }
        
        if ( isset( $user->last_name ) && $this->is_string_or_numeric( $user->last_name ) && ! $this->empty( $user->last_name ) && $maxlen['textbox'] >= mb_strlen( ( string ) $user->last_name ) ) {
            $describr_user_profile[ $badge_key ]['last_name'] = $user->last_name;
        }

        if ( isset( $describr_user_profile[ $badge_key ] ) ) {
            $describr_user_profile[ $badge_key ][ $privacy_key ]   = 1;
            $describr_user_profile[ $badge_key ][ $approval_key ]  = 1;
            $describr_user_profile[ $badge_key ][ $event_log_key ] = $event_user_id_and_time_array;
        }

        if ( isset( $user->user_email ) && is_string( $user->user_email ) && is_email( $user->user_email ) ) {
            $contact_key = 'contact';
            $email_key   = 'email';

            $describr_user_profile[ $contact_key ][ $email_key ]['address']        = $user->user_email;
            $describr_user_profile[ $contact_key ][ $email_key ][ $privacy_key ]   = 1;
            $describr_user_profile[ $contact_key ][ $email_key ][ $approval_key ]  = 1;
            $describr_user_profile[ $contact_key ][ $email_key ][ $event_log_key ] = $event_user_id_and_time_array;
        }

        if ( isset( $user->description ) && $this->is_string_or_numeric( $user->description ) && ! empty( $user->description ) && $maxlen['textarea_SM'] >= mb_strlen( ( string ) $user->description ) ) {
            $bio_key = 'bio';
            
            $describr_user_profile[ $bio_key ]['description']    = $user->description;
            $describr_user_profile[ $bio_key ][ $privacy_key ]   = 1;
            $describr_user_profile[ $bio_key ][ $approval_key ]  = 1;
            $describr_user_profile[ $bio_key ][ $event_log_key ] = $event_user_id_and_time_array;
        }

        if ( isset( $user->user_url ) && is_string( $user->user_url ) && $maxlen['textbox'] >= mb_strlen( $user->user_url ) ) {
            $parsed_url = $this->validate_url( $user->user_url );

            if ( $parsed_url ) {
                $web = 'websites';
                
                $describr_user_profile[ $web ]['addresses']      = array( $parsed_url );
                $describr_user_profile[ $web ][ $privacy_key ]   = 1;
                $describr_user_profile[ $web ][ $approval_key ]  = 1;
                $describr_user_profile[ $web ][ $event_log_key ] = $event_user_id_and_time_array;
            }
        }

        update_user_meta( ( int ) $user_id, 'describr_published', 1 );
        update_user_meta( ( int ) $user_id, 'describr', $this->sanitize_user_input( $describr_user_profile ) );
    }  
    
    /**
     * Loads text domain
     */
    public function load_textdomain () {
        load_plugin_textdomain( 'describr', false,  'describr/languages' );
    }
    
    /**
     * Registers REST endpoint
     */
    public function rest_api_init () {
        register_rest_route(
            'describr/v1',
            'partner',
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array( $this, 'rest_partner_search' ),
                'args' => array(
                    'search_term' => array(
                        'required'          => true,
                        'validate_callback' => array( $this, 'rest_validate' ),
                    ),
                    'profile_user_id' => array(
                        'required' => true,
                    ),
                ),
                'permission_callback' => array( 
                    $this,
                    'rest_permission',
                ),
            )
        );
    }

    /**
     * Validates search term sent by the way of REST
     * 
     * @param string $param Search term
     * @return bool True if search term neither is empty nor is of type array or object, otherwise False
     */
    public function rest_validate ( $search_term ) {
        if ( empty( $search_term ) || ! $this->is_string_or_numeric( $search_term ) ) {
            return false;
        }

        return true;
    }

    /**
     * Determines who can perform REST requests
     * 
     * @param array $request{
     *                 string 'profile_user_id' User ID belonging to the profile being edited
     *              }
     * @return bool True if the user can edit the profile, otherwise False
     */
    public function rest_permission ( WP_REST_Request $request ) {
        if ( isset( $request['profile_user_id'] ) && ! empty( $request['profile_user_id'] ) && is_numeric( $request['profile_user_id'] ) && current_user_can( 'edit_user', ( int ) $request['profile_user_id'] ) ) {
            return true;
        }

        return false;
    }
    
    /**
     * Searches for relationship partner by the way of REST
     * 
     * @param array $request{
     *                 string 'search_term' Keyword (s)
     *              }
     * @return WP_REST_Response object User info if found, otherwise empty 
     */
    public function rest_partner_search ( WP_REST_Request $request ) {
        global $describr_search_string;//To be used in the pre_user_query hook's callback
        
        $describr_search_string = sanitize_text_field( wp_unslash( $request['search_term'] ) );

        $response = array();
        
        add_action( 'pre_user_query', array( $this, 'partner_search_query' ) );

        $query = new WP_User_Query(
            array(
                'fields' => 'all',
            )
        ); 

        $users = $query->get_results();
        
        remove_action( 'pre_user_query', array( $this, 'partner_search_query' ) );
            
        if ( is_array( $users ) && count( $users ) ) {
            foreach ( $users as $user ) {
                $found_match = '';
                
                if ( isset( $user->describr ) ) {
                    if ( isset( $user->describr['badge'] ) ) {
                        if ( $this->user_profile_section_permission( $user->describr['badge'], $user->ID ) ) {
                            if ( isset( $user->describr['badge']['first_name'] ) && ! $this->empty( $user->describr['badge']['first_name'] ) ) {
                                $name = $user->describr['badge']['first_name'];
                         
                                if ( isset( $user->describr['badge']['last_name'] ) && ! $this->empty( $user->describr['badge']['last_name'] ) ) {
                                    $name .= ' ' . $user->describr['badge']['last_name'];
                                }

                                if ( 0 === stripos( $name, $describr_search_string ) ) {
                                    $found_match = $name;
                                }
                            }
                        } else {
                            continue;
                        }
                    }
                }
                
                if ( ! $found_match && isset( $user->first_name ) && ! $this->empty( $user->first_name ) ) {
                    $name = $user->first_name;

                    if ( isset( $user->last_name ) && ! $this->empty( $user->last_name ) ) {
                        $name .= ' ' . $user->last_name;
                    }
                            
                    if ( 0 === stripos( $name, $describr_search_string ) ) {
                        $found_match = $name;
                    }
                }

                if ( ! $found_match ) {
                    if ( isset( $user->user_login ) && ! $this->empty( $user->user_login ) && 0 === stripos( $user->user_login, $describr_search_string ) ) {
                        $found_match = $user->user_login;
                    } elseif ( isset( $user->display_name ) && ! $this->empty( $user->display_name ) && 0 === stripos( $user->display_name, $describr_search_string ) ) {
                        $found_match = $user->display_name;
                    } elseif ( isset( $user->user_nicename ) && ! $this->empty( $user->user_nicename ) && 0 === stripos( $user->user_nicename, $describr_search_string ) ) {
                        $found_match = $user->user_nicename;
                    } elseif ( isset( $user->nickname ) && ! $this->empty( $user->nickname ) &&  0 === stripos( $user->nickname, $describr_search_string ) ) {
                        $found_match = $user->nickname;
                    }           
                }
                    
                if ( $found_match ) {
                    $response[] = array(
                        'id'   => $user->ID,
                        'name' => $found_match,
                    );
                }
            }
        }
        
        return new WP_REST_Response( $response );
    }
  
    /**
     * Modifies database query during relationship-partner search
     * 
     * This callback function is added to the pre_user_query hook before the database is queried and removed
     * immediately after
     * 
     * @param object $query SQLs
     */
     public function partner_search_query ( $query ) {
        global $describr_search_string, $wpdb;

        if ( ! isset( $describr_search_string ) || ! self::is_wpdb_prefix() ) {
            return;
        }
        
        /*Check if string contains a space indicating the user is searching by username, nickname, or first and last name*/
        $words       = preg_split( '/\s+/', $describr_search_string, -1, PREG_SPLIT_NO_EMPTY );
        $words_count = count( $words );
        
        $db_meta  = "`{$wpdb->prefix}usermeta`";
        $db_users = "`{$wpdb->prefix}users`";
        
        $like = $wpdb->esc_like( sanitize_text_field( $describr_search_string ) ) . '%';

        $prepare_args = array( 
            ( int ) get_current_user_id(), 
            $like,
            $like,
            $like,
        );
        
        $query->query_fields = $wpdb->prepare( "SQL_CALC_FOUND_ROWS DISTINCT $db_users.`ID`, $db_users.`user_login`" );
         
        $query->query_from .= $wpdb->prepare( " INNER JOIN $db_meta ON $db_meta.`user_id` = $db_users.`ID`" );
        
        $where = " WHERE $db_users.`ID` <> %d AND ($db_users.`user_login` LIKE %s OR $db_users.`display_name` LIKE %s OR $db_users.`user_nicename` LIKE %s OR ";

        //Is the user searching by username or nickname?
        if ( $words_count > 2 || $words_count < 2 ) {
            $where .= "($db_meta.`meta_key` IN (";
            
            //String with more than two spaces can match a nickname
            if ( $words_count > 2 ) {
                $where .= "'nickname'";
            } else { //String without a space can match nickname or first name
                $where .= "'nickname', 'first_name'";
            }

            $where .= ") AND $db_meta.`meta_value` LIKE %s)";

            $prepare_args[] = $like;
        } else {
            $where .= "($db_meta.`meta_key` IN ('nickname', 'first_name') AND $db_meta.`meta_value` = %s)";

            $prepare_args[] = sanitize_text_field( $words[0] );
        }

        $where .= ')';

        $query->query_where = $wpdb->prepare( $where, $prepare_args );

        $query->query_orderby .= $wpdb->prepare( ", $db_users.`display_name` ASC, $db_users.`user_nicename` ASC, $db_meta.`meta_value` ASC" );
    }

    /**
     * Fires if the current user is editing his or her own profile
     * 
     * Delineates the plugin's section on the user's profile screen
     * 
     * Profile data are added by JavaScript
     * 
     * @param WP_User $profile_user User info 
     */
	public function show_user_profile ( $profile_user ) {
        $name = $this->username_to_use( $profile_user );

        if( $this->empty( $name ) ) {
            $alt = __( 'Loading profile data...', 'describr' );
        } else {
            $alt = sprintf(
                /*translators: %s: User's name*/
                __( 'Loading %s profile data...', 'describr' ),
                $name
            );
        }
        ?>
        <div id="describr" class="describr">
            <h1><?php echo esc_html( $this->plugin_name );?></h1>
            <span class="describr__accessibility" aria-live="polite"></span>
            <p class="describr__loading">
                <img src="<?php echo esc_url( $this->plugin_url ) . 'images/loading.gif';?>" alt="<?php echo esc_attr( $alt );?>" width="20px" height="20px">
            </p>
        </div>
        <?php
        wp_nonce_field( 'describr_update_profile_nonce', 'describr_update_profile_nonce', false );
	}

	/**
	 * Saves any changes made to profile
	 *
	 * @param int $user_id User ID
	 */
	public function edit_user_profile ( $user_id ) {
        require_once plugin_dir_path( __FILE__ ) . 'edit-user-profile-describr.php';
    }
    
    /**
     * Provides info related to the owner of the profile in question
     * 
     * No profile info is redacted if the user profile is being viewed by an editor
     * 
     * @param WP_User object|array $user User info
     * @return array Info related to the profile owner, with sections redacted if necessary
     */
    private function plugin_user_profile ( $user = array() ) {
        if ( is_object( $user ) && isset( $user->describr ) ) {
            $describr_user_profile = ( array ) $user->describr;
        } elseif ( is_array( $user ) ) {
            $describr_user_profile = $user;
        } else {
            $describr_user_profile = array();
        }
        
        $plugin_user_id = 0;

        $describr_user_profile_is_published = 0;

        if ( is_object( $user ) ) {
            if ( isset( $user->ID ) ) {
                $plugin_user_id = ( int ) $user->ID;
            }

            if ( isset( $user->describr_published ) ) {
                $describr_user_profile_is_published = ( int ) $user->describr_published;
            }
        }    
        
        $sessions = WP_Session_Tokens::get_instance( $plugin_user_id );
        
        $is_editor = $this->can_edit_profiles();
        $can_edit  = $is_editor;
        
        if ( count( $describr_user_profile ) && $plugin_user_id && ( $describr_user_profile_is_published || $can_edit ) ) {
            if ( ! $can_edit ) {
                $can_edit = current_user_can( 'edit_user', $plugin_user_id );
            }

            $describr_user_profile = $this->user_friendly_user_profile_info( $describr_user_profile, $plugin_user_id, $can_edit );
            $describr_user_profile = $this->user_friendly_user_profile_event_logs( $describr_user_profile, $is_editor );
            $describr_user_profile = $this->unset_empty_array_key( $describr_user_profile );
            
            $describr_user_profile['displayName']   = $this->username_to_use( $user );
            $describr_user_profile['profileUserId'] = $plugin_user_id;
            $describr_user_profile['published']     = $describr_user_profile_is_published;
            $describr_user_profile['isOwnProfile']  = $plugin_user_id === ( int ) get_current_user_id();
            $describr_user_profile['isLogin']       = count( $sessions->get_all() );
            $describr_user_profile['canEdit']       = $can_edit;
            $describr_user_profile['userImage']     = $this->get_the_avatar( $plugin_user_id );
        } else {
            $describr_user_profile = array();
        }       

        return $describr_user_profile;
    }
    
    /**
     * Ensures user profile data are in user-friendly format
     * 
     * @param array $user_profile_prepare User profile info
     * @param int   $user_id              User ID
     * @param bool  $can_edit             Whether the current user can edit the user profile
     */
    private function user_friendly_user_profile_info ( $user_profile_prepare, $user_id, $can_edit ) {
        $array_keys = $this->array_keys;

        $timeperiod_key = 'timeperiod';
        $from_key       = 'from';
        $to_key         = 'to';
        
        foreach ( $user_profile_prepare as $user_profile_prepare_key => &$user_profile_prepare_value ) {
            if ( is_array( $user_profile_prepare_value  ) ) {
                $user_profile_prepare_value = $this->user_friendly_user_profile_info( $user_profile_prepare_value, $user_id, $can_edit );
            } elseif ( is_object( $user_profile_prepare_value ) ) {
                unset( $user_profile_prepare[ $user_profile_prepare_key ] );
            } elseif ( $this->user_profile_section_permission( $user_profile_prepare, $user_id ) ) {
                if ( ! $can_edit && ! empty( $user_profile_prepare_value ) && in_array( $user_profile_prepare_key, array( 'date', 'moved', 'since', $from_key ), true ) ) {
                    $user_profile_prepare_value = ( string ) $user_profile_prepare_value;
                       
                    if ( isset( $user_profile_prepare[ $from_key ] ) ) {
                        //Allow only one timeperiod per section
                        if ( ! isset( $user_profile_prepare[ $timeperiod_key ] ) ) {
                            $timeperiod = $this->create_date( $user_profile_prepare_value );
                            $to         = '';

                            if ( ! empty( $user_profile_prepare[ $to_key ] ) ) {
                                $to = $user_profile_prepare[ $to_key ];
                            }
                        
                            if ( isset( $user_profile_prepare['present'] ) ) {
                                $timeperiod .= '-' . __( 'present', 'describr' );
                            } elseif ( isset( $user_profile_prepare['graduated'] ) ) {
                                if ( $to ) {
                                    $to = explode( '-', $to );

                                    $timeperiod = sprintf(
                                        /*translators: %s: Year*/
                                        __( 'Class of %s', 'describr' ),
                                        ( string ) $to[0]
                                    );
                                }
                            } elseif ( $to ) {
                                $timeperiod .= '-' . $this->create_date( $to );
                            }

                            if ( $timeperiod ) {
                                $user_profile_prepare[ $timeperiod_key ] = $timeperiod;
                            }
                        }
                    } else {
                        $user_profile_prepare_value = $this->create_date( $user_profile_prepare_value );
                    }
                }
            } else {
                $user_profile_prepare = array();

                break;
            }
            
        }

        return $user_profile_prepare;
    }
    
    /**
     * Calls plugin's sort_profile_section_events function so that each user 
     * profile section has user-friendly events logs 
     *  
     * @param array $user_profile_to_prepare User profile info
     * @param bool  $is_editor               Whether the current user is an editor
     * @return array User profile info
     */
    private function user_friendly_user_profile_event_logs ( $user_profile_to_prepare, $is_editor ) {
        foreach( $user_profile_to_prepare as $user_profile_to_prepare_key => &$user_profile_to_prepare_value ) {
            if ( ( string ) $this->array_keys[4] === ( string ) $user_profile_to_prepare_key ) {
                if ( $is_editor ) {
                    $user_profile_to_prepare[ $user_profile_to_prepare_key ] = $this->sort_profile_section_events( $user_profile_to_prepare_value );
                } else {
                    unset( $user_profile_to_prepare[ $user_profile_to_prepare_key ] );
                }
            } elseif ( is_array( $user_profile_to_prepare_value ) ) {
                $user_profile_to_prepare_value = $this->user_friendly_user_profile_event_logs( $user_profile_to_prepare_value, $is_editor );
            }
        }

        return $user_profile_to_prepare;
    }

    /**
     * Sorts user profile section's events in descending order using the date the event was logged
     * 
     * @param array $log Event logs
     * @return array User-friendly Event logs  
     */
    private function sort_profile_section_events ( $log ) {
        $log = ( array ) $log;
        
        foreach ( $log as $event => $details ) {
            $current_user_timezone = '';

            $event_user_id_and_time = explode( '__', $details );

            $user = get_userdata( ( int ) $event_user_id_and_time[0] );

            $current_user = wp_get_current_user();

            if ( $this->can_edit_profiles() && $current_user && isset( $current_user->describr ) && isset( $current_user->describr['timezone'] ) && isset( $current_user->describr['timezone']['name'] ) && isset( $current_user->describr['timezone'][ $this->array_keys[1] ] ) ) {
                $current_user_timezone = $current_user->describr['timezone']['name'];
            }
            
            if ( ! isset( $event_user_id_and_time[1] ) ) {
                $event_user_id_and_time[1] = $this->time();
            }

            $log[ $event ] = array(
                'date' => $this->datetime( $event_user_id_and_time[1], $current_user_timezone ), 
                'name' => $this->username_to_use( $user ), 
                'id'   => $event_user_id_and_time[0], 
            );
        }

        usort( $log, array( $this, 'sort_updated_by' ) );
                
        return $log;
    }
    
    /**
     * Sorts event logs by date and in descending order
     * 
     * @param array $first_date_to_compare  The first date to compare
     * @param array $second_date_to_compare The second date to compare
     * @return int 0 if $first_date_to_compare and $second_date_to_compare date are the same, 1 if
     *             $first_date_to_compare is greater than $second_date_to_compare date, or -1 if
     *             $first_date_to_compare is less than $second_date_to_compare date.
     */
    public function sort_updated_by ( $first_date_to_compare, $second_date_to_compare ) {
        $first_time_to_compare  = strtotime( $first_date_to_compare['date'] );
        $second_time_to_compare = strtotime( $second_date_to_compare['date'] );

        if ( $first_time_to_compare > $second_time_to_compare ) {
            return -1;
        } elseif ( $second_time_to_compare > $first_time_to_compare ) {
            return 1;
        } else{
            return 0;
        }
    }

    /**
     * Sets privacy, approval, and event log for user profile section
     *
     * @param array $profile_section Previously saved privacy, approval, and event log
     * @return array Updated privacy, approval, and event log
     */
    private function update_user_profile_section_event_log ( $profile_section = array() ) {
        $event_user_id_and_time = ( ( int ) get_current_user_id() ) . '__' . $this->time();
            
        $privacy_key = $this->array_keys[2];
        $event_key   = $this->array_keys[4];
        
        //The section is an existing one if the visibility element is set
        if ( isset( $profile_section[ $privacy_key ] ) ) {
            if ( isset( $profile_section[ $event_key ] ) ) {
                if ( is_array( $profile_section[ $event_key ] ) ) {
                    $profile_section[ $event_key ][] = $event_user_id_and_time;
                } else {
                    $profile_section[ $event_key ] = array( $profile_section[ $event_key ], $event_user_id_and_time );
                }
            } else {
                $profile_section[ $event_key ] = array( $event_user_id_and_time );
            }
        } else {
            $profile_section[ $this->array_keys[1] ] = 1;
            $profile_section[ $privacy_key ]         = 1;            
            $profile_section[ $event_key ]           = array( $event_user_id_and_time );
        }

        return $profile_section;
    }

    /**
     * Adds the necessary changes to user profile sections
     * 
     * @param string|int|array $submitted_value           The new value
     * @param string           $section_key               The key to set the new value
     * @param array            $old_profile_section_array Existing info pertaining to the section
     * @param bool             $change                    Inicates if changes are made
     * @param array            $new_profile_section_array User-submitted data pertaining to the section
     */
    private function update_user_profile_section ( $submitted_value, $section_key, &$old_profile_section_array, &$change, $new_profile_section_array = array() ) {
        $submitted_value_length = 0;

        if ( is_array( $submitted_value ) ) {
            $submitted_value_length = count( $submitted_value );
        } elseif ( ! is_object( $submitted_value ) ) {
            $submitted_value_length = mb_strlen( ( string ) $submitted_value );
        }

        if ( isset( $old_profile_section_array[ $section_key ] ) ) {
            if ( $new_profile_section_array ) {
                $this->add_user_profile_section_controls( $old_profile_section_array, $new_profile_section_array, $change );
            }

            if ( $submitted_value_length ) {
                if ( is_array( $submitted_value ) ) {
                    if ( $submitted_value !== $old_profile_section_array[ $section_key ] ) {
                        $old_profile_section_array[ $section_key ] = $submitted_value;
                        $change = true;
                    }
                } elseif ( ( string ) $submitted_value !== ( string ) $old_profile_section_array[ $section_key ] ) {
                    $old_profile_section_array[ $section_key ] = $submitted_value;
                    $change = true;
                }
            } else {
                unset( $old_profile_section_array[ $section_key ] );                
               $change = true;
            }
        } elseif ( $submitted_value_length ) {
            $old_profile_section_array[ $section_key ] = $submitted_value;
            $change = true;
        }
    }

    /**
     * Sets a user profile section's visibility and approval status
     * 
     * @param array $old_profile_section_array Already saved data
     * @param array $new_profile_section_array New data
     * @param bool  $change                    Whether already saved data should be updated in the database
     */
    private function add_user_profile_section_controls ( &$old_profile_section_array, $new_profile_section_array, &$change ) {
        $approval_key = $this->array_keys[1];
        $privacy_key  = $this->array_keys[2];
        
        $error = false;

        if ( isset( $new_profile_section_array[ $privacy_key ] ) ) {
            if ( ! is_numeric( $new_profile_section_array[ $privacy_key ] ) ) {
                $error = true;
            } 
        }
        
        if ( ! $error ) {
            $privacy_value = isset( $new_profile_section_array[ $privacy_key ] ) && in_array( ( int ) $new_profile_section_array[ $privacy_key ], $this->user_int, true ) ? ( int ) $new_profile_section_array[ $privacy_key ]: 1;

            if ( isset( $old_profile_section_array[ $privacy_key ] ) && $privacy_value !== ( int ) $old_profile_section_array[ $privacy_key] ) {
                $old_profile_section_array[ $privacy_key ] = $privacy_value;

                $change = true;
            }
        }
        

        if ( $this->can_edit_profiles() ) {
            $error = false;

            if ( isset( $new_profile_section_array[ $approval_key ] ) ) {
                if ( ! is_numeric( $new_profile_section_array[ $approval_key ] ) ) {
                    $error = true;
                } 
            }
            
            if ( ! $error ) {
                $approval_value = isset( $new_profile_section_array[ $approval_key ] ) && in_array( ( int ) $new_profile_section_array[ $approval_key ], $this->user_int, true ) ? ( int ) $new_profile_section_array[ $approval_key ] : 0;

                if ( isset( $old_profile_section_array[ $approval_key ] ) && $approval_value !== ( int ) $old_profile_section_array[ $approval_key ] ) {
                    $old_profile_section_array[ $approval_key ] = $approval_value;

                    $change = true;
                }
            }
        }
    }
    
    /**
     * Adds to the plugin's main user meta array changes made to a user profile section
     * 
     * @param array  $old_userdata            Data already saved
     * @param array  $new_userdata            Data that will be saved in the database
     * @param array  $user_profile_section    New data for the user profile section in question 
     * @param string $saved_data_key          Array key used to unset old data 
     * @param string $locate_updated_data_key Array key used to set new data
     * @param bool   $change                  Inicates whether changes were made to the section
     */
    private function commit_changes_made_to_user_profile_section ( &$old_userdata, &$new_userdata, $user_profile_section, $saved_data_key, $locate_updated_data_key, $change ) {
        if ( $change ) {
            //Remove old data
            if ( isset( $old_userdata[ $saved_data_key ] ) ) {
                unset( $old_userdata[ $saved_data_key ] );
            }
            
            //Are there new data? If yes, add them to the array that will be saved in the database
            if ( isset( $user_profile_section[ $locate_updated_data_key ] ) ) {
                $new_userdata[ $saved_data_key ] = $this->update_user_profile_section_event_log( $user_profile_section );
            }        
        }
    }
    
    /**
     * Validates city
     *
     * @param string $city The city to validate
     * @return bool True if the city doesn't contain disallowed characters, otherwise False
     */
    public function is_city ( $city = '' ) {
        if ( is_string( $city ) ) {
            return 1 !== preg_match( "/[^0-9a-zA-Z\.\s&,'-]+/", $city );
        } else {
            return false;
        }
    }

    /**
     * Fetches HTML img
     * 
     * Credit to Simple Local Avatars for how to customize
     * the filters in WordPress get_avatar function and for how to assign and delete the avatar
     * 
     * @see https://10up.com/plugins/simple-local-avatars-wordpress/
     * 
     * @param int|string|object $id_or_email A user ID,  email address, or comment object
     * @param int               $size        Size of the avatar
     * @param string            $default     Url to a default image to use if no avatar is available
     * @param string            $alt         Alternate text to use in image tag. Defaults to blank
     * @param array             $args        Extra arguments related to the avatar (optional)
     *
     * @return string User's avatar, otherwise default avatar
     */
    private function get_the_avatar ( $id_or_email, $size = 96, $default = '', $alt = '', $args = array() ) {
        return apply_filters( 'describr_avatar', get_avatar( $id_or_email, $size, $default, $alt, $args ) );
    }
    
    /**
     * Fetches the site's default avatar
     *
     * @return string Default avatar
     */
    public function get_default_avatar () {
        $avatar_default = ( string ) get_option( 'avatar_default' );

        if ( empty( $avatar_default ) ) {
            $avatar_default = 'mystery';
        }

        return $avatar_default;
    }
    
    /**
	 * Filters avatar data early to add avatar url if needed. This filter hooks
	 * before Gravatar setup to prevent wasted requests
	 *
	 * @param array $args        Arguments passed to get_avatar_data function, after processing
	 * @param mixed $id_or_email The Gravatar to retrieve. Accepts a user ID, Gravatar MD5 hash,
	 *                           user email, WP_User object, WP_Post object, or WP_Comment object
     * @return array Data about the avatar
	 */
	public function get_avatar_data ( $args, $id_or_email ) {
		if ( ! empty( $args['force_default'] ) ) {
			return $args;
		}
        
        $change_alt = apply_filters( 'describr_avatar_change_alt', true );
        
        $size = ( int ) $args['size'];

        $avatar_url = $this->get_avatar_url( $id_or_email, $size );
		
        if ( $avatar_url ) {
			$args['url']    = $avatar_url;
            $args['height'] = $size;
            $args['width']  = $size;

            if ( $change_alt ) {
                 if ( is_numeric( $id_or_email ) ) {
                    $user = get_user_by( 'id' , ( int ) $id_or_email );
                } elseif ( is_string( $id_or_email ) ) {
                    $user = get_user_by( 'email', sanitize_text_field( $id_or_email ) ); 
                } elseif ( is_object( $id_or_email ) && ! empty( $id_or_email->user_id ) ) {
                    $user = get_user_by( 'id' , ( int ) $id_or_email->user_id );
                } elseif ( $id_or_email instanceof WP_Post && ! empty( $id_or_email->post_author ) ) {
                    $user = get_user_by( 'id' , ( int ) $id_or_email->post_author );
                }
            
                if ( $user ) {
                    $name = $this->username_to_use( $user ); 

                    if ( ! $this->empty( $name ) ) {
                        $args['alt'] = $name;
                    }  
                }
            }
		}

		//Should default avatar be used if no url exists?
		if ( ! $avatar_url && ! empty( $this->avatar_permissions['only'] ) ) {
			$args['url'] = $this->get_default_avatar_url( $args['size'] );
            
            if ( $change_alt ) {
                $args['alt'] = $this->default_avatar;
            }
		}

		if ( ! empty( $args['url'] ) ) {
			$args['found_avatar'] = true;
		}
        
        return $args;
	}

    /**
	 * Gets url of avatar uploaded by this plugin
     * 
     * @param mixed $id_or_email The Gravatar to retrieve. Accepts a user ID, Gravatar
     *                           MD5 hash, user email, WP_User object, WP_Post object,
     *                           or WP_Comment object
	 * @param int   $size        Requested avatar size
     * @return string The avatar url, otherwise empty string
	 */
	public function get_avatar_url ( $id_or_email, $size ) {
        $user = false;
        
        $user_id = 0;

        $avatar_url = '';
        
        if ( is_numeric( $id_or_email ) ) {
            $user_id = ( int ) $id_or_email;
        } elseif ( is_string( $id_or_email ) ) {
            $user = get_user_by( 'email', sanitize_text_field( $id_or_email ) );
            
            if ( $user ) {
                $user_id = ( int ) $user->ID;
            }
        } elseif ( is_object( $id_or_email ) && ! empty( $id_or_email->user_id ) ) {
            $user_id = ( int ) $id_or_email->user_id;
        } elseif ( $id_or_email instanceof WP_Post && ! empty( $id_or_email->post_author ) ) {
            $user_id = ( int ) $id_or_email->post_author;
        }
                
        if ( ! $user && $user_id ) {
            $user = get_user_by( 'id', $user_id );
        }
        
        if ( ! $user || ! isset( $user->describr ) ) {
            return '';
        }
        
        $describr_user_profile = ( array ) $user->describr;


        if ( ! isset( $describr_user_profile['avatar'] ) ) {
            return '';
        }
        
        $avatars = ( array ) $describr_user_profile['avatar'];
        
        if ( ! $this->user_profile_section_permission( $avatars, $user_id ) ) {
            return '';
        }
                  
        if ( empty( $avatars[ $this->array_keys[3] ] ) ) {
            return '';
        }
        
        $upload_path = wp_get_upload_dir();

        $baseurl = $upload_path['baseurl'];
        $basedir = $upload_path['basedir'];

        if ( is_ssl()  && 0 !== strpos( $baseurl, 'https' ) ) {
            $baseurl = str_replace( 'http://', 'https://', $baseurl );
        }
        
        $size = ( int ) $size;

        if ( ! empty( $avatars[ $size ] ) ) {
            if ( file_exists( $basedir . $avatars[ $size ] ) ) {
                $avatar_url = $baseurl . $avatars[ $size ];
            }
        }
        
        //The avatar is legitimate only if it has a media ID (assigned by WordPress), for which we checked
        if ( ! empty( $avatars[ $this->array_keys[0] ] ) ) {
            //Has the media been deleted?
            $avatar_full_path = get_attached_file( ( int ) $avatars[ $this->array_keys[0] ] );
            
            if ( ! $avatar_full_path ) {
                $avatar_partial_path = ( string ) $avatars[ $this->array_keys[3] ];
                $avatar_full_path    = $basedir . $avatar_partial_path;
                
                if ( ! file_exists( $avatar_full_path ) ) {
                    $this->avatar_delete( $user_id );

                    return '';
                }
            }
            
            //Does the avatar not exist in this size? If yes, create one in this size
            if ( empty( $avatars[ $size ] ) ) {
                if ( apply_filters( 'describr_avatars_dynamic_resize', true ) ) {
                    $this->avatar_generate( $avatar_full_path, $upload_path, $size, $avatars );
                            
                    //Was the image create? If yes, save its url.
                    if ( ! empty( $avatars[ $size ] ) ) {
                        $avatar_url = $avatars[ $size ];

                        $avatars[ $size ] = $this->avatar_remove_baseurl( $avatars[ $size ] );

                        unset( $describr_user_profile['avatar'] );

                        $this->plugin_update_user_meta( $user_id, $describr_user_profile, array( 'avatar' => $avatars ) );
                    }
                }
            }
        }
        
        if ( $avatar_url ) {
            if ( 0 !== strpos( $avatar_url, 'http' ) ) {
                $avatar_url = home_url( $avatar_url );
            }
                       
            return $avatar_url;
        }
        
        return '';
    }

    /**
     * Creates default avatar url
     *
     * @param int $size Avatar size
     * @return string Avatar default url
     */
    public function get_default_avatar_url ( $size ) {
        $default = ( string ) $this->default_avatar;

        $host = is_ssl() ? 'https://secure.gravatar.com' : 'http://0.gravatar.com';

        if ( 'mystery' === $default ) {
            //ad516503a11cd5ca435acc9bb6523536 == md5('unknown@gravatar.com')
            $default = "{$host}/avatar/ad516503a11cd5ca435acc9bb6523536?s={$size}"; 
        } elseif ( 'blank' === $default ) {
            $default = includes_url( 'images/blank.gif' );
        } elseif ( 'gravatar_default' === $default ) {
            $default = "{$host}/avatar/?s={$size}";
        } else {
            $default = "{$host}/avatar/?d=$default&amp;s={$size}";
        }

        return $default;
    }
    
    /**
     * Generates avatar
     *
     * @param string $path        Base avatar file path
     * @param array  $upload_path Info about WordPress upload directory  
     * @param int    $size        Avatar size
     * @param array  $avatars     Array in which to save new avatar path    
     * @return bool True if new avatar is created, otherwise false
     */
    public function avatar_generate ( $path, $upload_path, $size, &$avatars ) {        
        $editor = wp_get_image_editor( $path );

        if ( is_wp_error( $editor ) ) {
            return;
        }
        
        $resized = $editor->resize( $size, $size, false );

        if ( is_wp_error( $resized ) ) {
            return;
        }

        $dest_file = $editor->generate_filename();
        $saved     = $editor->save( $dest_file );

        if ( is_wp_error( $saved ) ) {
            return;
        }
        
        $avatars[ $size ] = str_replace( $upload_path['basedir'], $upload_path['baseurl'], $dest_file );
    }

	/**
     * Gives developers access to override maximum file size for avatar upload 
     * 
	 * @return int Maximum file size
	 */
	private function upload_size_limit () {
        return apply_filters( 'describr_files_upload_limit', wp_max_upload_size() );
	}    

    /**
	 * Deletes avatar by the way of ajax
	 */
	public function action_remove_avatar () {
        if ( isset( $_POST['user_id'] ) && is_numeric( $_POST['user_id'] ) && defined( 'DOING_AJAX' ) && DOING_AJAX ) {
            $user_id = absint( $_POST['user_id'] );

            if ( ( $this->can_edit_profiles() || current_user_can( 'edit_user', $user_id ) ) && isset( $_POST['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash ( $_POST['_wpnonce'] ) ) , 'describr_remove_avatar_nonce' ) ) {
                //Delete old avatar
                $this->avatar_delete( $user_id );
                
                //Send the updated avatar to the client
                echo wp_kses_post( $this->get_the_avatar( $user_id ) );
            } else {
                wp_die( esc_html__( 'You do not have permission to edit this profile.', 'describr' ) );
            }
        }
        
        exit;
    }

	/**
	 * Assigns the avatar ID (issued by WordPress) to the user meta that the plugin stores
	 */
	public function action_assign_avatar () {
        if ( isset( $_POST['user_id'] ) && isset( $_POST[ $this->array_keys[0] ] ) && is_numeric( $_POST['user_id'] ) && is_numeric( $_POST[ $this->array_keys[0] ] ) && defined( 'DOING_AJAX' ) && DOING_AJAX ) {
            $user_id  = absint( $_POST['user_id'] );
            $media_id = absint( $_POST[ $this->array_keys[0] ] );

            if ( $this->can_upload_files() && ( $this->can_edit_profiles() || current_user_can( 'edit_user', $user_id ) ) && isset( $_POST['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash ( $_POST['_wpnonce'] ) ), 'describr_assign_from_media_library_avatar_nonce' ) ) {

                //Ensure the ID is associated with an image
                if ( wp_attachment_is_image( $media_id ) ) {
                    $this->assign_avatar( $media_id, $user_id );
                }
                
                //Send the new avatar to the client
                echo wp_kses_post( $this->get_the_avatar( $user_id ) );
            }
        }
        
        exit;
	}

	/**
	 * Deletes avatar
	 *
	 * @param int  $user_id         User ID
     * @param bool $update_database Whether to update the avatar info in the database 
	 */
	private function avatar_delete ( $user_id, $update_database = true ) {
        $user = get_user_by( 'id', ( int ) $user_id );
		
        if ( $user && isset( $user->describr ) ) {
            $array_key = $this->array_keys;

            $describr_user_profile = ( array ) $user->describr;

            if ( isset( $describr_user_profile['avatar'] ) ) {
                $avatars = ( array ) $describr_user_profile['avatar'];

                $upload_path = wp_get_upload_dir();

                foreach ( $avatars as $key => $value ) {
                    if ( ( string ) $key === ( string ) $array_key[0] ) {
                        //Prevent WordPress media library from using the url of a deleted image
                        wp_delete_attachment( ( int ) $value, true );
                    } elseif ( ! in_array( $key, array( $array_key[1], $array_key[2], $array_key[4] ), true ) ) {
                        if ( 0 !== strpos( $value, '/' ) ) {
                            $value = '/' . $value;
                        }

                        wp_delete_file( "{$upload_path['basedir']}$value" );
                    }
                }
            
            
                if ( $update_database ) {
                    unset( $describr_user_profile['avatar'] );
                
                    $this->plugin_update_user_meta( $user_id, $describr_user_profile );
                }
            }
        }
	}
    
    /**
     * Deletes avatar upon plugin deactivation
     * 
     * @param int $user_id User ID
     */
    public function plugin_deactivaton_delete_avatar ( $user_id ) {
        $this->avatar_delete( $user_id, false );
    }

    /**
     * Assign avatar to user
     *
     * @param int|string $media_id Local url for avatar or ID of attachment
     * @param int        $user_id  User ID to whom the image is assigned
     */
    public function assign_avatar ( $media_id, $user_id ) {
        if ( is_numeric( $media_id ) && is_numeric( $user_id ) ) {
            //Delete old avatar     
            $this->avatar_delete( $user_id );
        
            $user = get_user_by( 'id', ( int ) $user_id );

            $describr_user_profile = array();
        
            if ( $user && isset( $user->describr ) ) {
                $describr_user_profile = ( array ) $user->describr;
            }
        
            if ( isset( $describr_user_profile['avatar'] ) ) {
                $avatar = $this->update_user_profile_section_event_log( ( array ) $describr_user_profile['avatar'] );
            } else {
                $avatar = $this->update_user_profile_section_event_log();
            }
        
            $attachment = wp_get_attachment_url( ( int ) $media_id );

            if ( $attachment ) {
                $avatar[ $this->array_keys[0] ] = ( int ) $media_id;

                $upload_path      = wp_upload_dir();
                $avatar_full_path = str_replace( $upload_path['baseurl'], $upload_path['basedir'], $attachment );
                
                $avatar['full'] = $this->avatar_remove_baseurl( $attachment );
                    
                //Get the image WordPress created, and add it to the images associated with the avatar
                $post = get_post_meta( $media_id, '_wp_attachment_metadata' );

                if ( is_array( $post ) && count( $post ) ) {
                    $thumbnailDir = pathinfo( $avatar_full_path, PATHINFO_DIRNAME );
                    $thumbnailDir = rtrim( $thumbnailDir, '/' );

                    $thumbnailURL = pathinfo( $attachment, PATHINFO_DIRNAME );
                    $thumbnailURL = rtrim( $thumbnailURL, '/' );

                    foreach ( $post as $key => $value ) {
                        if ( is_array( $value ) ) {
                            if ( isset( $value['sizes'] ) ) {
                                if ( isset( $value['sizes']['thumbnail'] ) ) {
                                    $thumbnail = $value['sizes']['thumbnail'];
                                    
                                    if ( isset( $thumbnail['file'] ) ) {
                                        $file = '/' . ltrim( $thumbnail['file'], '/' );

                                        $thumbnailDir .= $file;
                            
                                        $thumbnailURL .= $file;
                                    }

                                    if ( file_exists( $thumbnailDir ) ) {
                                        $thumbnailURL = $this->avatar_remove_baseurl( $thumbnailURL );
                                        
                                        //Is there an image on file that is saved by the plugin?
                                        if ( file_exists( $avatar_full_path ) ) {
                                            $size = 0;

                                            if ( isset( $thumbnail['width'] ) ) {
                                                $size = ( int ) $thumbnail['width'];
                                            }
                                            
                                            if ( ! $size ) {
                                                $size = 150;
                                            }

                                            $avatar[ $size ] = $thumbnailURL;
                                        } else {
                                            $avatar['full'] = $thumbnailURL;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                        
                if ( isset( $describr_user_profile['avatar'] ) ) {
                    unset( $describr_user_profile['avatar'] );
                }
                
                $this->plugin_update_user_meta( $user_id, $describr_user_profile , array( 'avatar' => $avatar ) );
            }
        }
    }
    
    /**
     * Removes WordPress baseurl from avatar url, leaving: /YYYY/MM/filename
     * 
     * @param string $path Absolute url path
     * @return string Avatar file path, with everthing before and including `/upload/` removed
     */
    private function avatar_remove_baseurl ( $path = '' ) {
        if ( $path ) {            
            $url_parts = preg_split( '#/uploads/#', ( string ) $path );
            
            if ( 2 === count( $url_parts ) ) {
                $path = '/' . $url_parts[1];
            }
        }

        return $path; 
    }
    
    /**
     * Creates a unique basename for manually uploaded avatars
     *
     * @param  string $dir  File path
     * @param  string $name File name
     * @param  string $ext  File extension (e.g., .jpg)
     * @return string Unique filename
     */
    public function unique_filename_callback ( $dir, $name, $ext ) {
        if ( isset( $this->upload_avatar_user_id ) ) {
            $user = get_user_by( 'id', ( int ) $this->upload_avatar_user_id );
        }            
        
        if ( $user ) {
            $user_name = $user->user_login;
        } else {
            $user_name = $this->time();
        }
            
        $created_filename = $user_name . '_avatar';
        $hashed_filename  = wp_hash( $created_filename );
        $unique_filename  = sanitize_file_name( $hashed_filename );
        $base_filename    = $unique_filename;
            
        $number = 1;

        //Ensure no conflict with existing file names
        while ( file_exists( $dir . "/$unique_filename$ext" ) ) {
            $unique_filename = $base_filename . '_' . $number;

            $number++;
        }

        return $unique_filename . $ext;
    }
    	
    /**
     * Sets the HTML form encoding type that enables avatar upload
     */
    public function user_avatar_edit_form_tag () {
        echo 'enctype="multipart/form-data"';
    }

    /**
     * Carries out post-plugin-activation operations
     * 
     * Registers and adds avatar setting field on Discussion screen
     */
    public function admin_init() {
        //Was the plugin just activated?
        if ( get_option( 'describr_is_activated' ) ) {
            delete_option( 'describr_is_activated' );
            
            $users = get_users();
            
            if ( $users ) {
                foreach ( $users as $user ) {
                    $this->plugin_add_user_meta( $user->ID );
                }
            }
            
            add_option( 'describr_avatars', array( 'only' => 0 ) );
        }
    	
        register_setting( 
            'discussion', 
            'describr_avatars', 
            array( 
                'type'              => 'integer',
                'sanitize_callback' => array( $this, 'sanitize_avatars_option' ),
                'Default'           => 0,
            )
        );
        
        $settings_field_header = $this->plugin_name . ' ' . __( 'Avatar', 'describr' );

        add_settings_field(
			'describr_avatars_only',
			esc_attr( $settings_field_header ),
			array( $this, 'avatar_settings_field' ),
			'discussion',
			'avatars',
            array(
				'key'       => 'only',
                'label_for' => 'describr_avatars',
			)
		);        
    }
    
    /**
	 * Sanitizes avatar option field value before it is saved in the database
	 *
	 * @param  array $input User input
	 * @return array Sanitized input value
	 */
    public function sanitize_avatars_option ( $input ) {
        $new_input = array();

    	$new_input['only'] = isset( $input['only'] ) && in_array( ( int ) $input['only'], $this->user_int, true ) ? ( int ) $input['only'] : 1;

		return $new_input;
    } 

    /**
	 * Echos the HTML input element of type checkbox on the Discussion screen, 
     * enabling the user to set the avatar permission
	 *
	 * @param array $args Avatar setting field arguments
	 */
	public function avatar_settings_field ( $args ) {
		$args = wp_parse_args(
			$args,
			array( 
                'key' => '',
            )
		);
        
        $key = $args['key'];

        if ( ! isset( $this->avatar_permissions[ $key ] ) ) {
			$this->avatar_permissions[ $key ] = 0;
		}
        
        echo '<label>
				<input id="describr_avatars" type="checkbox" name="describr_avatars[' . esc_attr( $key ) . ']" value="1"' . ( 1 === ( int ) $this->avatar_permissions[ $key ] ? ' checked="checked"' : '' ) . '>
				' . esc_html__( 'Use as main Avatar (default to Gravatar)', 'describr' ) . '
			</label>';
	}

    /**
     * Makes directory separator uniform across all operating systems
     * 
     * @param string $path Directory path
     * @return string Directory path, with backslash converted to forward slash
     */
    private function uniform_directory_separator ( $path = '' ) {
        if ( false !== strpos( $path, '\\' ) ) {
            $path = str_replace( '\\', '/', $path );
        }

        return $path;
    }

    /**
     * Validates image
     *
     * @param string $filename The file name of the image to validate
     * @return boolean True if file type is an image, False otherwise
     */
    private function is_image ( $filename = '' ) {
        $file_specs = wp_check_filetype( $filename );

        if ( isset( $file_specs['ext'] ) && is_string( $file_specs['ext'] ) && in_array( mb_strtolower( $file_specs['ext'] ), $this->supported_image_types(), true ) ) {
            return true;
        }
        
        return false;
    }

    /**
     * Validates the part of the image file path that comes after `/uploads`. 
     *
     * @param string $file The file path
     * @return bool True if the path validates, otherwise False
     */
    private function is_image_file_and_path ( $file = '' ) {
        if ( $this->is_image( $file ) ) {
            $file = $this->uniform_directory_separator( $file );

            //Path traversal is not allowed in the part of the path that comes after "/uploads"
            if ( 1 === preg_match( '#\.\.?/#', $file ) ) {
                return false;
            }

            $path_parts = pathinfo( $file );
        
            if ( 1 === preg_match( '#[^a-zA-Z0-9\._/-]#', $path_parts['dirname'] ) ) {
                return false;
            }

            return true;
        } else {
            return false;
        }
    }

    /**
     * Fetches supported image file extensions
     * 
     * @return array Supported image file extensions
     */
    private function supported_image_types () {
        $image_extensions = array();

        $mime_types = preg_grep( '#^(image/)#', wp_get_mime_types() );   

        if ( false === $mime_types ) {
            return array( 
                'jpg',
                'jpeg',
                'jpe',
                'jfif',
                'pjpeg',
                'pjp',
                'gif',
                'png',
                'apng',
                'webp',
                'svg',
                'avif', 
                'heic', 
                'bmp', 
                'tiff', 
                'tif', 
            );
        }
        
        $mime_types = array_keys( $mime_types );

        foreach ( $mime_types as $key => $value ) {
            if ( false === strpos( $value, '|' ) ) {
                $image_extensions[] = $value;
            } else {
                $image_extensions = array_merge( $image_extensions, explode( '|', $value ) );
            }
        }

        return $image_extensions;
    }

    /**
     * Adds to WP_Error object error messages that might be encountered when updating a user profile section
     *
     * @param WP_Error object $errors Error messages
     */
    public function user_profile_update_errors ( WP_Error $errors ) {
        if ( is_array( $this->profile_update_errors ) && count( $this->profile_update_errors ) ) {
            foreach ( $this->profile_update_errors as $user_profile_section => $error ) {
                $errors->add( "describr_{$user_profile_section}", wp_kses( $error , array( 'strong' => array() ) ) );
            }
        }
    }    

    /**
     * Adds Publish/Unpublish options to bulk actions menu on users screen 
     *
     * @param array $actions Actions menu
     * @return array Actions menu with new options added
     */
    public function bulk_actions ( $actions ) {
        if ( $this->can_edit_profiles() ) {
            $actions['describr_publish']   = esc_html__( 'Publish', 'describr' ); 
    		$actions['describr_unpublish'] = esc_html__( 'Unpublish', 'describr' );
    	}
        
       	return $actions;
    }
      
    /**
     * Processes publish/unpublish bulk actions generated on users screen
     *
     * @param string $redirect_to The redirect url
     * @param string $doaction    The action being taken
     * @param array $user_ids     User IDs
     * @return string Redirect url 
     */
    public function bulk_actions_handler ( $redirect_to, $doaction, $user_ids ) {
        $notice = 'fail';

        if ( $this->can_edit_profiles() ) {
            foreach( $user_ids as $key => $value ) {
                $user_id = ( int ) $value;
    			$user    = get_user_by( 'id', $user_id );

                if ( $user ) {
                    if( 'describr_publish' === ( string ) $doaction ) {
                        update_user_meta( $user_id, 'describr_published', 1, 0 );
            	    } elseif ( 'describr_unpublish' === ( string ) $doaction ) {
                        update_user_meta( $user_id, 'describr_published', 0, 1 );
            	    }
            	}
            }
    		
            $notice = 'success';
        }    
        
        return add_query_arg( 'manage_privilege', $notice, $redirect_to );
    }

    /**
     * Sets plugin admin notices
     */
    public function admin_notices () {
        if ( isset( $_GET['page'] ) && 'describr' === ( string ) sanitize_text_field( $_GET['page'] ) ) {
            settings_errors();
    	}

    	if ( isset( $_GET['manage_privilege'] ) ) {
            $message = __( 'Changes saved successfully.', 'describr' );
    		
            $class  = 'success';

    		if ( 'fail' === ( string ) sanitize_text_field( $_GET['manage_privilege'] ) ) {
                $message = __( 'Failed to save changes. Please try again.', 'describr' );
    			$class   = 'error';
            }

    		echo '<div class="notice notice-' . esc_attr( $class ) . ' is-dismissible"> 
	                 <p><strong>' . esc_html( $message ) . '</strong></p>
	                 <button type="button" class="notice-dismiss">
		                   <span class="screen-reader-text">' . esc_html__( 'Dismiss this notice.', 'describr' ) . '</span>
	                 </button>
                 </div>';
    	}
    }
    
    /**
     * Adds plugin-specific columns to Users screen 
     *
     * @param array $columns Existing columns
     * @return array Pre-existing and new columns
     */
    public function customize_user_columns ( $columns ) {
        $columns['describr_published']  = esc_html__( 'Published', 'describr' );
        $columns['describr_reg_date']   = esc_html__( 'Registration Date', 'describr' );
        $columns['describr_last_login'] = esc_html__( 'Last Login', 'describr' );
        
        return $columns;
    }

    /**
     * Adds table data to the table on Users screen
     *
     * @param string $val     Existing table data
     * @param string $column  Column being operated on
     * @param int    $user_id User ID
     * @return string Updated table data
     */
    public function costumize_user_columns_data ( $table_data, $column, $user_id ) {
        $user = get_userdata( ( int ) $user_id );

        if ( ! $user ) {
            return $table_data;
        }

        if ( 'describr_published' === ( string ) $column ) {
            $published = isset( $user->describr_published ) ? ( int ) $user->describr_published : 1;
            
            $table_data .= '<span class="dashicons-before dashicons-' . ( $published ? 'yes' : 'no-alt' ) . '"></span>';
        } elseif ( 'describr_reg_date' === ( string ) $column ) {
        	$table_data .= esc_html( $this->datetime( $user->user_registered ) );
        } elseif ( 'describr_last_login' === ( string ) $column ) {
            $sessions = WP_Session_Tokens::get_instance( $user_id );
            
            if ( isset( $user->describr_last_login ) ) {
                $table_data .= '<div>' . esc_html( $this->datetime( $user->describr_last_login ) ) . '</div>';
        	}

        	if ( count( $sessions->get_all() ) ) {
                $table_data .= '<div class="describr__users__login"><span title="';
                $table_data .= esc_html(sprintf(
                    /*translators: %s: User's name*/
                    __( '%s Is Logged In', 'describr' ),
                    $this->username_to_use( $user )     
                ));
                $table_data .= '" class="dashicons-before dashicons-unlock"></span></div>';
        	}
        }
    	
    	return $table_data;
    }

    /**
     * Sets plugin-related columns that should be sortable on Users screen
     *
     * @var array $columns Sortable columns
     * @return array Sortable columns
     */
    public function users_sortable_columns ( $columns ) {
       if ( is_array( $columns ) ) {
            $columns['describr_reg_date']   = 'describr_reg_date';
            $columns['describr_published']  = 'describr_published';
            $columns['describr_last_login'] = 'describr_last_login';
        }
        
        return $columns;
    }
    
    /**
     * Creates user-friendly UTC offset
     * 
     * Credit WordPress wp_timezone_string function
     * 
     * @param float $offset The UTC offset
     * @return string user-friendly UTC
     */
    public function utc_user_friendly ( $offset = 0 ) {
        $offset  = ( float ) $offset;
        $hours   = ( int ) $offset;
        $minutes = ( $offset - $hours );
 
        $sign      = ( $offset < 0 ) ? '-' : '+';
        $abs_hour  = abs( $hours );
        $abs_mins  = abs( $minutes * 60 );

        return sprintf( '%s%02d:%02d', $sign, $abs_hour, $abs_mins );
    }

    /**
     * Checks if UTC exists
     * 
     * @param string $utc The UTC to check against
     * @return string|bool The existent UTC, False otherwise
     */
    private function get_utc ( $utc = '' ) {
        $utc_range = array(
            -12, 
            -11.5, 
            -11, 
            -10.5, 
            -10, 
            -9.5, 
            -9, 
            -8.5, 
            -8, 
            -7.5, 
            -7, 
            -6.5, 
            -6, 
            -5.5, 
            -5, 
            -4.5, 
            -4, 
            -3.5, 
            -3, 
            -2.5, 
            -2, 
            -1.5, 
            -1, 
            -0.5, 
            0, 
            0.5, 
            1, 
            1.5, 
            2, 
            2.5, 
            3, 
            3.5, 
            4, 
            4.5, 
            5, 
            5.5, 
            5.75, 
            6, 
            6.5,
            7, 
            7.5, 
            8, 
            8.5, 
            8.75, 
            9, 
            9.5, 
            10, 
            10.5, 
            11, 
            11.5, 
            12, 
            12.75, 
            13, 
            13.75, 
            14,
        );

        foreach ( $utc_range as $key => $value ) {
            if ( ( string ) $utc === ( string ) $value ) {
                return $utc; 
            }
        }

        return false;
    }

    /**
     * Validates UTC
     * 
     * @param string $utc The UTC to validate
     * @return string|bool True if the UTC was found, False otherwise
     */
    private function is_utc ( $utc = '' ) {
        return false !== $this->get_utc( $utc );
    }
    
    /**
     * Checks if time zone exists
     * 
     * @param string $timezone                  The time zone for which to search
     * @param bool   $return_false_if_not_found Whether to return False if time zone is not found
     * @return string|bool The time zone in question, otherwise False if the second argument is set to True. 
     */
    public function get_timezone ( $timezone = '', $return_false_if_not_found = false ) {
        $timezone_list = timezone_identifiers_list();

        foreach ( $timezone_list as $key => $value ) {
            if ( ( string ) $timezone === ( string ) $value ) {
                return $timezone ;
            }
        } 
        
        if ( $return_false_if_not_found ) {
            return false;
        }

        return $timezone ;
    } 

    /**
     * Fetches the time zone or UTC used to format the datetime shown to users.
     * 
     * Defaults to the site's time zone.  
     *
     * @param string $timezone_or_utc User-supplied time zone or UTC offset
     * @return string Time zone or UTC (in dd:dd format)
     */
    private function timezone_to_use ( $timezone_or_utc = '' ) {
        $timezone_or_utc = $this->get_timezone( $timezone_or_utc );

        if ( $timezone_or_utc ) {
            return $timezone_or_utc;
        } else {
            $timezone_or_utc = $this->get_utc( $timezone_or_utc );

            if ( false !== $timezone_or_utc ) {
                return $this->utc_user_friendly( $timezone_or_utc );
            }
        }

        return wp_timezone_string();
    }

    /**
     * Validates time zone
     * 
     * @param string $timezone The time zone to validate
     * @return bool True if the time zone is found in PHP's timezone_identifiers_list(), False otherwise
     */
    private function is_timezone ( $timezone = '' ) {
        return false !== $this->get_timezone( $timezone, true );
    }
    
    /**
     * Casts to int what is returned by PHP's time function
     * 
     * @return int
     */
    private function time () {
        return ( int ) time();
    }
    
    /**
     * Creates user-friendly date and time
     *
     * @param int|string $timestamp Timestamp
     * @param string     $timezone  Time zone
     * @param string     $format    Date format
     * @return Formatted date.
     */
    private function datetime ( $timestamp = '', $timezone = '', $format = '' ) {
        if ( $this->empty( $timezone ) ) {
            $timezone = $this->timezone_to_use();
        }

    	if ( ! $format ) {
            /*translators: draft saved date format, see http://php.net/date*/
            $format = __( 'F j, Y h:i A', 'describr' );
        }

        $datetime = new DateTime( 'now', new DateTimeZone( ( string ) $timezone ) );
        
        if ( is_numeric( $timestamp ) ) {
            $timestamp = ( int ) $timestamp;
        } elseif ( is_string( $timestamp ) ) {
            $timestamp = strtotime( $timestamp );
        } else {
            $timestamp = $this->time();
        }

        $datetime->setTimestamp( $timestamp );
        
        return $datetime->format( ( string ) $format );
    }
    
    /**
     * Validates datetime
     * 
     * @param string $date The date to validate
     * @return bool True if the date is valid, False otherwise
     */
    private function is_date ( $date = '' ) {
        return 1 === preg_match( '/^[0-9]{4}(\-[0-9]{2})?(\-[0-9]{2})?$/', ( string ) $date );
    }

    /**
     * Creates string representation of partial, numeric date saved by the user
     * 
     * @param string $date The date in question
     * @return string A string representation of the date
     */
    public function create_date ( $date = '' ) {
        if ( $this->is_date( $date ) ) {
            $date_count = count( explode( '-', $date ) );

            if ( 3 === $date_count ) {
                /*translators: draft saved date format, see http://php.net/date*/
                $format = __( 'M j, Y', 'describr' );
            } elseif ( 2 === $date_count ) {
                /*translators: draft saved date format, see http://php.net/date*/
                $format = __( 'M Y', 'describr' );
            
                $date .= '-01';
            } else {
                /*translators: draft saved date format, see http://php.net/date*/
                $format = __( 'Y', 'describr' );

                $date .= '-01-01';
            }

            $strtotime = strtotime( $date );
        
            if ( $strtotime ) {
                return gmdate( $format, $strtotime );
            }
        }

        return '';
    }       
    
    /**
     * user_register hook callback function
     * 
     * Sets user meta upon new-user registration
     *
     * @param int   $user_id  User ID
     * @param array $userdata User data
     */
    public function user_register ( $user_id, $userdata ) {
        $this->plugin_add_user_meta( $user_id, $userdata );
    }
    
    /**
     * delete_user hook callback function
     * 
     * Deletes the user's avatar from the filesystem just before the account is deleted
     * 
     * @param int $user_id User ID
     */
    public function delete_user ( $user_id ) {
        $this->avatar_delete( $user_id, false );
    }

    /**
     * wp_login hook callback function
     * 
     * Updates the user's last log-in date and time
     *
     * @param string         $user_login Login name
     * @param WP_User object $user       User info       
     */
    public function logged_in ( $user_login, $user ) {
        update_user_meta( ( int ) $user->ID, 'describr_last_login', $this->time() );
    }
    
    /**
     * Updates plugin's main user meta
     *
     * @param int   $user_id      User ID
     * @param array $old_userdata Old user data
     * @param array $new_userdata New user data
     */
    private function plugin_update_user_meta ( $user_id, $old_userdata, $new_userdata = array() ) {
        if ( is_array( $old_userdata ) ) {
            if ( is_array( $new_userdata ) && count( $new_userdata ) ) {
                $old_userdata = array_merge_recursive( $old_userdata, $new_userdata );
            }
        
            update_user_meta( ( int ) $user_id, 'describr', $this->sanitize_user_input( $old_userdata ) );
        }
    }
    
    
    /**
     * Sanitizes array contents that will be saved in the database
     * 
     * @param array $array_to_sanitize The array to sanitize
     * @return array The sanitized array or an empty array if $array_to_sanitize is not an array
     */
    private function sanitize_user_input ( $array_to_sanitize ) {
        $array_key = $this->array_keys;

        foreach ( $array_to_sanitize as $array_to_sanitize_key => &$array_to_sanitize_value ) {
            if ( is_array( $array_to_sanitize_value ) ) {
                $array_to_sanitize_value = $this->sanitize_user_input( $array_to_sanitize_value );
            } else {
                /*Sanitize avatar data. If the array contains avatar data, the key "full" ($array_key[3]) should be set*/
                if ( isset( $array_to_sanitize[ $array_key[3] ] ) && ! in_array( $array_to_sanitize_key, array( $array_key[0], $array_key[1], $array_key[2] ), true ) ) {
                    //Validate the file path
                    if ( $this->is_image_file_and_path( $array_to_sanitize_value ) ) {
                        $path_parts = pathinfo( $this->uniform_directory_separator( $array_to_sanitize_value ) );

                        $array_to_sanitize_value = rtrim( $path_parts['dirname'], '/' ) . '/' . sanitize_file_name( $path_parts['basename'] );
                    } else {
                        unset( $array_to_sanitize[ $array_to_sanitize_key ] );
                        continue;
                    }
                }
                
                //Sanitize anything that is destined for the database
                $array_to_sanitize_value = sanitize_text_field( $array_to_sanitize_value );
            }
        }
        
        return $array_to_sanitize;
    }

    /**
     * Removes duplicate values from array, irrespective of case, and reindexes array
     * 
     * @param array $array The array in question
     * @return array Array containing unique values
     */
    private function unique_array_values ( $array = array() ) {
        if ( is_array( $array ) && ! empty( $array ) ) {
            $lowered_values = map_deep( $array, 'mb_strtolower' );

            $array_unique = array_intersect_key( $array, array_unique( $lowered_values ) );

            return array_values( $array_unique );
        }

        return $array;
    }
    
    /**
     * Checks if array is a duplicate
     * 
     * @param array $haystack The array that stores potentially duplicate arrays
     * @param array $needle   The duplicate array
     * @return bool True if the array is a duplicate, otherwise False
     */
    private function is_duplicate_array ( $haystack, $needle ) {
        $haystack = map_deep( $haystack, 'mb_strtolower' );
        $needle   = map_deep( $needle, 'mb_strtolower' );

        return in_array( $needle, $haystack, true );
    }

    /**
     * Sanitizes urls
     * 
     * @param string $user_url Url
     * @return string|bool The sanitized url, or False if the url is invalid
     */
    private function validate_url ( $user_url = '' ) {
        if ( empty( $user_url ) ) {
            return false;
        }

        if ( 1 !== preg_match( '/^(https?:\/\/)/', ( string ) $user_url ) ) {
            $user_url = 'http://' . $user_url;
        }

        $parsed_url = wp_parse_url( $user_url );
                                        
        if ( false !== $parsed_url && isset( $parsed_url['host'] ) && 1 === preg_match( '/[a-z0-9\.-]{3,}\.[a-z]{2,}(\.[a-z]{2,})?/i', $parsed_url['host'] ) ) {
            $href = '';

            if ( isset( $parsed_url['scheme'] ) && in_array( $parsed_url['scheme'], array( 'http', 'https' ), true ) ) {
                $href = $parsed_url['scheme'];
            }

            if ( ! $href ) {
                $href = 'http';
            }

            $href .= '://';
                
            $href = $href . $parsed_url['host'];

            if ( isset( $parsed_url['path'] ) && '' !== ( string ) $parsed_url['path'] ) {
                $href .= '/' . rawurlencode( ltrim( $parsed_url['path'], '/' ) );
            }

            if ( isset( $parsed_url['query'] ) && '' !== ( string ) $parsed_url['query'] ) {
                $href .= '?' . rawurlencode( $parsed_url['query'] );
            }

            if ( isset( $parsed_url['fragment'] ) && '' !== ( string ) $parsed_url['fragment'] ) {
                $href .= '#' . rawurlencode( $parsed_url['fragment'] );
            }

            return $href;
        }

        return false;
    }
    
    /**
     * Checks whether the type of data is string or number
     * 
     * @param string $string The variable to check
     * @return bool True if variable type is string or number, otherwise false
     */
    private function is_string_or_numeric ( $string = '' ) {
        if ( ! is_string( $string ) && ! is_numeric( $string ) ) {
            return false;
        }

        return true;
    }
    
    /**
     * Determines whether the prefix assigned to the database's table's names is valid
     * 
     * @return bool True if prefix is valid, otherwise False
     */
    private static function is_wpdb_prefix () {
        global $wpdb;

        if ( ! isset( $wpdb->prefix ) || 1 === preg_match( '/[^a-zA-Z0-9_]/', $wpdb->prefix ) ) {
            return false;
        }

        return true;
    }

    /**
     * Chooses the most appropriate name for the user: first name, first name and last name, login
     * name, nicename, or display name, in that order
     *
     * @param WP_User object User info
     * @return string Best available name for the user, or empty string
     */
    private function username_to_use ( $user ) {
        $name = '';

        if ( is_object( $user ) ) {
            $user = map_deep( $user, 'trim' );

            if ( isset( $user->describr ) && isset( $user->describr['badge'] ) ) {
                $badge = ( array ) $user->describr['badge'];

                if ( $this->user_profile_section_permission( $badge, $user->ID ) ) {
                    if ( isset( $badge['first_name'] )  && ! $this->empty( $badge['first_name'] ) ) {
                        $name = $badge['first_name'];

                        if ( isset( $badge['last_name'] ) && ! $this->empty( $badge['last_name'] ) ) {
                            $name .= ' ' . $badge['last_name'];
                        }

                        return sprintf(
                            '%s', 
                            $name 
                        );
                    }
                } else {
                    return $name;
                }
            }
        
            if ( isset( $user->first_name ) && ! $this->empty( $user->first_name ) ) {
                $name = $user->first_name;

                if ( isset( $user->last_name ) && ! $this->empty( $user->last_name ) ) {
                    $name .= ' ' . $user->last_name;
                }

                $name = sprintf(
                    '%s', 
                    $name                                            
                ); 
            } elseif ( isset( $user->display_name ) && ! $this->empty( $user->display_name )) {
                $name = sprintf(
                    '%s',
                    $user->display_name
                );
            } elseif ( isset( $user->user_nicename ) && ! $this->empty( $user->user_nicename ) ) {
                $name = sprintf(
                    '%s',
                    $user->user_nicename
                );
            } elseif ( isset( $user->user_login ) && ! $this->empty( $user->user_login ) ) {
                $name = sprintf(
                    '%s',
                    $user->user_login
                );
            } elseif ( isset( $user->nickname ) && ! $this->empty( $user->nickname ) ) {
                $name = sprintf(
                    '%s',
                    $user->nickname
                );
            }
        }

        return $name;
    }

    /**
     * Gives developers access to override who (except the user whose profile is being edited)
     * can edit the user profile
     * 
     * @return bool
     */
    private function can_edit_profiles () {
        return apply_filters( 'describr_can_edit_profiles', current_user_can( 'edit_others_posts' ) );
    }
    
    /**
     * Gives developers access to override who can upload avatar
     * 
     * @return bool
     */
    private function can_upload_files () {
        return apply_filters( 'describr_can_upload_files', current_user_can( 'upload_files' ) );
    }
    
    /**
     * Removes array keys whose values are empty
     * 
     * @param array $array The array whose empty keys are to be removed
     * @return array The array, with keys whose values are empty removed
     */
    private function unset_empty_array_key ( $array ) {
        foreach( $array as $array_key => &$array_value ) {
            if ( is_array ( $array_value ) ) {
                if ( count( $array_value ) ) {
                    $array_value = $this->unset_empty_array_key( $array_value );
                } else {
                    unset( $array[ $array_key ] );
                }
            } elseif ( $this->empty( $array_value ) ) {
                unset( $array[ $array_key ] );
            }
        }

        return $array;
    }
    
    /**
     * Removes array's last key if its value is empty
     * 
     * @param array $array The array whose last key is to be removed
     * @return array The array, with last key whose value is empty removed
     */
    private function remove_empty_last_key_from_array ( &$array ) {
        $last_value = end( $array );

        reset( $array );

        if ( is_array( $last_value ) ) {
            if ( 0 === count( $last_value ) ) {
                array_pop( $array );
            }
        } elseif ( $this->empty( $last_value ) ) {
            array_pop( $array );
        }
    }

    /**
     * Stores plugin filters that restrict the size of strings and arrays submitted by users.
     * 
     * @return array {
        int tagline     Maximum number of characters allowed in tagline
     *  int textbox     Maximum number of characters allowed in strings
     *                  submitted by the way of HTML input elements of type text
     *  int textarea_LG Maximum number of characters allowed in strings
     *                  submitted by the way of large HTML textarea elements
     *  int textarea_SM Maximum number of characters allowed in strings 
     *                  submitted by the way of small HTML textarea elements
     *  int phone       Maximum number of characters allowed in phone numbers 
     *  int url         Maximum number of characters allowed in urls
     *  int arraysize   Maximum number of array elements a user can submit
     * }
     */
    private function maxlen () {
        return array(
            'tagline'     => apply_filters( 'describr_maxlen_tagline', 20 ),
            'textbox'     => apply_filters( 'describr_maxlen_textbox', 150 ),
            'textarea_LG' => apply_filters( 'describr_maxlen_textarea_LG', 1000 ),
            'textarea_SM' => apply_filters( 'describr_maxlen_textarea_SM', 300 ),
            'phone'       => apply_filters( 'describr_maxlen_phonenumber', 50 ),
            'url'         => apply_filters( 'describr_maxlen_url', 100 ),
            'arraysize'   => apply_filters( 'describr_maxlen_arraysize', 10 ),
        );
    }

    /**
     * Checks if a string is empty
     * 
     * @param string $string The string to check
     * @return bool True if the string contains only white space or is NULL, otherwise False
     */
    private function empty ( $string = '' ) {
        if ( is_null( $string ) ) {
            return true;
        } elseif ( 1 === preg_match( '/[^\s]+/', ( string ) $string ) ) {
            return false;
        }

        return true;
    }
    
    /**
     * Checks if the current user is authorized to view a section of the user profile
     * 
     * @param array $user_profile_section User profile section
     * @param int   $user_id              User ID belonging to the owner of the profile
     * @return bool True if the current user is authorized to view the section of the profile, otherwise False
     */
    private function user_profile_section_permission ( $user_profile_section, $user_id ) {
        if ( isset( $user_profile_section[ $this->array_keys[1] ] ) ) {
            if ( in_array( ( int ) $user_profile_section[ $this->array_keys[1] ], $this->user_int, true ) ) {
                $user_profile_section_approval_status = ( int ) $user_profile_section[ $this->array_keys[1] ];
            } else {
                $user_profile_section_approval_status = 0;
            }
        } else {
            $user_profile_section_approval_status = 1;
        }

        if ( isset( $user_profile_section[ $this->array_keys[2] ] ) ) {
            if ( in_array( ( int ) $user_profile_section[ $this->array_keys[2] ], $this->user_int, true ) ) {
                $user_profile_section_privacy_status = ( int ) $user_profile_section[ $this->array_keys[2] ];
            } else {
                $user_profile_section_privacy_status = 0;
            }
        } else {
            $user_profile_section_privacy_status = 1;
        }

        if ( ( ! $user_profile_section_approval_status || ! $user_profile_section_privacy_status ) && ( ! $this->can_edit_profiles() && ! current_user_can( 'edit_user', ( int ) $user_id ) ) ) {
            return false;
        }

        return true;
    }
}