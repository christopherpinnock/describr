<?php
class Describr {
    /**
     * Plugin's name
     *
     * @var string
     */
    public static $plugin = 'describr';
    
    /**
	 * Plugin's name, capitalized
     *
	 * @var string
	 */
	public $plugin_name;

	/**
     * Plugin's root url
     *
     * @var string
     */
    public $plugin_url;
    
    /**
     * Stores the avatar's option, indicating whether the plugin must use the default photo if no photo has been
     * uploaded
     *
     * @var array
     */
    public $avatar_permissions;

    /**
     * Stores errors that may arise while updating user profile
     *
     * @var array
     */
    public $profile_update_errors = array();
    
    /**
     * User ID to whom the uploaded avatar belongs
     *
     * @var int
     */
    public $upload_avatar_user_id;

    /**
     * Default avatar
     *
     * @var string
     */
    public $avatar_default; 

    /**
     * Avatar sizes
     *
     * @var array
     */
    public $avatar_sizes = array( 150, 300, 768, 1024 );
    /**
     * Types of image files supported.
     * 
     * @var array
     */
    private $supported_image_types = array( 'jpg','jpeg','jpe','jfif','pjpeg','pjp','gif','png','apng','webp','svg','avif' );

    /**
     * UTC manual offsets
     *
     * @var array
     */
    private $utc_range = array( -12, -11.5, -11, -10.5, -10, -9.5, -9, -8.5, -8, -7.5, -7, -6.5, -6, -5.5, -5, -4.5, -4, -3.5, -3, -2.5, -2, -1.5, -1, -0.5, 0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 5.75, 6, 6.5,
        7, 7.5, 8, 8.5, 8.75, 9, 9.5, 10, 10.5, 11, 11.5, 12, 12.75, 13, 13.75, 14
    );
    
    /**
     * Array key for storing the privacy setting for a profile section
     * @var string
     */
    public static $visibility_key = 'visibility';

    /**
     * Array key for storing the published setting for a profile section
     * @var string
     */
    public static $approval_key = 'approved';
    
    /**
     * Array key for storing the event log of a profile section
     * @var string
     */
    public $event = 'updated_by';

	public function __construct() {
        $this->avatar_default     = $this->get_default_avatar();
        $this->avatar_permissions = ( array ) get_option( self::$plugin . '_avatars' );
		$this->plugin_name        = ucfirst( self::$plugin );
		$this->plugin_url         = plugins_url( '', __FILE__ ) . '/';
                
        $this->add_hooks();
	}

    /**
     * Adds callback functions to action hooks
     */
    public function add_hooks () {
        add_action( 'user_register', array( $this, 'user_register'), 10, 2 );
        add_action( 'delete_user', array( $this, 'delete_user' ), 10, 1 );

        add_action( 'init', array( $this, 'init' ) );
        add_action( 'admin_init', array( $this, 'admin_init' ) );
        add_action( 'admin_notices', array( $this, 'admin_notices' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts'), 10, 1 );
        
        add_action( 'wp_ajax_remove-avatar', array( $this, 'action_remove_avatar' ) );
        add_action( 'wp_ajax_assign-avatar', array( $this, 'action_assign_avatar' ) );

        add_action( 'rest_api_init', array( $this, 'rest_api_init' ) );
        
        add_action( 'show_user_profile', array( $this, 'show_user_profile' ), 10, 1 );
        add_action( 'edit_user_profile', array( $this, 'show_user_profile' ), 10, 1 );
        
        add_action( 'personal_options_update', array( $this, 'edit_user_profile' ), 10, 1 );
        add_action( 'edit_user_profile_update', array( $this, 'edit_user_profile' ), 10, 1 );
        add_action( 'user_profile_update_errors', array( $this, 'user_profile_update_errors' ), 10, 1 );
        
        add_action( 'wp_login', array( $this, 'logged_in' ), 101, 2 );
        
        add_action( 'user_edit_form_tag', array( $this, 'user_avatar_edit_form_tag' ) );

        add_filter( 'bulk_actions-users', array( $this, 'bulk_actions' ), 10, 1 );
        add_filter( 'handle_bulk_actions-users', array( $this, 'bulk_actions_handler' ), 10, 3 );
        
        add_filter( 'manage_users_columns', array( $this, 'customize_user_columns'), 10, 1 );
        add_filter( 'manage_users_custom_column', array( $this, 'costumize_user_columns_data' ), 10, 3 );
        add_filter( 'manage_users_sortable_columns', array( $this, 'users_sortable_columns' ), 10, 1 );

        add_filter( 'pre_get_avatar_data', array( $this, 'get_avatar_data' ), 10, 2 );
        add_filter( 'get_avatar', array( $this, 'get_avatar' ), 10, 6 );
        
        //Plugin-specific filter that allows dynamic resizing of avatars
        add_filter( 'describr_avatars_dynamic_resize', array( $this, 'avatar_dynamic_resize' ), 10, 1 );
    }  

    /**
     * Enqueues admin scripts
     *
     * @param string $hook_suffix the filename of the currently executing script
     */
	public function admin_scripts ( $hook_suffix ) {
        $version    = false;
        $dependency = null;      
        
        if ( 'profile.php' == $hook_suffix || 'user-edit.php' == $hook_suffix || 'users.php' == $hook_suffix ) {

            $plugin = self::$plugin;

            $supporting_scripts = $plugin . '-';

            $js_filepath  = $this->plugin_url . 'js/';
            $css_filepath = $this->plugin_url . 'css/';
                
            $min     = '.min.';
            $min_js  = $min . 'js';
            $min_css = $min . 'css';

            if ( 'profile.php' == $hook_suffix || 'user-edit.php' == $hook_suffix ) {
                $profile = array();

                $main_scripts = $supporting_scripts . 'js-main';

                $can_upload = current_user_can( 'upload_files' );

                $current_user = get_current_user_id();
                
                if ( $can_upload ) {
                    //Enqueue scripts needed to use WordPress' media library.
                    wp_enqueue_media();
                }
                
                $rest_url = rest_url( 'describr/v1/partner' );
                $rest_url = esc_url( $rest_url );

                $plugin_javascript = array(
                    'isMobile'   => wp_is_mobile(),
                    'avatarPerm' => isset( $this->avatar_permissions['only'] ) ? $this->avatar_permissions['only'] : 0,
                    'pluginName' => esc_html( $this->plugin_name ),
                    'isEditor'   => current_user_can( 'edit_others_posts' ),
                    'canUpload'  => $can_upload,
                    'loadMedia'  => did_action( 'wp_enqueue_media' ),
                    'curUser'    => $current_user,
                    'adminUrl'   => get_admin_url(),
                    'rootUrl'    => home_url( '/' ),
                    'nonceRest'  => wp_create_nonce( 'wp_rest' ),
                    'siteName'   => get_bloginfo(),
                    'utcOff'     => $this->utc_range,
                    'restURL'    => $rest_url,
                );

                if ( isset( $_GET['user_id'] ) ) {
                    $user_id = ( int ) $_GET['user_id'];
                } else {
                    $user_id = $current_user;
                }

                $user_info = get_userdata( $user_id );
    
                if ( $user_info ) {
                    $profile = $this->profile_info( $user_info );
                } else {
                    $profile = $this->profile_info();
                }
                
                $plugin_javascript['profile'] = $profile;

                if ( $can_upload ) {
                    $plugin_javascript['avatar'] = array(
                        'user_id'       => $user_id,
                        'deleteNonce'   => wp_create_nonce( $plugin . '_remove_avatar_nonce' ),
                        'updateNonce'   => wp_create_nonce( $plugin . '_assign_from_media_library_avatar_nonce' ),
                        'defaultAvatar' => $this->avatar_default,
                        'fileSpecs'     => array(
                            'type'         => 'jpg, jpeg, jpe, gif, png',
                            'limit'        => wp_max_upload_size(),
                            'limitDisplay' => $this->display_max_upload_size(),
                        ),
                    );
                }

                //CSS for jQuery UI components
                wp_enqueue_style( $supporting_scripts . 'css-jquery-ui', $css_filepath . 'jquery-ui/jquery-ui' . $min_css, $dependency );
                wp_enqueue_style( $supporting_scripts . 'css-jquery-ui-structure', $css_filepath . 'jquery-ui/jquery-ui.structure' . $min_css, $dependency );
                wp_enqueue_style( $supporting_scripts . 'css-jquery-ui-theme', $css_filepath . 'jquery-ui/jquery-ui.theme' . $min_css, $dependency );

                //Load both autocomplete() and selectmenu() jQuery UI methods.
                wp_enqueue_script( 'jquery-ui-autocomplete' );
                wp_enqueue_script( 'jquery-ui-selectmenu' );

                //The libphonenumber library enables the verifying of phone numbers
                wp_enqueue_script( $supporting_scripts .'js-libphonenumber', $js_filepath . 'libphonenumber.js', $dependency,  $version );
             
                //Languages
                wp_enqueue_script( $supporting_scripts . 'js-langs', $js_filepath . 'langs' . $min_js, $dependency,  $version );

                //Time zones
                wp_enqueue_script( $supporting_scripts . 'js-datetime', $js_filepath . 'timezone' . $min_js, $dependency, $version );
            
                //All cities in the world
                wp_enqueue_script( $supporting_scripts . 'js-cities', $js_filepath . 'cities' . $min_js, $dependency, $version  );

                //All countries and states in the world
                wp_enqueue_script( $supporting_scripts . 'js-country-state', $js_filepath . 'country-state' . $min_js, $dependency, $version  );
                
                //Plugin's main JavaScript file
                wp_enqueue_script( $main_scripts, $js_filepath . 'script' . $min_js, array( 'jquery', 'wp-i18n' ), $version, true );
               
               //Some JavaScript objects on which the main JavaScript depends
                wp_localize_script( $main_scripts, $plugin, $plugin_javascript );
                
                //JavaScript object containing translated texts
                wp_localize_script( $main_scripts, $plugin . 'i18n', $this->translation_javascript() );
            }//if ( 'profile.php' == $hook_suffix || 'user-edit.php' == $hook_suffix ) {
            
            //Plugin's main CSS
            wp_enqueue_style( $supporting_scripts . 'css-main', $css_filepath . 'styles' . $min_css, $dependency, $version );
        }
    }

	/**
	 * Activates plugin by hooking to activate_PLUGIN action via register_activation_hook()
	 *
     * @static
	 */
	public static function plugin_activation () {
        if ( ! empty( $_SERVER['SCRIPT_NAME'] ) && false !== strpos( $_SERVER['SCRIPT_NAME'], '/wp-admin/plugins.php' ) ) {
            //In the admin_init callback, we check if this option is set after activation of the plugin is completed.
            add_option( self::$plugin . '_is_activated', true );
        }
	}

    /**
     * Removes plugin-specific options and usermetas
     * 
     * @static
     */
    public static function plugin_deactivation () {
        global $wpdb;
        
        $plugin_usermetas = self::$plugin . '_';

        if ( false === delete_option( $plugin_usermetas . 'avatars' ) ) {
            delete_option( $plugin_usermetas . 'avatars' );
        }
        
        foreach ( get_users() as  $user ) { 
            self::avatar_delete( $user->ID, false );//Delete avatar from upload folder.
        }
        
        //Delete all rows this plugin added to the wp_usermeta table.
        $wpdb->query("DELETE FROM {$wpdb->prefix}usermeta WHERE meta_key IN ('{$plugin_usermetas}last_login', '{$plugin_usermetas}published', '" . self::$plugin . "', '{$plugin_usermetas}reg_date')");
    }

    /**
     * Saves some user data that the user can be included in the profile
     * 
     * @param int $user_id The ID of the user
     * @param array $userdata The raw array of data passed to wp_insert_user()
     */
    public function plugin_user_meta ( $user_id, $userdata = array() ) {
        $plugin_metas = self::$plugin . '_';

        $current_user = get_current_user_id();

        if ( $userdata ) {
            $userdata = ( object ) $userdata;
        } else {
            $userdata = get_userdata( $user_id );
        
            if ( ! $userdata ) {
                return;
            }
        }
                
        $privacy_key            = self::$visibility_key;
        $approval_key           = self::$approval_key;
        $event_log_key          = 'updated_by';
        $badge_key              = 'badge';
        $timezone_key           = 'timezone';
        $user_login             = $userdata->user_login;
        $event_user_id_and_time = array( $current_user . '__' . time() ) ;
        $plugin_userdata        = array();
        
        $plugin_userdata[ $badge_key ]['username']       = $this->sanitize_txt( $user_login );
        $plugin_userdata[ $badge_key ][ $privacy_key ]   = 1;
        $plugin_userdata[ $badge_key ][ $approval_key ]  = 1;
        $plugin_userdata[ $badge_key ][ $event_log_key ] = $event_user_id_and_time;

        $plugin_userdata[ $timezone_key ]['name']           = $this->default_timezone_or_utc();
        $plugin_userdata[ $timezone_key ][ $privacy_key ]   = 1;
        $plugin_userdata[ $timezone_key ][ $approval_key ]  = 1;
        $plugin_userdata[ $timezone_key ][ $event_log_key ] = $event_user_id_and_time;

        if ( isset( $userdata->first_name ) ) {
            $plugin_userdata[ $badge_key ]['first_name'] = $this->sanitize_txt( $userdata->first_name );

            if ( isset( $userdata->last_name ) ) {
                $plugin_userdata[ $badge_key ]['last_name'] = $this->sanitize_txt( $userdata->last_name );
            }
        } elseif ( isset( $userdata->display_name ) ) {
            $plugin_userdata[ $badge_key ]['first_name'] = $this->sanitize_txt( $userdata->display_name );
        } elseif ( isset( $userdata->user_nicename ) ) {
            $plugin_userdata[ $badge_key ]['first_name'] = $this->sanitize_txt( $userdata->user_nicename );
        }

        if ( isset( $userdata->user_email ) ) {
            $contact_key = 'contact';
            $email_key   = 'email';

            $plugin_userdata[ $contact_key ][ $email_key ]['address']        = $this->sanitize_txt( $userdata->user_email );
            $plugin_userdata[ $contact_key ][ $email_key ][ $privacy_key ]   = 1;
            $plugin_userdata[ $contact_key ][ $email_key ][ $approval_key ]  = 1;
            $plugin_userdata[ $contact_key ][ $email_key ][ $event_log_key ] = $event_user_id_and_time;
        }

        if ( isset( $userdata->description ) ) {
            $bio_key = 'bio';
            
            $plugin_userdata[ $bio_key ]['description']    = $this->sanitize_txt( $userdata->description );
            $plugin_userdata[ $bio_key ][ $privacy_key ]   = 1;
            $plugin_userdata[ $bio_key ][ $approval_key ]  = 1;
            $plugin_userdata[ $bio_key ][ $event_log_key ] = $event_user_id_and_time;
        }

        if ( isset( $userdata->user_url ) ) {
            $parsed_url = $this->validate_url( $userdata->user_url );

            if ( $parsed_url ) {
                $web = 'websites';
                
                $plugin_userdata[ $web ]['addresses']      = array( $parsed_url );
                $plugin_userdata[ $web ][ $privacy_key ]   = 1;
                $plugin_userdata[ $web ][ $approval_key ]  = 1;
                $plugin_userdata[ $web ][ $event_log_key ] = $event_user_id_and_time;
            }
        }

        //Usermetas that are used by the plugin.
        $meta = array(
            $plugin_metas . 'reg_date'  => $userdata->user_registered,
            $plugin_metas . 'published' => 1,
        );
       
        $meta[ self::$plugin ] = $plugin_userdata;

        foreach ( $meta as $key => $value ) {
            update_user_meta( $user_id, $key, $value );
        }
    }  
    
    /**
     * Loads textdomain
     */
    public function init () {
        load_plugin_textdomain( 'describr', false,  'describr/languages' );
    }
    
    /**
     * Registers REST endpoint
     */
    public function rest_api_init () {
        //Fetches usernames based on keywords.
        register_rest_route(
            'describr/v1',
            'partner',
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array( $this, 'rest_partner_search' ),
                'args' => array(
                    'search_term' => array(
                        'required'          => true,
                        'validate_callback' => array( $this, 'rest_validate' ),
                    ),
                    'profile_user_id' => array(
                        'required' => true,
                    ),
                ),
                'permission_callback' => array( 
                    $this,
                    'rest_permission',
                ),
            )
        );
    }

    /**
     * Validates search term sent by the way of REST
     * 
     * @param string $param Search term
     * @return bool True if search term is not empty, otherwise False
     */
    public function rest_validate ( $search_term ) {
        if ( empty( $search_term ) ) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Decides who can perform rest's requests
     * 
     * @param WP_REST_Request array $request{
     *                 string 'profile_user_id' User ID belonging to the profile being edited
     *              }
     * @return bool True if the user can edit the profile, otherwise False
     */
    public function rest_permission ( WP_REST_Request $request ) {
        if ( empty( $request['profile_user_id'] ) || ! is_numeric( $request['profile_user_id'] ) ) {
            return false;
        }

        if ( current_user_can( 'edit_user', $request['profile_user_id'] ) ) {
            return true;
        }

        return false;
    }
    
    /**
     * Fetches user's name and ID via REST
     * 
     * @param WP_REST_Request array $request{
     *                 string 'search_term' Keyword (s) used to search for user
     *              }
     * @return WP_REST_Response object with array (containing user data or empty if no user data were found) as
     * argument 
     */
    public function rest_partner_search ( WP_REST_Request $request ) {
        global $user;//To be used in the pre_user_query hook
        
        $response = array();

        $user = $request['search_term'];

        $user = $this->sanitize_txt( $user );
            
        $search_term = strtolower( $user );
            
        add_action( 'pre_user_query', array( $this, 'partner_search_query' ) );

        $user_query = new WP_User_Query(
            array(
                'fields' => array( 'ID' ),
            )
        ); 

        $partners = $user_query->get_results();
            
        //Removes hook so that WordPress' default query behavior can resume.
        remove_action( 'pre_user_query', array( $this, 'partner_search_query' ) );
            
        if ( ! empty( $partners ) ) {
            foreach ( $partners as $partner ) {
                $user_id = $partner->ID;
                    
                $user_data = get_userdata( $user_id );
                    
                if ( ! $user_data ) {
                        continue;
                }

                $found_match = '';

                if ( isset( $user_data->describr['badge']['first_name'] ) ) {
                    $first_name = $user_data->describr['badge']['first_name'];
                        
                    if ( isset( $user_data->describr['badge']['last_name'] ) ) {
                        $first_name .= ' ' . $user_data->describr['badge']['last_name'];
                    }

                    if ( 0 === strpos( $first_name, $user ) ) {
                        $found_match = $first_name;
                    }
                }

                if ( ! $found_match && isset( $user_data->first_name ) ) {
                    $first_name = $user_data->first_name;

                    if ( isset( $user_data->last_name ) ) {
                        $first_name .= ' ' . $user_data->last_name;
                    }
                            
                    if ( 0 === strpos( $first_name, $user ) ) {
                        $found_match = $first_name;
                    }
                }

                if ( ! $found_match ) {
                    if ( 0 === strpos( $user_data->user_login, $user ) ) {
                        $found_match = $user_data->user_login;
                    } elseif ( ! empty( $user_data->nickname ) &&  0 === strpos( $user_data->nickname, $user ) ) {
                        $found_match = $user_data->nickname;
                    } elseif ( ! empty( $user_data->display_name ) && 0 === strpos( $user_data->display_name, $user ) ) {
                        $found_match = $user_data->display_name;
                    }           
                }
                    
                //This user is skipped if a match is not found at the beginning of the string.
                if ( 0 !== strpos( strtolower( $found_match ), $search_term ) ) {
                    continue;
                }

                $response[] = array(
                    'id'   => $user_id,
                    'name' => $found_match
                );
            }
        }
        
        return new WP_REST_Response( $response );
    }
  
    /**
     * Modifies database query during relationship partner search
     * 
     * This callback will be added to the pre_user_query hook before querying the 
     * database and removed immediately after.
     * 
     * @param object $query Contains SQL used to query MySQL
     */
     public function partner_search_query ( $query ) {
        global $user, $wpdb;
        
        $current_user = get_current_user_id();
        
        /*Check if string contains a space, which would mean the user is searching by username, nickname, or first and last name.*/
        $user_array        = preg_split( '/\s+/', $user, -1, PREG_SPLIT_NO_EMPTY );
        $user_array_length = count( $user_array );
        
        $db_meta  = $wpdb->usermeta;
        $db_users = $wpdb->users;
        
        $wild = '%';
        
        $search_name = "nickname', 'first_name";

        //Keywords of all varieties can match username, so it will always be searched against.
        $where = "$db_users.user_login LIKE %s OR ";
        
        $query_user = $wpdb->esc_like( $user ) . $wild;

        $args = array( $query_user );
        
        //Is the user searching by username or nickname, since any one of the two can have more than two spaces?
        if ( $user_array_length > 2 || $user_array_length < 2 ) {
            $args[] = $query_user;

            $where .= "($db_meta.meta_key IN ('";
            
            //A keyword with more than two spaces can match either a username or a nickname.
            if ( $user_array_length > 2 ) {
                $where .= 'nickname';
            } else { //A keyword without a space can match a username, a nickname, and a first name.
                $where .= $search_name;
            }

            $where .= "') AND $db_meta.meta_value LIKE %s)";
        } else {
            $where .= "($db_meta.meta_key IN ('$search_name') AND $db_meta.meta_value = %s)";
            
            $args[] = $wpdb->esc_like( $user_array[0] );
        }

        $query->query_fields = "SQL_CALC_FOUND_ROWS DISTINCT $db_users.ID, $db_users.user_login";
         
        $query->query_from .= " INNER JOIN $db_meta ON $db_meta.user_id = $db_users.ID";

        $query->query_where = " WHERE $db_users.ID != $current_user AND (" . $wpdb->prepare( $where, $args ) . ')';

        $query->query_orderby .= ', meta_value DESC';
    }

    /**
     * Fires if the current user is editing his or her own profile
     * 
     * Delineates the plugin's section on the user's profile screen
     * 
     * Profile data are added by JavaScript.
     * 
     * @param WP_User $profile_user Profile owner's info 
     */
	public function show_user_profile ( $profile_user ) {
      $main_class = self::$plugin;
      $username   = $this->username_to_use( $profile_user );

      if ( $username ) {
        $alt = sprintf(
            /*translators: %s: User's name*/
            __( 'Loading %s profile data...', 'describr' ),
            $username
        );
      } else {
        $alt = __( 'Loading profile data...', 'describr' );
      }
      ?>
      <div id="<?php echo esc_attr( $main_class );?>" class="<?php echo esc_attr( $main_class );?>">
        <h1><?php echo esc_html( $this->plugin_name );?></h1>
        <span class="<?php echo esc_attr( $main_class . '__accessibility' );?>" aria-live="polite"></span>
        <p class="<?php echo esc_attr( $main_class . '__loading' )?>">
            <img src="<?php echo esc_attr( $this->plugin_url . 'images/loading.gif' );?>" alt="<?php echo esc_attr( $alt );?>" width="20px" height="20px">
        </p>
      </div>
      <?php
      $main_var = self::$plugin . '_update_profile_nonce';

      wp_nonce_field( $main_var, $main_var, false );
	}

	/**
	 * Saves any changes made to profile
	 *
	 * @param int $user_id ID of user whose profile is being updated
	 */
	public function edit_user_profile ( $user_id ) {
        require_once( dirname( __FILE__ ) . '/edit-user-profile.php' );
    }
    
    /**
     * Provides info related to the owner of the profile in question
     * 
     * No profile info is redacted if the profile is being viewed by an editor. 
     * 
     * The user's profile in question is not necessarily that of the logged-in user.
     * 
     * @param WP_User object|array $profile_user Profile owner's info
     * @return array Info related to the profile owner, with sections redacted if necessary
     */
    public function profile_info ( $profile_user = array() ) {
        if ( $profile_user && isset( $profile_user->describr ) ) {
            $describr_profile_user = $profile_user->describr;
        } else {
            $describr_profile_user = $profile_user;
        }
        
        $is_editor = current_user_can( 'edit_others_posts' );
            
        $current_user_id = get_current_user_id();

        $can_edit = false;

        $describr_profile_user_is_published = 0;
        
        $timeperiod_key = 'timeperiod';
        $from_key       = 'frm';
        $to_key         = 'to';      

        if ( $profile_user ) {
            $describr_profile_user_id = $profile_user->ID;            
        } else {
            $describr_profile_user_id = 0;
        }    
        
        $sessions = WP_Session_Tokens::get_instance( $describr_profile_user_id );

        $describr_profile_user_is_owner = $current_user_id && $current_user_id == $describr_profile_user_id;

        if ( $is_editor ) {
            $can_edit = true;
        } elseif ( $describr_profile_user_id ) {
            $can_edit = current_user_can( 'edit_user', $describr_profile_user_id );
        }
        
        if ( $profile_user && isset( $profile_user->describr_published ) ) {
            $describr_profile_user_is_published = $profile_user->describr_published;
        }
        
        if ( $describr_profile_user_is_published || $is_editor ) {
            foreach ( $describr_profile_user as $sctn => &$specs ) {
                if ( is_array( $specs ) ) {
                    //Create string representation of dates if the current user can't edit this profile.
                    if ( ! $can_edit ) {
                        if ( 'birthdate' == $sctn ) {
                            if ( ! empty( $specs['date'] ) ) {
                                $specs['date'] = $this->create_date( $specs['date'] );
                            }
                        } elseif ('addresses' == $sctn ) {
                            if ( isset( $specs['lived_cities'] ) ) {
                                $lived_cities =& $specs['lived_cities'];

                                foreach ( $lived_cities as $city => &$elements ) {
                                    if ( ! empty( $elements['moved'] ) ) {
                                        $elements['moved'] = $this->create_date( $elements['moved'] );
                                    }
                                }
                            }
                        } elseif ( 'workhistory' == $sctn ) {
                            $work_history =& $specs['jobs'];

                            foreach ( $work_history as $jobs => &$job ) {
                                if ( ! empty( $job[ $from_key ] ) ) {
                                    $timeperiod = $this->create_date( $job[ $from_key ] );

                                    if ( $timeperiod ) {
                                        if ( isset( $job['present'] ) ) {
                                            $timeperiod .= '-' . __( 'present', 'describr' );
                                        } elseif ( isset( $job[ $to_key ] ) && ! empty( $job[ $to_key ] ) ) {
                                            $timeperiod .= '-' . $this->create_date( $job[ $to_key ] );
                                        }
                                    }
                                    
                                    if ( $timeperiod ) {
                                        $job[ $timeperiod_key ] = $timeperiod;
                                    }                                    
                                }
                            }                            
                        } elseif ( 'colleges' == $sctn || 'highschools' == $sctn ) {
                            if ( ! empty( $specs['schools'] ) ) {
                                $schools =& $specs['schools'];

                                foreach ( $schools as $school => &$fields ) {
                                    if ( ! empty( $fields[ $from_key ] ) ) {
                                        $timeperiod = '';

                                        if ( ! empty( $fields[ $to_key ] ) ) {
                                            $to = $fields[ $to_key ];
                                        } else {
                                            $to = '';
                                        }

                                        if ( isset( $fields['graduated'] ) ) {
                                            if ( $to ) {
                                                $to = explode( '-', $to );

                                                $timeperiod = sprintf(
                                                    /*translators: %s: Year*/
                                                    __( 'Class of %s', 'describr' ),
                                                    $to[0]
                                                );
                                            }
                                        } else {
                                            $timeperiod = $this->create_date( $fields[ $from_key ] );
                                            if ( $to ) {
                                                $timeperiod .= '-' . $this->create_date( $to );
                                            }
                                        }

                                        if ( $timeperiod ) {
                                            $fields[ $timeperiod_key ] = $timeperiod;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if ( 'contact' == $sctn ) {
                        if (  isset( $specs['email'] ) ) {
                            $this->permission_profile_section( $specs['email'], $describr_profile_user_is_owner );
                        }

                        if ( isset( $specs['phones'] ) ) {
                            $this->permission_profile_section( $specs['phones'], $describr_profile_user_is_owner );                            
                        }
                    } else {
                        if ( isset( $specs['partner'] ) ) {
                            $partner =& $specs['partner'];
                            
                            if ( ! empty( $partner['id'] ) ) {
                                $partner_id = get_userdata( $partner['id'] );

                                if ( $partner_id ) {
                                    $partner_name = $this->username_to_use( $partner_id );

                                    if ( $partner_name ) {
                                        $partner['name'] = $partner_name;
                                    }
                                }                                
                            }

                            if ( ! $can_edit && ! empty( $partner['since'] ) ) {
                                $partner['since'] = $this->create_date( $partner['since'] );
                            }
                        }

                        $this->permission_profile_section( $specs, $describr_profile_user_is_owner );
                    }
                }//if ( is_array( $specs ) )
            }//foreach
            
            $name = $this->username_to_use( $profile_user );
            
            if ( $name ) {
                $describr_profile_user['displayName'] = esc_html( $name );
            }
        }

        $describr_profile_user['profileUserId'] = $describr_profile_user_id;
        $describr_profile_user['published']     = $describr_profile_user_is_published;
        $describr_profile_user['isOwnProf']     = $describr_profile_user_is_owner;
        $describr_profile_user['isLogin']       = count( $sessions->get_all() );
        $describr_profile_user['canEdit']       = $can_edit;
        $describr_profile_user['profImage']     = $this->get_the_avatar( $describr_profile_user_id );

        return $describr_profile_user;
    }
    
    /**
     * Decides whether the current user has permission to view the profile section in question
     * 
     * @param array $profile_section  The profile section to update
     * @param bool  $is_profile_owner Indicates whether the logged-in user is the owner of  
     *                                the profile 
     */
    public function permission_profile_section ( &$profile_section, $is_profile_owner ) {
        $is_editor = current_user_can( 'edit_others_posts' );

        $privacy_key  = self::$visibility_key;
        $approval_key = self::$approval_key;

        if ( $is_editor ) {
            $this->sort_profile_section_events( $profile_section );
        } elseif ( isset( $profile_section[ $this->event ] ) ) {
            unset( $profile_section[ $this->event ] );
        }

        if ( ! $is_editor && ! $is_profile_owner ) {
            if ( isset( $profile_section[ $privacy_key ] ) ) {
                $privacy_status = $profile_section[ $privacy_key ];

                unset( $profile_section[ $privacy_key ] );
            } else {
                $privacy_status = 1;
            }

            if ( isset( $profile_section[ $approval_key ] ) ) {
                $approval_status = $profile_section[ $approval_key ];
            } else {
                $approval_status = 1;
            }

            if ( ! $approval_status || ! $privacy_status ) {
                foreach( $profile_section as $key ) {
                    if ( $approval_key != $key ) {
                        unset( $profile_section[ $key ] );
                    }
                }
            }
        }//if ( ! $is_editor && ! $is_profile_owner ) {
    }
        
    /**
     * Sorts profile section's events in descending order
     * 
     * @param array $profile_section Profile section's info
     */
    public function sort_profile_section_events ( &$profile_section ) {
        $event_key = $this->event;

        if ( isset( $profile_section[ $event_key ] ) && is_array( $profile_section[ $event_key ] ) ) {
            $events_log =& $profile_section[ $event_key ];

            foreach ( $events_log as $event => $details ) {
                $user_timezone = '';

                $event_user_id_and_time = explode( '__', $details );

                $user_id = $event_user_id_and_time[0];

                $user = get_userdata( $user_id );

                //Get the user's preferred time zone, if set.
                if ( $user && isset( $user->describr['timezone'] ) ) {
                    $profile_section_timezone = $user->describr['timezone'];
                    if ( isset( $profile_section_timezone['name'] ) && isset( $profile_section_timezone['approved'] ) && 1 == $profile_section_timezone['approved'] ) {
                         $user_timezone = $profile_section_timezone['name'];
                    }
                }
                             
                $events_log[ $event ] = array( 
                    'date' => $this->datetime( $event_user_id_and_time[1], $user_timezone ), 
                    'name' => $this->username_to_use( $user ), 
                    'id'   => $user_id, 
                );
            }
            
            usort( $events_log, array( $this, 'sort_updated_by' ) );
        }
    }
    
    /**
     * Sorts event logs, by date, in descending order
     * 
     * @param array $first_date_to_compare  The first date to compare
     * @param array $second_date_to_compare The second date to compare
     * @return int 0 if $first_date_to_compare and $second_date_to_compare date are the same, 1 if
     *             $first_date_to_compare is greater than $second_date_to_compare date, or -1 if
     *             $first_date_to_compare is less than $second_date_to_compare date.
     */
    public function sort_updated_by ( $first_date_to_compare, $second_date_to_compare ) {
        $first_time_to_compare  = strtotime( $first_date_to_compare['date'] );
        $second_time_to_compare = strtotime( $second_date_to_compare['date'] );

        if ( $first_time_to_compare > $second_time_to_compare ) {
            return -1;
        } elseif ( $second_time_to_compare > $first_time_to_compare ) {
            return 1;
        } else{
            return 0;
        }
    }

    /**
     * Sets privacy, approval, and event log for profile section
     *
     * @param array $profile_section Previously saved privacy, approval, and event log
     * @return array Updated privacy, approval, and event log
     */
    public function update_profile_section_event_log ( $profile_section = array() ) {
        $event_user_id_and_time = get_current_user_id() . '__' . time();
        
        $event_key = $this->event;

        //The section is an existing one if the visibility element is set.
        if ( isset( $profile_section[ self::$visibility_key ] ) ) {
            if ( isset( $profile_section[ $event_key ] ) ) {
                if ( is_array( $profile_section[ $event_key ] ) ) {
                    $profile_section[ $event_key ][] = $event_user_id_and_time;
                } else {
                    $profile_section[ $event_key ] = array( $profile_section[ $event_key ], $event_user_id_and_time );
                }
            } else {
                $profile_section[ $event_key ] = array( $event_user_id_and_time );
            }
        } else {
            $profile_section[ self::$visibility_key ]  = 1;
            $profile_section[ self::$approval_key ] = 1;
            $profile_section[ $event_key ]  = array( $event_user_id_and_time );
        }

        return $profile_section;
    }

    /**
     * Adds the necessary changes to profile sections
     * 
     * @param string|int|array $submitted_value     The new value
     * @param string           $section_key               The key to set the new value
     * @param array            $old_profile_section_array Existing info pertaining to the section
     * @param bool             $change                    Inicates if changes are made
     * @param array            $new_profile_section_array User-submitted data pertaining to the section
     */
    public function update_profile_section ( $submitted_value, $section_key, &$old_profile_section_array, &$change, $new_profile_section_array = array() ) {
        if ( is_string( $submitted_value ) || is_numeric( $submitted_value ) || is_int( $submitted_value ) ) {
            $submitted_value_length = strlen( $submitted_value );
        } elseif ( is_array( $submitted_value ) ) {
            $submitted_value_length = count( $submitted_value );
        } else {
            $submitted_value_length = $submitted_value;
        }
        
        if ( isset( $old_profile_section_array[ $section_key ] ) ) {
            if ( $new_profile_section_array ) {
                $this->add_profile_section_controls( $old_profile_section_array, $new_profile_section_array, $change );
            }

            if ( $submitted_value_length ) {
                if ( is_array( $submitted_value ) ) {
                    if ( $submitted_value !== $old_profile_section_array[ $section_key ] ) {
                        $old_profile_section_array[ $section_key ] = $submitted_value;
                        $change = true;
                    }
                } elseif ( ( string ) $submitted_value !== ( string ) $old_profile_section_array[ $section_key ] ) {
                    $old_profile_section_array[ $section_key ] = $submitted_value;
                    $change = true;
                }
            } else {
                unset( $old_profile_section_array[ $section_key ] );                
               $change = true;
            }
        } elseif ( $submitted_value_length ) {
            $old_profile_section_array[ $section_key ] = $submitted_value;
            $change = true;
        }
    }

    /**
     * Sets a section's visibility and approval status
     * 
     * @param array $old_profile_section_array Old info for existing section
     * @param array $new_profile_section_array New info for profile section
     * @param bool  $change                    Indicates whether the value should be updated in the database
     */
    public function add_profile_section_controls ( &$old_profile_section_array, $new_profile_section_array, &$change ) {
        $privacy_key  = self::$visibility_key;
        $approval_key = self::$approval_key;
        
        $privacy_value = isset( $new_profile_section_array[ $privacy_key ] ) ? ( int ) $new_profile_section_array[ $privacy_key ] : 1;

        if ( isset( $old_profile_section_array[ $privacy_key ] ) && $privacy_value !== ( int ) $old_profile_section_array[ $privacy_key] ) {
            $old_profile_section_array[ $privacy_key ] = $privacy_value;

            $change = true;
        }

        if ( current_user_can( 'edit_others_posts' ) ) {
            $approval_value = isset( $new_profile_section_array[ $approval_key ] ) ? ( int ) $new_profile_section_array[ $approval_key ] : 0;

            if ( isset( $old_profile_section_array[ $approval_key ] ) && $approval_value !== ( int ) $old_profile_section_array[ $approval_key ] ) {
                $old_profile_section_array[ $approval_key ] = $approval_value;

                $change = true;
            }
        }
    }
    
    /**
     * Adds to the plugin's main usermeta array changes made to a profile section
     * 
     * @param array  $old_userdata            Pre-existing user meta values
     * @param array  $new_userdata            The array that stores all describr fields that
     *                                        will eventually be updated in the database
     * @param array  profile_section          Existing user data pertaining to the section 
     * @param string $saved_data_key          The key to locate the section in main user-meta array belonging to 
     *                                        the plugin
     * @param string $locate_updated_data_key The key to locate the updated data in specific section
     * @param bool   $change                  Inicates whether changes were made to the section
     */
    public function commit_changes_made_to_profile_section ( &$old_userdata, &$new_userdata, $profile_section, $saved_data_key, $locate_updated_data_key, $change ) {
        if ( $change ) {
            //Unset the pre-existing section
            if ( isset( $old_userdata[ $saved_data_key ] ) ) {
                unset( $old_userdata[ $saved_data_key ] );
            }
            
            //Is there new data? If yes, re-add the section 
            if ( isset( $profile_section[ $locate_updated_data_key ] ) ) {
                $new_userdata[ $saved_data_key ] = $this->update_profile_section_event_log( $profile_section );
            }        
        }
    }
    
    /**
     * Truncates text if its length exceeds a specified length
     * 
     * @param string $string       The string to truncate
     * @param string $field        The field to which the text belongs
     * @param int    $field_length The length that the string must not exceed
     * @param int    $offset       Where to start the returned string
     * @return string Truncated string or the entire string if length retriction was not breached
     */
    public function trunc ( $string = '', $field = '', $field_length = 1000, $offset = 0 ) {
        $string = trim( $string );

        if ( strlen( $string ) > $field_length ) {
            $string = substr( $string, $offset, $field_length );

            $error_array_key = preg_replace( '/\s+/', '_', $field ) . '_errors';

            if ( ! isset( $this->profile_update_errors[ $error_array_key ] ) ) {
                $this->profile_update_errors[ $error_array_key ] = sprintf(
                    /*translators: %s: HTML form field, %d: number of characters allowed*/
                    __( '%s cannot have no more than %d characters.', 'describr' ),
                    $field,
                    $field_length
                );
            }
        }

        return $string;
    }
    
    /**
     * Validates email
     * 
     * We test for some email formats that are not allowed instead of those allowed because both the number of
     * characters allowed and different formats are vast.
     * Our goal is to be as liberal as possible with allowed characters while preventing the most obvious disallowed 
     * characters. For example, we don't test for a top-level domain at the end of the email address as doing so
     * would retrict an email address with "localhost" as the domain.
     * 
     * An email address can't have any of these conditions:
     * 1) start or end with either a dot (.) or @; 
     * 2) dot on either side of @ sign if not in double quotes; 
     * 3) consecutive dots, consecutive @@, or space if not in double quotes;
     * 4) double or single quotes on the right side of the @ sign; or 
     * 5) one double quote.
     * 
     * @param string email The email to validate.
     * @return bool True if email passes validation, otherwise False
     */    
    public function validate_email ( $email = '' ) {
        $email = trim( $email );

        $error_array_key = '';

        $notices = array(
            __( 'Email address must be at least three characters in length.', 'describr' ), 
            __( 'Email address must have at least one @ character.', 'describr' ), 
            __( 'Invalid email address format.' , 'describr' ),
        );

        //Testing for a minimum of 3 characters, the @ sign and one character on either side, is very liberal.
        if ( 3 > strlen( $email ) ) {
            $error_array_key = 0;
        } elseif ( 1 !== preg_match( '/@/', $email ) ) {//An email address must have at east one @ sign.
            $error_array_key = 1;
        } elseif ( preg_match( '/^(\.|@)|(\.|@)$/', $email ) || ( preg_match( '/(\.@|@\.|\.{2,}|@{2,}|\s+|\\\)/', $email ) && ! preg_match( '/".*(\.@|@\.|\.{2,}|@{2,}|\s+|\\\)+.*"/', $email ) ) || preg_match( '/"(?!.*@+)/', $email ) ) {
            $error_array_key = 2;
        }

        if ( 2 != $error_array_key ) {
            preg_match_all( '/"/', $email, $matches );

            if ( 1 == count( $matches[0] ) ) {
                $error_array_key = 2;
            }
        }
        
        if ( '' !== $error_array_key ) {
            $this->profile_update_errors['email_errors'] = $notices[ $error_array_key ];

            return false;
        }

        return true;
    }
    
    /**
     * Sanitizes city
     * 
     * Strips characters except dot, white space, alphabetic characters, single quote, dash, and 
     * comma
     * 
     * @param string $city The city to sanitize
     * @return string The city, less disallowed characters
     */
    public function sanitize_city ( $city = '' ) {
        return preg_replace( "/[^\.\sa-zA-Z0-9&,'-]+/", '', trim( $city ) );
    }

    /**
     * Checks whether logged in user is the same as profile owner
     *
     * @param int $user_id Profile owner ID
     * @return bool True if the current user is the owner of $user_id's profile,
     *              otherwise False
     */
    public function is_profile_owner ( int $user_id ) {
        return get_current_user_id() === $user_id;
    }

    /**
     * Fetches avatar
     * 
     * @param int|string|object $id_or_email A user ID,  email address, or comment object
     * @param int               $size        Size of the avatar
     * @param string            $default     URL to a default image to use if no avatar is available
     * @param string            $alt         Alternate text to use in image tag. Defaults to blank
     * @param array             $args        Extra arguments related to the avatar (optional)
     *
     * @return string User's avatar, otherwise default avatar
     */
    public function get_the_avatar ( $id_or_email, $size = 96, $default = '', $alt = '', $args = array() ) {
        return get_avatar( $id_or_email, $size, $default, $alt, $args );
    }
    
    /**
	 * Creates default avatar url
	 *
	 * @param int $size Requested avatar size.
     * @return string Avatar's default URL
	 */
	public function get_default_avatar_url ( $size ) {
		$default = $this->avatar_default;

		$host = is_ssl() ? 'https://secure.gravatar.com' : 'http://0.gravatar.com';

		if ( 'mystery' === $default ) {
            //ad516503a11cd5ca435acc9bb6523536 == md5('unknown@gravatar.com')
			$default = "{$host}/avatar/ad516503a11cd5ca435acc9bb6523536?s={$size}"; 
		} elseif ( 'blank' === $default ) {
			$default = includes_url( 'images/blank.gif' );
		} elseif ( 'gravatar_default' === $default ) {
			$default = "{$host}/avatar/?s={$size}";
		} else {
			$default = "{$host}/avatar/?d=$default&amp;s={$size}";
		}

		return $default;
	}
    
    /**
     * Fetches the site's default avatar
     *
     * @return string Default avatar
     */
    public function get_default_avatar () {
        $avatar_default = get_option( 'avatar_default' );

        if ( empty( $avatar_default ) ) {
            $avatar_default = 'mystery';
        }

        return $avatar_default;
    }
    
    /**
     * Filters the HTML for a user’s avatar
     *
     * Changes html alt attribute to name of default image if html image 
     * being returned is that of WordPress' default image
     *
     * @param string $avatar      Image tag for the user's avatar
     * @param mixed  $id_or_email The avatar to retrieve. Accepts a user_id, Gravatar
     *                            MD5 hash, user email, WP_User object, WP_Post object,
     *                            or WP_Comment object
     * @param int    $size        Square avatar width and height in pixels to retrieve
     * @param string $default     URL for the default image or a default type. Accepts
     *                            '404', 'retro', 'monsterid', 'wavatar', 'indenticon',
     *                            'mystery', 'mm', 'mysteryman', 'blank', or 
     *                            'gravatar_default'. Default is the value of the
     *                            'avatar_default' option, with a fallback of 'mystery'.
     * @param string $alt         Alternative text to use in the avatar image tag.
     *                            
     * @param array  $args        Arguments passed to get_avatar_data(), after
     *                            processing
     * @return string the <img>.
     */
    public function get_avatar ( $avatar, $id_or_email, $size, $default, $alt, $args ) {
        if ( 1 === preg_match( "/<img alt='(.*)?'\s+src='(.*)'\s+srcset='(.*)'\s+class='(.*)'\s+height='(.*)'\s+width='(.*)'\s+(.*)?\/>/", $avatar, $attr ) ) {
            $old_alt    = $attr[1];
            $src        = $attr[2];
            $srcset     = $attr[3];
            $class      = $attr[4];
            $height     = $attr[5];
            $width      = $attr[6];
            $extra_attr = $attr[7];
            $new_alt    = '';

            if ( empty( $src ) ) {
                $src = $args['url'];
            }

            if ( 1 === preg_match('/\/wp\-includes\/images\//', $src ) || 1 === preg_match( '/https:\/\/secure\.gravatar\.com|http:\/\/[0-9]\.gravatar\.com/', $src ) ) {
                $new_alt = $this->avatar_default;
            } elseif ( empty( $old_alt ) ) {
                if ( is_numeric( $id_or_email ) ) {
                    $user = get_user_by( 'ID' , (int) $id_or_email );
                } elseif ( is_email( $id_or_email ) ) {
                    $user = get_user_by( 'email', $id_or_email ); 
                } elseif ( is_object( $id_or_email ) && ! empty( $id_or_email->user_id ) ) {
                    $user = get_user_by( 'ID' , (int) $id_or_email->user_id );
                } elseif ( $id_or_email instanceof WP_Post && ! empty( $id_or_email->post_author ) ) {
                    $user = get_user_by( 'ID' , (int) $id_or_email->post_author );
                }

                if ( $user && is_object( $user ) ) {
                    $new_alt = $this->username_to_use( $user );
                }
            } else {
                $new_alt = $old_alt;
            }
         
            if ( ! empty( $new_alt ) ) {
                if ( empty( $height ) ) {
                    $height = $size;
                }

                if ( empty( $width ) ) {
                    $width = $size;
                }
                
                $avatar = sprintf(
                    "<img alt='%s' src='%s' srcset='%s' class='%s' height='%d' width='%d' %s/>",
                    esc_attr( $new_alt ),
                    $src,
                    $srcset,
                    $class,
                    ( int ) $height,
                    ( int ) $width,
                    $extra_attr
                );
            }
        }
        
        return $avatar;
    }
    
    /**
	 * Filters avatar data early to add avatar url if needed. This filter hooks
	 * before Gravatar setup to prevent wasted requests.
	 *
	 * @param array $args        Arguments passed to get_avatar_data(), after processing
	 * @param mixed $id_or_email The Gravatar to retrieve. Accepts a user ID, Gravatar MD5 hash,
	 *                           user email, WP_User object, WP_Post object, or WP_Comment object
     * @return array Data about the avatar
	 */
	public function get_avatar_data ( $args, $id_or_email ) {
		if ( ! empty( $args['force_default'] ) ) {
			return $args;
		}
        
        //Gets the URL to use.
        $avatar_url = $this->get_avatar_url( $id_or_email, $args['size'] );
		
        //Sets the URL to use for the avatar.
        if ( $avatar_url ) {
			$args['url'] = $avatar_url;
		}

		//Should default avatar be used if no avatar URL exists?
		if ( ! $avatar_url && ! empty( $this->avatar_permissions['only'] ) ) {
			$args['url'] = $this->get_default_avatar_url( $args['size'] );
		}

		if ( ! empty( $args['url'] ) ) {
			$args['found_avatar'] = true;
		}
        
        return $args;
	}

    /**
	 * Gets URL of avatar uploaded my this plugin
     * 
     * Shows the default avatar if the user's avatar is restricted: marked as unapproved 
     * by an editor, marked as invisible by the owner of the profile, or marked as 
     * visible to only friends. Restrictions set by the avatar's owner doesn't apply to 
     * editors. 
	 *
	 * @param mixed $id_or_email The Gravatar to retrieve. Accepts a user ID, Gravatar
     *                           MD5 hash, user email, WP_User object, WP_Post object,
     *                           or WP_Comment object
	 * @param int   $size        Requested avatar size
     * @return array|string The avatar's size and URL, otherwise empty string the user
     *                      can't be found or no avatar was uploaded 
	 */
	public function get_avatar_url ( $id_or_email, $size ) {
        $current_user = get_current_user_id();

        $plugin = self::$plugin;

        $user_id  = '';

        $avatar_url = '';

        if ( is_numeric( $id_or_email ) ) {
            $user_id = ( int ) $id_or_email;
        } elseif ( is_string( $id_or_email ) ) {
            $user = get_user_by( 'email', $id_or_email );
            
            if ( $user ) {
                $user_id = $user->ID;
            }
        } elseif ( is_object( $id_or_email ) && ! empty( $id_or_email->user_id ) ) {
            $user_id = ( int ) $id_or_email->user_id;
        } elseif ( $id_or_email instanceof WP_Post && ! empty( $id_or_email->post_author ) ) {
            $user_id = ( int ) $id_or_email->post_author;
        }

        if ( empty( $user_id ) ) {
            return '';
        }
        
        //Fetches local avatar from meta and makes sure it's properly set.
        $user = get_user_by( 'id', $user_id );
        
        if ( empty( $user ) ) {
            return '';
        }

        $profile_info = $user->$plugin;

        if ( ! isset( $profile_info['avatar'] ) ) {
            return '';
        }

        $avatars = ( array ) $profile_info['avatar'];

        if ( $user->ID ) {
            $avatar_owner = $user->ID;
        } else {
            $avatar_owner = false;
        }

        $avatar_privacy_status  = isset( $avatars[ self::$visibility_key ] ) ?  ( int ) $avatars[ self::$visibility_key ] : 1;
        $avatar_approval_status = isset( $avatars[ self::$approval_key ] ) ?  ( int ) $avatars[ self::$approval_key ] : 1;
        
        $size = ( int ) $size;

        //Show default Avatar if the Avatar is set either as private by the profile owner or as unapproved by an editor and the current user is neither an editor nor the owner of the profile.
        if ( ! $avatar_privacy_status || ! $avatar_approval_status ) {
            if ( ! current_user_can( 'edit_others_posts' ) && $current_user !== $avatar_owner ) {
                return $this->get_default_avatar_url( $size );
            }
        }
              
        if ( empty( $avatars['full'] ) ) {
            return '';
        }
        
        $upload_path = wp_get_upload_dir();

        $baseurl = $upload_path['baseurl'];
        $basedir = $upload_path['basedir'];

        if ( is_ssl()  && 0 !== strpos( $baseurl, 'https' ) ) {
            $baseurl = str_replace( 'http://', 'https://', $baseurl );
        }
        
        if ( ! empty( $avatars[ $size ] ) ) {
            if ( file_exists( $basedir . $avatars[ $size ] ) ) {
                $avatar_url = $baseurl . $avatars[ $size ];
            }
        }

        //Handle "real" media
        if ( ! empty( $avatars['media_id'] ) ) {
            
            //Has the media been deleted?
            $avatar_full_path = get_attached_file( $avatars['media_id'] );

            if ( ! $avatar_full_path ) {
                $avatar_full_path = $basedir . $avatars['full'];
                
                if ( ! file_exists( $avatar_full_path ) ) {
                    self::avatar_delete( $user_id );

                    return '';
                }
            }
            
            if ( empty( $avatars[ $size ] ) ) {
                if ( apply_filters( self::$plugin . '_avatars_dynamic_resize', true ) ) {
                    $this->avatar_generate( $avatar_full_path, $upload_path, $size, $avatars );
                            
                    //Was the image create? If yes, save this image in the user's profile data.
                    if ( ! empty( $avatars[ $size ] ) ) {
                        $avatar_url = $avatars[ $size ];

                        $avatars[ $size ] = $this->avatar_remove_baseurl( $avatars[ $size ] );

                        unset( $profile_info['avatar'] );

                        self::update_user_meta( $user_id, $profile_info, array( 'avatar' => $avatars ) );
                    }
                }
            }
        }
        
        if ( $avatar_url ) {
            if ( 0 !== strpos( $avatar_url, 'http' ) ) {
                $avatar_url = home_url( $avatar_url );
            }
                        
            return esc_url( $avatar_url );
        }
        
        return '';
    }

	/**
	 * Saves avatar image to a user
	 *
	 * @param int|string $url_or_media_id Local URL for avatar or ID of attachment
	 * @param int        $user_id         ID of user to whom the image is assigned
	 */
	public function assign_avatar ( $url_or_media_id, $user_id ) {
        //Delete old images		
		self::avatar_delete( $user_id );
        
        $user = get_user_by( 'id', $user_id );

        $profile_info = array();

        $plugin = self::$plugin;

        if ( $user && $user->$plugin ) {
            $profile_info = $user->$plugin;
        }
        
        if ( empty( $profile_info['avatar'] ) ) {
            $avatar = $this->update_profile_section_event_log();
        } else {
            $avatar = $this->update_profile_section_event_log( $profile_info['avatar'] );            
        }
        
        $avatar['media_id'] = $url_or_media_id;
		
        //Sets the new avatar
		if ( is_int( $url_or_media_id ) ) {
            $attachment = wp_get_attachment_url( $url_or_media_id );

            if ( $attachment ) {
                $upload_path      = wp_upload_dir();
                $avatar_full_path = str_replace( $upload_path['baseurl'], $upload_path['basedir'], $attachment );
                
                $avatar['full'] = $this->avatar_remove_baseurl( $attachment );
                    
                //WordPress automatically creates an accompanying thumnail image when a new image is uploaded to media library. In order for the thumbnail to be deleted from the filesystem when the user deletes the avatar, the thumbnail is added to the images associated with the avatar. Failing this, the thumnail remains on the filesystem after the user deletes the avatar.
                $post = get_post_meta( $url_or_media_id, '_wp_attachment_metadata' );

                if ( is_array( $post ) && $post ) {
                    $thumbnailDir = pathinfo( $avatar_full_path, PATHINFO_DIRNAME );
                    $thumbnailDir = rtrim( $thumbnailDir, '/' );

                    $thumbnailURL = pathinfo( $attachment, PATHINFO_DIRNAME );
                    $thumbnailURL = rtrim( $thumbnailURL, '/' );

                    foreach ( $post as $key => $value ) {
                        if ( is_array( $value ) ) {
                            $thumbnail = $value['sizes']['thumbnail'];
                            $file = '/' . ltrim( $thumbnail['file'], '/' );

                            $thumbnailDir .= $file;
                            
                            $thumbnailURL .= $file;
                            
                            $thumbnailURL = $this->avatar_remove_baseurl( $thumbnailURL );

                            if ( file_exists( $thumbnailDir ) ) {
                                if ( file_exists( $avatar_full_path ) ) {
                                    $size = $thumbnail['width'];

                                    if ( ! $size ) {
                                        $size = 150;
                                    }

                                    $avatar[ $size ] = $thumbnailURL;
                                } else {
                                    //Use the thumnail as the default image if no default image is available.
                                    $avatar['full'] = $thumbnailURL;
                                }
                            }
                        }
                    }
                }
                        
                if ( isset( $profile_info['avatar'] ) ) {
                    unset( $profile_info['avatar'] );//Remove existing avatar.
                }
                
                //Attaches updated avatar to describr meta_data.
                self::update_user_meta( $user_id, $profile_info , array( 'avatar' => $avatar ) );
                
            }
        }
    }
    
    /**
     * Generates image with dimensions based on the size argument
     *
     * @param string $path        File path of image to generate new size from.
     * @param array  $upload_path Information about WordPress upload directory  
     * @param int    $size        Size of new generated image
     * @param array  $avatars     Array to save new image path    
     * @return bool True if new image was created. False if error is encountered during image creation process
     */
    public function avatar_generate ( $path, $upload_path, $size, &$avatars ) {        
        $editor = wp_get_image_editor( $path );

        if ( is_wp_error( $editor ) ) {
            return;
        }
        
        $resized = $editor->resize( $size, $size, false );

        if ( is_wp_error( $resized ) ) {
            return;
        }

        $dest_file = $editor->generate_filename();
        $saved     = $editor->save( $dest_file );

        if ( is_wp_error( $saved ) ) {
            return;
        }
        
        $avatars[ $size ] = str_replace( $upload_path['basedir'], $upload_path['baseurl'], $dest_file );
    }

	/**
	 * Gives developers access to custom filter hook {describr_files_upload_limit} 
     * that can be used to override WordPress maximum size for uploaded files
	 *
	 * @param  int $bytes WordPress' maximum size for uploaded files
	 * @return int Maximum file size
	 */
	public function upload_size_limit ( $bytes ) {
        return apply_filters( 'describr_files_upload_limit', $bytes );
	}

    /**
	 * Deletes avatar by the way of ajax
	 */
	public function action_remove_avatar () {
        if ( ! empty( $_POST['user_id'] ) ) {
            $user_id  = ( int ) $_POST['user_id'];

            if ( defined( 'DOING_AJAX' ) && DOING_AJAX && current_user_can( 'edit_user', $user_id ) && ! empty( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], self::$plugin . '_remove_avatar_nonce' ) ) {
                //Delete old avatar.
                self::avatar_delete( $user_id );
                
                //Send the updated image to the client.
                echo $this->get_the_avatar( $user_id );
            } else {
                wp_die( __( 'You do not have permission to edit this profile.', 'describr' ) );
            }
        }
        
        exit;
    }

	/**
	 * Assigns the avatar's ID, which was issued by WordPress' media library, upon
     * uplaoding of the avatar by the way of ajax
	 */
	public function action_assign_avatar () {
        if ( ! empty( $_POST['user_id'] ) && ! empty( $_POST['media_id'] ) ) {
            $user_id  = ( int ) $_POST['user_id'];
            $media_id = ( int ) $_POST['media_id'];
            
            if ( current_user_can( 'upload_files' ) && current_user_can( 'edit_user', $user_id ) && ! empty( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], self::$plugin . '_assign_from_media_library_avatar_nonce' ) ) {
                //Ensure media exist and is an image.
                if ( wp_attachment_is_image( $media_id ) ) {
                    $this->assign_avatar( $media_id, $user_id );
                }
                
                //Send the new image to the client.
                echo $this->get_the_avatar( $user_id );
            }
        }
        
        exit;
	}

	/**
	 * Deletes avatar from both the database and the filesystem
	 *
	 * @param int  $user_id         ID of the user whose avatar should be deleled
     * @param bool $update_database Whether to update the avatar's info in the database 
	 */
	public static function avatar_delete ( $user_id, $update_database = true ) {
        $user = get_user_by( 'id', $user_id );
		
        $plugin = self::$plugin;

        if ( $user && $user->$plugin ) {
            $profile_info = $user->$plugin;
            
            if ( empty( $profile_info['avatar'] ) ) {
                return;
            }

            $existing_avatar = $profile_info['avatar'];
                        
            if ( isset( $existing_avatar['media_id'] ) ) {
                //Delete the post related to this image.
                wp_delete_attachment( $existing_avatar['media_id'], true );
                unset( $existing_avatar['media_id'] );
            }

            if ( isset( $existing_avatar[ self::$visibility_key ] ) ) {
                unset( $existing_avatar[ self::$visibility_key ] );
            }

            if ( isset( $existing_avatar[ self::$approval_key ] ) ) {
                unset( $existing_avatar[ self::$approval_key ] );
            }

            if ( isset( $existing_avatar['updated_by'] ) ) {
                unset( $existing_avatar['updated_by'] );
            }

            if ( ! empty( $existing_avatar ) ) {
                $upload_path = wp_get_upload_dir();

                foreach ( $existing_avatar as $size => $path ) {
                    $existing_avatar_path = $upload_path['basedir'] . $path;
                
                    if ( file_exists( $existing_avatar_path ) ) {
                        unlink( $existing_avatar_path );
                    }
                }
            }
            
            if ( $update_database ) {
                unset( $profile_info['avatar'] );

                self::update_user_meta( $user_id, $profile_info );
            }
        }
	}
    
    /**
     * Removes WordPress' baseurl from avatar's URL, leaving: /YYYY/MM/filename
     * 
     * @param string $path Absolute URL of avatar
     * @return string Avatar's file path, save for WordPress' baseurl
     */
    public function avatar_remove_baseurl ( $path = '' ) {
        if ( $path ) {            
            $url_parts = preg_split( '#/uploads/#', $path );
            
            if ( 2 === count( $url_parts ) ) {
                $path = '/' . $url_parts[1];
            }
        }

        return $path; 
    }
    
    /**
     * Plugin's filter that gives the ability to resize the avatar
     *
     * @param bool $allow_resize Whether resizing can take place
     * @return bool True if resizing of avatar should occur. False if resizing should
     *              not occur.
     */
    public function avatar_dynamic_resize ( $allow_resize = true ) {
        return $allow_resize;
    }

	/**
     * Creates a unique, meaningful file name for uploaded avatars
     *
     * @param  string $dir  Path for file
     * @param  string $name Filename
     * @param  string $ext  File extension (e.g., ".jpg")
     * @return string Unique filename
     */
    public function unique_filename_callback ( $dir, $name, $ext ) {
        if ( file_exists( $dir . "/$name$ext" ) ) {
            $number = 1;

            $user = get_user_by( 'id', $this->upload_avatar_user_id );
        
            if ( $user ) {
                $user_name = $user->user_login;
            } else {
                $user_name = time();
            }
        
            $filename          = md5( $user_name . '_avatar_' . time() );
            $returned_filename = $filename;

            //Ensure no conflicts with existing file names
            while ( file_exists( $dir . "/$returned_filename$ext" ) ) {
                $returned_filename = $filename . '_' . $number;

                $number++;
            }

            return $returned_filename . $ext;
        } else{
            return $name . $ext;
        }
    }
    
    /**
	 * Adds to WP_Error object error messages that might be encountered when updating a section
	 *
	 * @param WP_Error object $errors Object for adding error messages
	 */
	public function user_profile_update_errors ( WP_Error $errors ) {
        if ( ! empty( $this->profile_update_errors ) ) {
            foreach ( $this->profile_update_errors as $profile_section => $error ) {
                $errors->add( $profile_section, esc_html( $error ) );
            }
        }
	}
	
    /**
     * Attaches "enctype" attribute to html form. This attribute is required for to submit files
     */
    public function user_avatar_edit_form_tag () {
        echo 'enctype="multipart/form-data"';
    }

    /**
     * Carries out post-activation operations
     * 
     * Registers and adds avatar's setting field in Administration's Discussion screen
     */
    public function admin_init() {
        $plugin = self::$plugin;
        $option = $plugin . '_avatars';

        //Check if the plugin has just been activated and set plugin-specific user meta and option.
        if ( get_option( $plugin . '_is_activated' ) ) {
            delete_option( $plugin . '_is_activated' );

            foreach ( get_users() as $user ) {
                $this->plugin_user_meta( $user->ID );
            }

            add_option( $option, array( 'only' => 0 ) );
        }
    	
        register_setting( 
            'discussion', 
            $option, 
            array( 
                'type'              => 'integer',
                'sanitize_callback' => array( $this, 'sanitize_avatars_option' ),
                'Default'           => 0,
            )
        );
        
        //Add row to html table in admin/settings/discussion
        add_settings_field(
			'pt-avatars-only',
			$this->plugin_name . ' Avatar',//Row header
			array( $this, 'avatar_settings_field' ),//Row data
			'discussion',//Page
			'avatars',//Section on page
            //Arguments passed to callback, the 3rd argument of this function (add_settings_field)
			array(
				'key'       => 'only',
                'label_for' => $option,
			)
		);        
    }
    
    /**
	 * Sanitizes avatar option field value before it is saved
	 *
	 * @param  array $input Input value to sanitize
	 * @return array Sanitized input value
	 */
    public function sanitize_avatars_option ( $input ) {
    	$new_input['only'] = isset( $input['only'] ) ? ( int ) $input['only'] : 1;

		return $new_input;
    } 

    /**
	 * Settings field for avatar upload capabilities
	 *
	 * @param array $args Field arguments
	 */
	public function avatar_settings_field ( $args ) {
		$args = wp_parse_args(
			$args,
			array( 'key' => '' )
		);
        
        $option = self::$plugin . '_avatars';

		if ( empty( $this->avatar_permissions[ $args['key'] ] ) ) {
			$this->avatar_permissions[ $args['key'] ] = 0;
		}
        
		echo '<label>
				<input id="' . $option . '" type="checkbox" name="' . $option . '[' . esc_attr( $args['key'] ) . ']" value="1" ' . checked( $this->avatar_permissions[ $args['key'] ], 1, false ) . '>
				' . __( 'Use as main Avatar (default to Gravatar)', 'describr' ) . '
			</label>';
	}    

    /**
     * Adds Publish/Unpublish options to bulk actions menu on users' screen 
     *
     * @param array $actions Options list
     * @return array Menu with new options added
     */
    public function bulk_actions ( $actions ) {
        if ( current_user_can( 'edit_others_posts' ) ) {
            $actions['pt_publish']   = __( 'Publish', 'describr' ); 
    		$actions['pt_unpublish'] = __( 'Unpublish', 'describr' );
    	}
        
       	return $actions;
    }
      
    /**
     * Processes publish/unpublish bulk actions generated on users' screen
     *
     * @param string $redirect_to The redirect URL
     * @param string $doaction    The action being taken
     * @param array $user_ids     Ids of users for whom action is to be taken
     * @return string Url to redirect to 
     */
    public function bulk_actions_handler ( $redirect_to, $doaction, $user_ids ) {
        $notice    = 'fail';
        $published = self::$plugin . '_published';

    	if ( current_user_can( 'edit_others_posts' ) ) {
            foreach( $user_ids as $user_id ) {
                $user_id = ( int ) $user_id;
    			$user    = get_user_by( 'ID', $user_id );

                if ( $user ) {
                    if( 'pt_publish' == $doaction ) {
                        update_user_meta( $user_id, $published, 1, 0 );
            	    } elseif ( 'pt_unpublish' == $doaction ) {
                        update_user_meta( $user_id, $published, 0, 1 );
            	    }
            	}
            }
    		
            $notice = 'success';
        }    
        
        return add_query_arg( 'manage_privilege', $notice, $redirect_to );
    }

    /**
     * Chooses the most appropriate name for the user: first name and last name, login
     * name, nicename, or display name, in that order
     *
     * @param WP_User object User info
     * @return string Best available name for the user or empty string
     */
    public function username_to_use ( $user ) {
        $name = '';

        $plugin_userdata = '';
        
        if ( ! $user ) {
            return $name;
        }

        if ( isset( $user->describr ) ) {
            $plugin_userdata = $user->describr;
        }

        if ( $plugin_userdata ) {
            if ( isset( $plugin_userdata['badge']['first_name'] )  && '' != trim( $plugin_userdata['badge']['first_name'] ) ) {
                $name = $plugin_userdata['badge']['first_name'];

                if ( isset( $plugin_userdata['badge']['last_name'] ) && '' != trim( $plugin_userdata['badge']['last_name'] ) ) {
                    $name .= ' ' . $plugin_userdata['badge']['last_name'];
                }

                $name = sprintf(
                    '%s', 
                    $name 
                );
            } elseif ( isset( $plugin_userdata['badge']['first_name'] ) && isset( $plugin_userdata['badge']['last_name'] ) && '' != trim( $plugin_userdata['badge']['first_name'] ) && '' != trim( $plugin_userdata['badge']['last_name'] ) ) {
                $name = sprintf(
                    '%1$s %2$s', 
                    $plugin_userdata['badge']['first_name'], 
                    $plugin_userdata['badge']['last_name'] 
                );
            }
        }
        
        if ( ! $name ) {
            if ( isset( $user->first_name ) && isset( $user->last_name ) && '' != trim( $user->first_name ) && '' != trim( $user->last_name ) ) {
                $name = sprintf( 
                    '%1$s %2$s', 
                    $user->first_name, 
                    $user->last_name 
                );
            } elseif ( isset( $user->display_name ) && '' != trim( $user->display_name ) ) {
                $name = sprintf(
                    '%s',
                    $user->display_name
                );
            } elseif ( isset( $user->user_nicename ) ) {
                $name = sprintf(
                    '%s',
                    $user->user_nicename
                );
            } elseif ( isset( $user->user_login ) ) {
                $name = sprintf(
                    '%s',
                    $user->user_login
                );
            } elseif ( isset( $user->nickname ) ) {
                $name = sprintf(
                    '%s',
                    $user->nickname
                );
            }
        }
        
	    return $name;
    }
    
    /**
     * Sets admin notices
     */
    public function admin_notices () {
        if ( ! empty( $_GET['page'] ) && self::$plugin == $_GET['page'] ) {
            settings_errors();
    	}

    	if ( ! empty( $_GET['manage_privilege'] ) ) {
            $translations = $this->translation_javascript();
            
            $message = __( 'Changes saved successfully.', 'describr' );
    		
            $class  = 'success';

    		if ( 'fail' == $_GET['manage_privilege'] ) {
                $message = __( 'Failed to save changes. Please try again.', 'describr' );
    			$class   = 'error';
            }

    		echo '<div class="notice notice-' . $class . ' is-dismissible"> 
	                 <p><strong>' . $message . '</strong></p>
	                 <button type="button" class="notice-dismiss">
		                   <span class="screen-reader-text">' . $translations['general'][49] . '</span>
	                 </button>
                 </div>';
    	}
    }
    
    /**
     * Adds plugin-specific columns to Users screen 
     *
     * @param array $columns Existing columns
     * @return array Columns added to existing columns
     */
    public function customize_user_columns ( $columns ) {
        $plugin = self::$plugin . '_';
        
        $translations = $this->translation_javascript();
        
        if ( is_array( $columns ) ) {
            $columns[ $plugin . 'published' ]  = $translations['labels']['sections'][0];
            $columns[ $plugin . 'reg_date' ]   = __( 'Registration Date', 'describr' );
            $columns[ $plugin . 'last_login' ] = __( 'Last Login', 'describr' );
        }
        
    	return $columns;
    }

    /**
     * Adds table data to the table on Users screen
     *
     * @param string $val     Existing table data
     * @param string $column  Column being operated on
     * @param int    $user_id User ID
     * @return string Updated table data
     */
    public function costumize_user_columns_data ( $table_data, $column, $user_id ) {
        $user = get_userdata( $user_id );

        if ( ! $user ) {
            return $table_data;
        }

        $name = $this->username_to_use( $user );

        $plugin = self::$plugin . '_';
        
        if ( $plugin . 'published' == $column ) {
            $published = $user->describr_published;
            
            $table_data .= '<span class="dashicons-before dashicons-' . ( $published ? 'yes' : 'no-alt' ) . '"></span>';
        } elseif ( $plugin . 'reg_date' == $column ) {
        	$table_data .= $this->datetime( $user->describr_reg_date );
        } elseif ( $plugin . 'last_login' == $column ) {
            $sessions = WP_Session_Tokens::get_instance( $user_id );
            
            if ( isset( $user->describr_last_login ) ) {
                $table_data .= '<div>' . $this->datetime( $user->describr_last_login ) . '</div>';
        	}

        	if ( count( $sessions->get_all() ) ) {
                $table_data .= '<div class="column-describr_last_login"><span title="';
                $table_data .= sprintf(
                    /*translators: %s: User's name*/
                    esc_attr__( '%s Is Logged In', 'describr' ),
                    $name     
                );
                $table_data .= '" class="dashicons-before dashicons-unlock"></span></div>';
        	}
        }
    	
    	return $table_data;
    }

    /**
     * Set columns that should be sortable on Users screen
     *
     * @var array $columns Sortable columns
     * @return array Sortable columns
     */
    public function users_sortable_columns ( $columns ) {
        $plugin = self::$plugin . '_';
        
        if ( is_array( $columns ) ) {
            $columns[ $plugin . 'reg_date' ]   = $plugin . 'reg_date';
            $columns[ $plugin . 'published' ]  = $plugin . 'published';
            $columns[ $plugin . 'last_login' ] = $plugin . 'last_login';
        }
        
        return $columns;
    }
    
    /**
     * Creates user-friendly UTC offset
     * 
     * Places two digits (pads with zeros) on either side of the colon
     * 
     * @param float $offset The UTC offset
     * @return string user-friendly UTC
     */
    public function utc_user_friendly ( $offset = 0 ) {
        $offset  = ( float ) $offset;
        $hours   = ( int ) $offset;
        $minutes = ( $offset - $hours );
 
        $sign      = ( $offset < 0 ) ? '-' : '+';
        $abs_hour  = abs( $hours );
        $abs_mins  = abs( $minutes * 60 );

        return sprintf( '%s%02d:%02d', $sign, $abs_hour, $abs_mins );
    }
    /**
     * Checks if UTC exists
     * 
     * @param string The UTC to check against
     * @return string|bool The UTC passed as argument, False otherwise
     */
    public function get_utc ( $utc = '' ) {
        foreach ( $this->utc_range as $key => $value ) {
            if ( ( string ) $utc === ( string ) $value ) {
                return $utc; 
            }
        }

        return false;
    }
    /**
     * Validates UTC
     * 
     * @param string $utc The UTC to validate
     * @return string|bool True if the UTC was found, False otherwise
     */
    public function is_utc ( $utc = '' ) {
        return false !== $this->get_utc( $utc );
    }
    
    /**
     * Checks if time zone exists
     * 
     * @param string $timezone  The time zone to validate
     * @return string The time zone argument, otherwise empty string
     */
    public function get_timezone ( $timezone = '' ) {
        foreach ( timezone_identifiers_list() as $key => $value ) {
            if ( ( string ) $timezone === ( string ) $value ) {
                return $timezone ;
            }
        }

        return $timezone ;
    } 

    /**
     * Fetches the time zone or UTC to use to format the datetime shown to users.
     * 
     * Defaults to either time zone or UTC set in wp-admin 
     * 
     * Defaults to the site's time zone.  
     *
     * @param string $timezone User-supplied time zone or UTC offset
     * @return string Time zone or UTC (in dd:dd format)
     */
    public function timezone_to_use ( $timezone = '' ) {
        $timezone = $this->get_timezone( $timezone );

        if ( $timezone ) {
            return $timezone;
        } else {
            $timezone = $this->get_utc( $timezone );

            if ( false !== $timezone ) {
                return $this->utc_user_friendly( $timezone );
            }
        }

        return wp_timezone_string();
    }

    /**
     * Validates time zone
     * 
     * @param string $timezone The time zone to validate
     * @return bool True if the time zone is one in timezone_identifiers_list(), False otherwise
     */
    public function is_timezone ( $timezone = '' ) {
        return '' !== $this->get_timezone( $timezone );
    }

    /**
     * Returns site's time zone or UTC
     *
     * @return string Time zone or UTC
    */
	public function default_timezone_or_utc () {
        $timezone = get_option( 'timezone_string' );
           
        if ( ! $timezone ) {
            $timezone = get_option( 'gmt_offset' );
        }
		
        return $this->sanitize_txt( $timezone );
	}
    
    /**
     * Creates formatted date and time
     *
     * @param int|string $timestamp Timestamp or date to format
     * @param string     $timezone  Time zone to use to set date
     * @param string     $format    Date format to use to set date
     * @return Formatted date.
     */
    public function datetime ( $timestamp = '', $timezone = '', $format = '' ) {
        if ( ! $timezone ) {
            //Fetches the time zone to use to format the date and time shown to users.
            $timezone = $this->timezone_to_use();
        }

    	if ( ! $format ) {
            /*translators: draft saved date format, see http://php.net/date*/
            $format = __( 'F j, Y h:i A', 'describr' );
        }

        if ( ! $timestamp ) {
            $timestamp = time();
        }

    	$datetime = new DateTime( 'now', new DateTimeZone( $timezone ) );
        
        if ( ! is_int( $timestamp ) && is_numeric( $timestamp ) ) {
            $timestamp = (int) $timestamp;
        } elseif ( is_string( $timestamp ) ) {
            $timestamp = strtotime( $timestamp );
        }

        $datetime->setTimestamp( $timestamp );
        
        return $datetime->format( $format );
    }
    
    /**
     * Validates datetime
     * 
     * @param string $date The date to validate
     * @return bool True if the date is a valid, False otherwise
     */
    public function is_date ( $date = '' ) {
        return 1 === preg_match( '/^[0-9]{4}(\-[0-9]{2})?(\-[0-9]{2})?$/', $date );
    }
    
    /**
     * Creates string representation of partial, numeric date saved by the user
     * 
     * @param string $date The date in question
     * @return string A string representation of the date
     */
    public function create_date ( $date = '' ) {
        if ( ! $date ) {
            return '';
        }
        
        $date_array  = explode( '-', $date );
        $date_length = count( $date_array );

        if ( 3 === $date_length ) {
            /*translators: draft saved date format, see http://php.net/date*/
            $format = __( 'M j, Y', 'describr' );
        } elseif ( 2 === $date_length ) {
            /*translators: draft saved date format, see http://php.net/date*/
            $format = __( 'M Y', 'describr' );
            //Only year and month are present, so we add day so that a complete date string is sent to strotime.
            $date .= '-01';
        } else {
            /*translators: draft saved date format, see http://php.net/date*/
            $format = __( 'Y', 'describr' );
            $date .= '-01-01';//Only year is present, so we add month and day.
        }

        $strtotime = strtotime( $date );
        
        if ( ! $strtotime ) {
            return '';
        }
        
        return date( $format, $strtotime );
    }       
    
    /**
     * Sets usermetas immediately upon new-user registration
     *
     * @param int   $user_id  User ID
     * @param array $userdata The raw array of data passed to wp_insert_user()
     */
    public function user_register ( $user_id, $userdata ) {
        $this->plugin_user_meta( $user_id, $userdata );
    }
    
    /**
     * delete_user hook callback function
     * 
     * Deletes the avatar from the filesystem just before the account is deleted
     * 
     * @param int $id User ID
     */
    public function delete_user ( $id ) {
        self::avatar_delete( $id, false );
    }

    /**
     * wp_login hook callback function
     * 
     * Updates the date the user logins last to the current date and time
     *
     * @param string         $user_login Login name of user
     * @param WP_User object $user       User data       
     */
    public function logged_in ( $user_login, $user ) {
       //Update log-in date
        update_user_meta( $user->ID, self::$plugin . '_last_login', time() );
    }
    
    /**
     * Updates plugin's main user meta
     *
     * @param int    $user_id      User ID
     * @param array  $old_userdata Old user data
     * @param array  $new_userdata New user data
     */
    public static function update_user_meta ( $user_id, array $old_userdata, $new_userdata = array() ) {
        if ( $new_userdata ) {
            update_user_meta( $user_id, self::$plugin, array_merge_recursive( $old_userdata, $new_userdata ) );
        } else {
            update_user_meta( $user_id, self::$plugin, $old_userdata );
        }
    }    
    
    /**
     * Creates indicator for max upload file size
     * 
     * @return string Max upload file size
     */
    public function display_max_upload_size () {
        $max_upload_size = wp_max_upload_size();
    	$unit            = array( 'KB', 'MB', 'GB', 'TB' );
    	$i               = 0;
    	$bytes           = 1000;
        
        while( $bytes <= $max_upload_size ) {
    		$max_upload_size /= $bytes ;

    		$i++;
        }
        
    	return ( round( $max_upload_size, 1 ) . ' ' . $unit[ $i ] );
    }
    
    /**
     * Validates image file
     *
     * @param string $filename Name of file being uploaded
     * @return boolean True if file type is supported, False otherwise
     */
    public function is_image ( $filename ) {
        $fileparts      = explode( '.', $filename );
        $file_extension = end( $fileparts );
       
        foreach ( $this->supported_image_types as $key => $mime ) {
            if ( 1 === preg_match( '#' . $mime . '#i', $file_extension ) ) {
                return true;
            }
        }
       
       return false;
    }
    
    /**
     * Formulates message to be displayed when image file type is not supported
     *  
     * @param string $filename Name of file
     * @return string Notice indicating the types of image files that are supported
     */
    public function unsupported_imagefile_message ( $filename ) {
        return sprintf(
            /*translators: %s: Filename, %s: File extensions*/
            __( '%s file type not supported. Supported image file types: %s.', 'describr' ),
            basename( $filename ),
            implode( ', ', $this->supported_image_types ) 
        );
    }
    
    /**
     * Customizes error messages that might be shown if problems arise during uploading of image file
     *
     * @return array Error messages
     */
    public function upload_error_strings () {
        return array(
            false,
            sprintf(
                /* translators: %s: upload_max_filesize */
                __( 'The uploaded file exceeds the maximum upload size for this site. Maximum upload file size: %s.', 'describr' ),
                $this->display_max_upload_size()
            ),
            sprintf(
                /* translators: %s: MAX_FILE_SIZE */
                __( 'The uploaded file exceeds the %s directive that was specified in the HTML form.', 'describr' ),
                'MAX_FILE_SIZE'
            ),
            __( 'The uploaded file was only partially uploaded.', 'describr' ),
            __( 'No file was uploaded.', 'describr' ),
            '',
            __( 'Missing a temporary folder.', 'describr' ),
            __( 'Failed to write file to disk.', 'describr' ),
            __( 'File upload stopped by extension.', 'describr' ),
        );
    }
    
    /**
     * Sanitizes a string from user input
     * 
     * Strips newlines
     * 
     * Substitutes invalid UTF-8
     * 
     * Converts applicable characters to HTML entities
     * 
     * @param string $string String to sanitize
     * @return string The sanitized string
     */
    public function sanitize_txt ( $string = '' ) {
        $string = ( string ) trim( $string );

        if ( 0 === strlen( $string ) ) {
            return $string;
        }

        $string = preg_replace( '/[\r\n\t]+/', ' ', $string );

        return htmlentities( $string, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8', false );
    }

    /**
     * Removes duplicate values from an array, irrespective of case
     * 
     * Reindexes array
     * 
     * @param array $array The array in question
     * @return array Array containing unique values
     */
    public function unique_array_values ( $array = array() ) {
        if ( is_array( $array ) && ! empty( $array ) ) {
            $lowered = array_map( 'strtolower', $array );

            $array = array_intersect_key( $array, array_unique( $lowered ) );

            $array = array_values( $array );
        }

        return $array;
    }
    
    /**
     * Sanitizes user-submitted URLs
     * 
     * @param string $user_url URL
     * @return string|bool Sanitized URL, otherwise False if the URL is invalid
     */
    public function validate_url ( $user_url = '' ) {
        if ( empty( $user_url ) ) {
            return false;
        }

        if ( 1 !== preg_match( '/^(https?:\/\/)/', $user_url ) ) {
            $user_url = 'http://' . $user_url;
        }

        $parsed_url = wp_parse_url( $user_url );
                                        
        if ( false !== $parsed_url && ! empty( $parsed_url['host'] ) && 1 === preg_match( '/[a-z0-9\.-]{3,}\.[a-z]{2,}(\.[a-z]{2,})?/i', $parsed_url['host'] ) ) {
            $href = '';

            if ( ! empty( $parsed_url['scheme'] ) && ( 'http' === $parsed_url['scheme'] || 'https' === $parsed_url['scheme'] ) ) {
                $href = $parsed_url['scheme'];
            }

            if ( ! $href ) {
                $href = 'http';
            }

            $href .= '://';
                
            $href = $href . $parsed_url['host'];

            if ( isset( $parsed_url['path'] ) && '' !== $parsed_url['path'] ) {
                $href .= '/' . rawurlencode( ltrim( $parsed_url['path'], '/' ) );
            }

            if ( isset( $parsed_url['query'] ) && '' !== $parsed_url['query'] ) {
                $href .= '?' . rawurlencode( $parsed_url['query'] );
            }

            if ( isset( $parsed_url['fragment'] ) && '' !== $parsed_url['fragment'] ) {
                $href .= '#' . rawurlencode( $parsed_url['fragment'] );
            }

            return $href;
        }

        return false;
    }

    /**
     * Provides central location for most translated texts
     * 
     * @return array Translated texts
     */
    public function translation_javascript () {
        return array(
            'privacy' => array(
                __( 'Everyone', 'describr' ), 
                __( 'Only me', 'describr' ), 
            ),
            'choose' => array(
                __( 'Choose an image', 'describr' ),//0
                __( 'Choose a country', 'describr' ),//1
                __( 'Choose your gender', 'describr' ),//2
                __( 'Choose an image from your computer:', 'describr' ),//3
                __( 'Choose your time zone', 'describr' ),//4
                /*translators: %s: Profile's section*/
                __( 'Choose a privacy status for %s'),//5
                __( 'Choose a Partner', 'describr' ),//6
                __( 'Choose a Language', 'describr' ),//7
                __( 'Choose a City', 'describr' ),//8
                __( 'Choose your relationship status', 'describr' ),//9
                __( 'Choose a year', 'describr' ),//10
                __( 'Choose a month', 'describr' ),//11
                __( 'Choose a day', 'describr' ),//12
            ),
            'general' => array(
                __( 'Upload Avatar', 'describr' ),//0
                __( 'Update profile picture', 'describr' ),//1
                __( 'Remove profile picture', 'describr' ),//2               
                __( 'Set as profile picture', 'describr' ),//3
                __( 'Country', 'describr' ),//4                
                __( 'Phone number', 'describr' ),//5
                __( 'Please try again.', 'describr' ),//6
                __( 'Cancel', 'describr' ),//7
                _x( 'extension','Phone number extension', 'describr' ),//8                
                __( 'to', 'describr' ),//9
                __( 'by', 'describr' ),//10
                __( 'from', 'describr' ),//11
                __( 'with', 'describr' ),//12
                __( 'First name', 'describr' ),//13
                __( 'Last name', 'describr' ),//14
                __( 'Enter your current city', 'describr' ),//15
                __( 'Enter your hometown', 'describr' ),//16      
                __( 'This profile has been deemed inappropriate for public viewing. If you are the owner of this profile, a full explanation for this action was sent to the email on file that is associated with this account.', 'describr'),//17
                __( 'Search languages', 'describr' ),//18
                __( 'Search', 'describr' ),//19
                __( 'Selected values', 'describr' ),//20
                __( 'Remove', 'describr' ),//21
                __( 'Edit', 'describr' ),//22
                __( 'City', 'describr' ),//23
                __( 'Enter a city', 'describr' ),//24
                __( 'Moved', 'describr' ),//25
                __( 'Biography', 'describr' ),//26
                __( 'Unpublished', 'describr' ),//27
                __( 'Clear', 'describr' ),//28
                __( 'Time period', 'describr' ),//29
                __( 'Description', 'describr' ),//30
                __( 'in', 'describr' ),//31
                __( 'Share a little about you', 'describr' ),//32
                __( 'Profile data has been loaded.', 'describr' ),//33
                __( 'The following content has been unpublished because it violated our <a href="/terms">terms of service</a>. However, you can make the necessary changes to have it published.' ,'describr' ),//34              
                __( 'The website URL you provided is invalid. Please enter a correct URL and try again.', 'describr' ),//35
                __( 'Social network', 'describr' ),//36
                __( 'Username', 'describr' ),//37
                __( 'Website address', 'describr' ),//38
                __( 'Profile picture actions', 'describr' ),//39
                __( 'No profile picture actions approved', 'describr' ),//40
                __( 'This profile is published.', 'describr' ),//41
                __( 'This profile is unpublished.', 'describr' ),//42
                _x( 'Male', 'Gender', 'describr' ),//43
                _x( 'Female', 'Gender', 'describr' ),//44
                _x( 'and', 'Join a list of items', 'describr' ),//45
                __( 'Privacy', 'describr' ),//46
                __( 'Last updated', 'describr' ),//47
                __( 'Basic Info', 'describr' ),//48
                __( 'Dismiss this notice.', 'describr' ),//49
            ),
            'placeholders' => array(
                /*translators: %s: Number of characters*/
                __( '%d characters', 'describr' ),//0
                /*translators: 1: Number of characters, 2: Number of characters allowed*/
                __( 'You have typed %1$d of the %2$d characters allowed.', 'describr' ),//1
                /*translators: %s Name of image, %s: Image MIME type*/
                __( '%s file type not supported. Supported file types: %s.', 'describr' ),//2
                /*translators: %s Name of image, %s: Maximum upload file size*/
                __( '%s exceeds the maximum upload size for this site. Maximum upload file size: %s.', 'describr' ),//3
                /*translators: %s: Profile section*/ 
                __( 'Privacy status for %s', 'describr' ),//4       
                /*translators: %s: Profile section*/ 
                __( '%s is published', 'describr' ),//5       
                /*translators: %s: Profile section*/ 
                __( '%s is unpublished', 'describr' ),//6
                /*translators: %s: Profile section*/ 
                __( 'Unpublish %s', 'describr' ),//7
                /*translators: %s: Profile section*/ 
                __( 'Publish %s', 'describr' ),//8
                /*translators: %s: User's name*/
                __( '%s Is Not Logged In', 'describr' ),//9
                /*translators: %s: User's name*/
                __( '%s Is Logged In', 'describr' ),//10
                /*translators: %s: User's profile name*/ 
                __( '%s picture actions', 'describr' ),//11 
                /*translators: %s: User's profile name*/ 
                __( 'Remove %s profile picture', 'describr'  ),//12
                /*translators: %s: Plugin's name*/ 
                __( 'You can set %s Avatar as your default avatar in settings>discussion>avatars.', 'describr'  ),//13
                /*translators: %s Date*/
                __( 'Moved %s', 'describr' ),//14 
                /*translators: %s: User's name*/
                __( '%s profile data has been loaded.', 'describr' ),//15
            ),
            'labels'  => array(
                'sections' => array(
                    __( 'Published', 'describr' ),//0
                    __( 'Avatar', 'describr' ),//1
                    _x( 'Tagline', 'slogan', 'describr' ),//2
                    __( 'Name', 'describr' ),//3
                    __( 'Gender', 'describr' ),//4 
                    __( 'Birthdate', 'describr' ),//5
                    _x( 'Bio', 'Biography', 'describr' ),//6
                    __( 'Addresses', 'describr' ),//7
                    __( 'Hometown', 'describr' ),//8
                    __( 'Current City', 'describr' ),//9
                    __( 'Cities Lived', 'describr'), //10
                    __( 'Relationship', 'describr' ),//11
                    __( 'Languages', 'describr' ),//12
                    __( 'Contact', 'describr' ),//13
                    __( 'Phone', 'describr' ),//14
                    __( 'Email Address', 'describr' ),//15
                    __( 'Time Zone', 'describr' ),//16
                    __( 'Social Networks' , 'describr' ),//17
                    __( 'Websites', 'describr' ),//18
                    __( 'Work', 'describr' ),//19
                    __( 'Education', 'describr' ),//20
                    __( 'College', 'describr' ),//21
                    __( 'High School', 'describr' ),//22
                ),
                'section_events' => array(
                    /*translators: %s: User's name*/
                    __( 'View %s colleges editors', 'describr' ),//0
                    /*translators: %s: User's name*/
                    __( '%s colleges editors', 'describr' ),//1
                    /*translators: %s: User's name*/
                    __( 'View %s high schools editors', 'describr' ),//2
                    /*translators: %s: User's name*/
                    __( '%s high school editors', 'describr' ),//3
                    /*translators: %s: User's name*/
                    __( '%s profile photo editors', 'describr' ),//4                
                    /*translators: %s: User's name*/
                    __( 'View %s profile photo editors', 'describr' ),//5            
                    /*translators: %s: User's name*/
                    __( '%s addresses editors', 'describr' ),//6
                    /*translators: %s: User's name*/
                    __( 'View %s addresses editors', 'describr' ),//7             
                    /*translators: %s: User's name*/
                    __( '%s phone number editors', 'describr' ),//8                  
                    /*translators: %s: User's name*/
                    __( 'View %s phone numbers editors', 'describr' ),//9                    
                    /*translators: %s: User's name*/
                    __( '%s email editors', 'describr' ),//10                    
                    /*translators: %s: User's name*/
                    __( 'View %s email editors', 'describr' ),//11                    
                    /*translators: %s: User's name*/
                    __( '%s name editors', 'describr' ),//12                   
                    /*translators: %s: User's name*/
                    __( 'View %s name editors', 'describr' ),//13
                    /*translators: %s: User's name*/
                    __( '%s gender editors', 'describr' ),//14                   
                    /*translators: %s: User's name*/
                    __( 'View %s gender editors', 'describr' ),//15                    
                    /*translators: %s: User's name*/
                    __( '%s birthdate editors', 'describr' ),//16                    
                    /*translators: %s: User's name*/
                    __( 'View %s birthdate editors', 'describr' ),//17                
                    /*translators: %s: User's name*/
                    __( '%s biography editors', 'describr' ),//18                   
                    /*translators: %s: User's name*/
                    __( 'View %s biography editors', 'describr' ),//19                    
                    /*translators: %s: User's name*/
                    __( '%s time zone editors', 'describr' ),//20                    
                    /*translators: %s: User's name*/
                    __( 'View %s time zone editors', 'describr' ),//21                   
                    /*translators: %s: User's name*/
                    __( '%s social networks editors', 'describr' ),//22                   
                    /*translators: %s: User's name*/
                    __( 'View %s social networks editors', 'describr' ),//23                    
                    /*translators: %s: User's name*/
                    __( '%s Web site editors', 'describr' ),//24                    
                    /*translators: %s: User's name*/
                    __( 'View %s Web site editors', 'describr' ),//25                    
                    /*translators: %s: User's name*/
                    __( '%s Work editors', 'describr' ),//26
                    /*translators: %s: User's name*/
                    __( 'View %s Work editors', 'describr' ),//27
                ),
            ),
            'contact' => array(
                'phones' => array(
                    'country' => __( 'Phone number country', 'describr' ),
                    'types'  => array(
                        'MOBILE'               => _x( 'Mobile','cellular phone', 'describr' ),
                        'FIXED_LINE'           => _x( 'Fixed line', 'land line phone', 'describr' ),
                        'FIXED_LINE_OR_MOBILE' => _x( 'Fixed line or mobile', 'cellular phone or land line', 'describr' ),
                        'PREMIUM_RATE'         => __( 'Premium rate', 'describr' ),
                        'SHARED_COST'          => _x( 'Shared cost', 'An intermediate level of telephone call billing where the charge for calling a particular international or long-distance phone number is partially, but not entirely, paid for by the recipient', 'describr' ),
                        'VOIP'                 => 'VOIP',
                        'PERSONAL_NUMBER'      => _x( 'Personal number', 'A phone connected by satellites', 'describr' ),
                        'PAGER'                => _x( 'Pager', 'A wireless telecommunication device', 'describr' ),
                        'VOICEMAIL'            => __( 'Voicemail', 'describr' ),
                    ),
                    'errors' => array(
                        'NOT_A_NUMBER'     => __( 'No phone number was supplied. Phone number must have area code and cannot include alphabetic characters.', 'describr' ),
                        'INVALID_COUNTRY'  => __( 'The country is invalid for this phone number. Make sure to add the correct area code.', 'describr' ),
                        'TOO_SHORT'        => __( 'The phone number is too short.', 'describr' ),
                        'TOO_LONG'         => __( 'The phone number is too long.', 'describr' ),
                        'INCORRECT_FORMAT' => __( 'Phone number format does not match that of the country selected.', 'describr' ),
                    ),
                ),
                'email' => array(
                    'placeholder' => __( 'Enter your email address', 'describr' ),
                    'errors' => array(
                        __( 'Email address must be at least three characters in length.', 'describr' ),
                        __( 'Email address must have at least one @ character.', 'describr' ),
                        __( 'Invalid email address format.' , 'describr' ),
                    ),
                ),
            ),
            'relationship' => array(
                'labels' => array(
                    __( 'Relationship status', 'describr' ),//0
                    __( 'Status', 'describr' ),//1
                    __( 'Partner', 'describr' ),//2
                    __( 'Search for partner', 'describr' ),//3
                    __( 'Since', 'describr' ),//4
                    __( 'since', 'describr' ),//5
                ),
                'status' => array(
                    __( 'Single', 'describr' ),//0
                    __( 'In a relationship', 'describr' ),//1
                    __( 'Engaged', 'describr' ),//2
                    __( 'Married', 'describr' ),//3
                    __( 'Separated', 'describr' ),//4
                    __( 'Divorced', 'describr' ),//5
                    __( 'Widowed', 'describr' ),//6
                    __( 'In a domestic partnership', 'describr' ),//7
                    __( 'In a civil union', 'describr' ),//8
                    __( 'Friends with benifits', 'describr' ),//9
                ),
            ),
            'date' => array(
                __( 'Year', 'describr' ),//0
                __( 'Month', 'describr' ),//1
                __( 'Day', 'describr' ),//2
            ),
            'company' => array(
                __( 'Job description', 'describr' ),//0
                __( 'at', 'describr' ),//1
                __( 'present', 'describr' ),//2
                __( 'Company name', 'describr' ),//3
                __( 'Company', 'describr' ),//4
                __( 'Position', 'describr' ),//5
                __( 'I still work here', 'describr' ),//6
            ),
            'schools' => array(
                'general' => array(
                    __( 'Graduated', 'describr' ),
                ),
                'high_schools' => array(
                    /*translators: %s: School's name*/
                    __( 'Went to %s', 'describr' ),
                    /*translators: %s: School's name*/
                    __( 'Attending %s', 'describr' ),
                ),
                'colleges' => array(
                    /*translators: %s: College minor*/
                    __( 'Also studied %s', 'describr' ),//0
                    /*translators: %s: College minor*/
                    __( 'Also studying %s', 'describr' ),//1
                    __( 'Major', 'describr' ),//2
                    __( 'Minor', 'describr' ),//3
                    __( 'Degree', 'describr' ),//4
                ),
            ),
            'timezone' => array(
                __( 'Manual UTC Offsets', 'describr' ),
                /*translators: %s: Name of continent*/ 
                __( '%s time zones', 'describr' ),
            ),
            'months' => array(
                _x( 'Jan', 'Abbreviated version of January', 'describr' ),
                _x( 'Feb', 'Abbreviated version of February', 'describr' ),
                _x( 'Mar', 'Abbreviated version of March', 'describr' ),
                _x( 'Apr', 'Abbreviated version of April', 'describr' ),
                __( 'May', 'describr' ),
                _x( 'Jun', 'Abbreviated version of June', 'describr' ),
                _x( 'Jul', 'Abbreviated version of July', 'describr' ),
                _x( 'Aug', 'Abbreviated version of August', 'describr' ),
                _x( 'Sept', 'Abbreviated version of September', 'describr' ),
                _x( 'Oct', 'Abbreviated version of October', 'describr' ),
                _x( 'Nov', 'Abbreviated version of November', 'describr' ),
                _x( 'Dec', 'Abbreviated version of December', 'describr' ),
            ),
        );
    }
}