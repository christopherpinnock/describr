<?php
//Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$nonce = 'describr_update_profile_nonce';

if ( ! isset( $_POST[ $nonce ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash ( $_POST[ $nonce ] ) ) , $nonce ) ) {
    return;
}

if ( ! isset( $user_id ) ) {
    return;
}


$is_editor = $this->can_edit_profiles();

if ( ! $is_editor && ! current_user_can( 'edit_user', ( int ) $user_id )  ) {
    return;
}

$user = get_user_by( 'id', ( int ) $user_id );

if ( ! $user ) {
    return;
}

//Array keys for locating user profile sections in both $user->describr and $_POST 
$avatar_key             = 'avatar';
$tagline_key            = 'tagline';
$badge_key              = 'badge';
$gender_key             = 'gender';
$birthdate_key          = 'birthdate';
$bio_key                = 'bio';
$physical_addresses_key = 'addresses';
$relationship_key       = 'relationship';
$lang_key               = 'langs';
$contact_key            = 'contact';
$timezone_key           = 'timezone';
$social_networks_key    = 'socialnetworks';
$websites_key           = 'websites';
$work_history_key       = 'workhistory';
$colleges_key           = 'colleges';
$high_school_key        = 'highschools';

$description_key = 'description';
$graduated_key   = 'graduated' ;
$school_key      = 'schools';

$name = 'name';

$maxlen = $this->maxlen();

$approval_key = $this->array_keys[1];
$privacy_key  = $this->array_keys[2];

$time_span_arr = array(
    'from' => '',
    'to'   => '',
);

$arr = array();

/**
 * Stores updated users' submitted data saved in the database
 * 
 * @var array
 */
$updated_userdata = $arr;

if ( isset( $user->describr ) ) {
    $previously_saved_userdata  = ( array ) $user->describr;
} else {
    $previously_saved_userdata = $arr;
}

$previously_saved_userdata_count = count( $previously_saved_userdata );

if ( isset( $_POST['describr'] ) ) {
    $submitted_data = ( array ) map_deep( wp_unslash( $_POST['describr'] ), 'sanitize_text_field' );

    if ( $is_editor ) {
        if ( isset( $submitted_data['profile']['published'] ) ) {
            if ( ! is_numeric( $submitted_data['profile']['published'] ) ) {
                $this->profile_update_errors['published'] = sprintf(
                    /*translators: %s: User profile published status*/
                    __( '%s is not a valid user profile published status.', 'describr' ),
                    $submitted_data['profile']['published']
                );
            }
        }
        
        if ( ! isset( $this->profile_update_errors['published'] ) ) {
            if ( isset( $submitted_data['profile']['published'] ) ) {
                if ( in_array( ( int ) $submitted_data['profile']['published'], $this->user_int, true ) ) {
                    $submitted_published_value = ( int ) $submitted_data['profile']['published'];

                    if ( isset( $user->describr_published ) ) {
                        if ( ( int ) $user->describr_published !== $submitted_published_value )
                        {
                            update_user_meta( ( int ) $user_id, 'describr_published', $submitted_published_value );
                        }
                    } else {
                        update_user_meta( ( int ) $user_id, 'describr_published', $submitted_published_value );
                    }
                }
            } elseif ( ! isset( $user->describr_published ) || 0 !== ( int ) $user->describr_published ) {
                update_user_meta( ( int ) $user_id, 'describr_published', 0 );
            }
        }
    }
    
    //Uploading of the avatar is done at the bottom of this page
    if ( isset( $submitted_data[ $avatar_key ] ) && is_array( $submitted_data[ $avatar_key ] ) ) {
        $change = false;

        $profile_section = isset( $previously_saved_userdata[ $avatar_key ] ) ? ( array ) $previously_saved_userdata[ $avatar_key ] : $arr;
        
        $this->add_user_profile_section_controls( $profile_section, $submitted_data[ $avatar_key ], $change );
        
        if ( $change ) {
            if ( isset( $previously_saved_userdata[ $avatar_key ] ) ) {
                unset( $previously_saved_userdata[ $avatar_key ] );
            }

            $updated_userdata[ $avatar_key ] = $this->update_user_profile_section_event_log( $profile_section );
        }
    }

    if ( isset( $submitted_data[ $tagline_key ] ) && is_array( $submitted_data[ $tagline_key ] ) ) {
        $submitted_tagline_value = '';

        if ( isset( $submitted_data[ $tagline_key ][ $description_key ] ) ) {
            if ( ! $this->is_string_or_numeric( $submitted_data[ $tagline_key ][ $description_key ] ) ) {
                $this->profile_update_errors[ $tagline_key ] = sprintf(
                    /*translators: %s: Tagline of the user*/
                    __( '%s is not a valid tagline.', 'describr' ),
                    $submitted_data[ $tagline_key ][ $description_key ]
                );
            } elseif ( $maxlen['tagline'] < mb_strlen( ( string ) $submitted_data[ $tagline_key ][ $description_key ] ) ) {
                $this->profile_update_errors[ $tagline_key ] = sprintf(
                    /*translators: 1: Number of characters allowed in tagline of the user, 2: Tagline of the user*/
                    __( 'Tagline cannot have more than %1$d characters: %2$s.', 'describr' ),
                    $maxlen['tagline'],
                    $submitted_data[ $tagline_key ][ $description_key ]
                );
            } else {
                $submitted_tagline_value = $submitted_data[ $tagline_key ][ $description_key ];
            }
        }

        if ( ! isset( $this->profile_update_errors[ $tagline_key ] ) ) {
            $profile_section = isset( $previously_saved_userdata[ $tagline_key ] ) ? ( array ) $previously_saved_userdata[ $tagline_key ] : $arr;

            $change = false;

            $this->update_user_profile_section( $submitted_tagline_value, $description_key, $profile_section, $change, $submitted_data[ $tagline_key ] );
        
            $this->commit_changes_made_to_user_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $tagline_key, $description_key, $change );
        }
    }
    
    if ( isset( $submitted_data[ $badge_key ] ) && is_array( $submitted_data[ $badge_key ] ) ) {
        $badge_first_name_key = 'first_' . $name;
        $badge_last_name_key  = 'last_' . $name;
        
        $submitted_badge_first_name_value = '';
        $submitted_badge_last_name_value  = '';

        $change = false;

        $profile_section = isset( $previously_saved_userdata[ $badge_key ] ) ? ( array ) $previously_saved_userdata[ $badge_key ] : $arr;

        $this->add_user_profile_section_controls( $profile_section, $submitted_data[ $badge_key ], $change );
        
        if ( isset( $submitted_data[ $badge_key ][ $badge_first_name_key ] ) ) {
            if ( ! $this->is_string_or_numeric( $submitted_data[ $badge_key ][ $badge_first_name_key ] ) ) {
                $this->profile_update_errors[ $badge_first_name_key ] = sprintf(
                    /*translators: %s: First name of the user*/
                    __( '%s is not a valid first name.', 'describr' ),
                    $submitted_data[ $badge_key ][ $badge_first_name_key ]
                );
            } elseif ( $maxlen['textbox'] < mb_strlen( ( string ) $submitted_data[ $badge_key ][ $badge_first_name_key ] ) ) {
                $this->profile_update_errors[ $badge_first_name_key ] = sprintf(
                    /*translators: 1: Number of characters allowed in first name of the user, 2: First name of the user*/
                    __( 'First name cannot have more than %1$d characters: %2$s.', 'describr' ),
                    $maxlen['textbox'],
                    $submitted_data[ $badge_key ][ $badge_first_name_key ]
                );
            } else {
                $submitted_badge_first_name_value = $submitted_data[ $badge_key ][ $badge_first_name_key ];
            }
            
            if ( ! isset( $this->profile_update_errors[ $badge_first_name_key ] ) ) {
                if ( '' === ( string ) $submitted_badge_first_name_value ) {
                    if ( isset( $profile_section[ $badge_first_name_key ] ) ) {
                        unset( $profile_section[ $badge_first_name_key ] );
                    
                        $change = true;
                    }
                } elseif ( isset( $profile_section[ $badge_first_name_key ] ) ) {
                    if ( ( string ) $submitted_badge_first_name_value !== ( string ) $profile_section[ $badge_first_name_key ] ) {
                        $profile_section[ $badge_first_name_key ] = $submitted_badge_first_name_value;

                        $change = true;
                    }
                } else {
                    $profile_section[ $badge_first_name_key ] = $submitted_badge_first_name_value;

                    $change = true;
                }
            }

            if ( isset( $profile_section[ $badge_first_name_key ] ) && $this->empty( $profile_section[ $badge_first_name_key ] ) ) {
                unset( $profile_section[ $badge_first_name_key ] );

                $change = true;
            }            
        }
        
        if ( isset( $submitted_data[ $badge_key ][ $badge_last_name_key ] ) ) {
            if ( ! $this->is_string_or_numeric( $submitted_data[ $badge_key ][ $badge_last_name_key ] ) ) {
                $this->profile_update_errors[ $badge_last_name_key ] = sprintf(
                    /*translators: %s: Last name of the user*/
                    __( '%s is not a valid last name.', 'describr' ),
                    $submitted_data[ $badge_key ][ $badge_last_name_key ]
                );
            } elseif ( $maxlen['textbox'] < mb_strlen( ( string ) $submitted_data[ $badge_key ][ $badge_last_name_key ] ) ) {
                $this->profile_update_errors[ $badge_last_name_key ] = sprintf(
                    /*translators: 1: Number of characters allowed in last name of the user, 2: Last name of the user*/
                    __( 'Last name cannot have more than %1$d characters: %2$s.', 'describr' ),
                    $maxlen['textbox'],
                    $submitted_data[ $badge_key ][ $badge_last_name_key ]
                );
            } else {
                $submitted_badge_last_name_value = $submitted_data[ $badge_key ][ $badge_last_name_key ];
            }           
            
            if ( ! isset( $this->profile_update_errors[ $badge_last_name_key ] ) ) {
                if ( '' === ( string ) $submitted_badge_last_name_value  ) {
                    if ( isset( $profile_section[ $badge_last_name_key ] ) ) { 
                        unset( $profile_section[ $badge_last_name_key ] );
                    
                    $change = true;
                    }
                } elseif ( isset( $profile_section[ $badge_last_name_key ] ) ) {
                    if ( ( string ) $submitted_badge_last_name_value !== ( string ) $profile_section[ $badge_last_name_key ] ) {
                        $profile_section[ $badge_last_name_key  ] = $submitted_badge_last_name_value;

                    $change = true;
                    }
                } else {
                    $profile_section[ $badge_last_name_key ] = $submitted_badge_last_name_value;

                    $change = true;
                }
            }

            if ( isset( $profile_section[ $badge_last_name_key ] ) && $this->empty( $profile_section[ $badge_last_name_key ] ) ) {
                unset( $profile_section[ $badge_last_name_key ] );

                $change = true;
            }
        }
        
        if ( $change ) {
            if ( isset( $previously_saved_userdata[ $badge_key ] ) ) {
                unset( $previously_saved_userdata[ $badge_key ] );
            }
        
            if ( isset( $profile_section[ $badge_first_name_key ] ) || isset( $profile_section[ $badge_last_name_key ] ) ) {
                $updated_userdata[ $badge_key ] = $this->update_user_profile_section_event_log( $profile_section );
            }
        }
    }
    
    if ( isset( $submitted_data[ $gender_key ] ) && is_array( $submitted_data[ $gender_key ] ) ) {
        $gender_type_key = 'type';

        $gender_type_value = '';

        if ( isset( $submitted_data[ $gender_key ][ $gender_type_key ] ) && ! empty( $submitted_data[ $gender_key ][ $gender_type_key ] ) ) {

            if ( in_array( $submitted_data[ $gender_key ][ $gender_type_key ], array( 'm', 'f' ), true ) ) {
                $gender_type_value = $submitted_data[ $gender_key ][ $gender_type_key ];
            } else {
                $this->profile_update_errors[ $gender_key ] = __( 'Your gender selection is invalid.', 'describr' );
            }
            
        }
        
        if ( ! isset( $this->profile_update_errors[ $gender_key ] ) ) {
            $profile_section = isset( $previously_saved_userdata[ $gender_key ] ) ? ( array ) $previously_saved_userdata[ $gender_key ] : $arr;
        
            $change = false;
        
            $this->update_user_profile_section( $gender_type_value, $gender_type_key, $profile_section, $change, $submitted_data[ $gender_key ] );
            $this->commit_changes_made_to_user_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $gender_key, $gender_type_key, $change );
        }
    }

    if ( isset( $submitted_data[ $birthdate_key ] ) && is_array( $submitted_data[ $birthdate_key ] ) ) {
        $date_key = 'date';        

        $birthdate = '';

        if ( isset( $submitted_data[ $birthdate_key ][ $date_key ] ) && ! $this->empty( $submitted_data[ $birthdate_key ][ $date_key ] ) ) {
            if ( $this->is_date( $submitted_data[ $birthdate_key ][ $date_key ] ) ) {
                $birthdate = $submitted_data[ $birthdate_key ][ $date_key ];            
            } else {
                $this->profile_update_errors[ $birthdate_key ] = __( 'Birthdate date format is invalid. Supported date format: YYYY-MM-DD.', 'describr' );
            }
        }
        
        if ( ! isset( $this->profile_update_errors[ $birthdate_key ] ) ) {
            $profile_section = isset( $previously_saved_userdata[ $birthdate_key ] ) ? ( array ) $previously_saved_userdata[ $birthdate_key ] : $arr;

            $change = false;
        
            $this->update_user_profile_section( $birthdate, $date_key, $profile_section, $change, $submitted_data[ $birthdate_key ] );
            $this->commit_changes_made_to_user_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $birthdate_key, $date_key, $change );
        }
    }

    if ( isset( $submitted_data[ $bio_key ] ) && is_array( $submitted_data[ $bio_key ] ) ) {
        $submitted_bio_value = '';
        
        if ( isset( $submitted_data[ $bio_key ][ $description_key ] ) && ! $this->empty( $submitted_data[ $bio_key ][ $description_key ] ) ) {
            if ( ! $this->is_string_or_numeric( $submitted_data[ $bio_key ][ $description_key ] ) ) {
                $this->profile_update_errors['biography'] = sprintf(
                    /*translators: %s: Biography of the user*/
                    __( 'Bio is invalid: %s.', 'describr' ),
                    $submitted_data[ $bio_key ][ $description_key ]
                );
            } elseif ( $maxlen['textarea_SM'] < mb_strlen( ( string ) $submitted_data[ $bio_key ][ $description_key ] ) ) {
                $this->profile_update_errors['biography'] = sprintf(
                    /*translators: 1: Number of characters allowed in biography of the user, 2: Biography of the user*/
                    __( 'Bio cannot have more than %1$d characters: %2$s.', 'describr' ),
                    $maxlen['textarea_SM'],
                    $submitted_data[ $bio_key ][ $description_key ]
                );
            } else {
                $submitted_bio_value = $submitted_data[ $bio_key ][ $description_key ];
            }
        }
                
        if ( ! isset( $this->profile_update_errors['biography'] ) ) {
            $profile_section = isset( $previously_saved_userdata[ $bio_key ] ) ? ( array ) $previously_saved_userdata[ $bio_key ] : $arr;
            
            $change = false;

            $this->update_user_profile_section( $submitted_bio_value, $description_key, $profile_section, $change, $submitted_data[ $bio_key ] );
        
            $this->commit_changes_made_to_user_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $bio_key, $description_key, $change );
        }
    }

    if ( isset( $submitted_data[ $physical_addresses_key ] ) && is_array( $submitted_data[ $physical_addresses_key ] )) {
        $submitted_physical_addresses_arr = $submitted_data[ $physical_addresses_key ];
                
        $change = false;

        $physical_addresses_current_city_arr_key = 'current_city';
        $physical_addresses_hometown_arr_key     = 'hometown';
        
        $submitted_physical_addresses_current_city_value = '';
        $submitted_physical_addresses_hometown_value     = '';
                
        if( isset( $submitted_physical_addresses_arr[ $physical_addresses_current_city_arr_key ] ) && ! empty( $submitted_physical_addresses_arr[ $physical_addresses_current_city_arr_key ] ) ) {
            if ( $this->is_city( $submitted_physical_addresses_arr[ $physical_addresses_current_city_arr_key ] ) ) {
                $submitted_physical_addresses_current_city_value = $submitted_physical_addresses_arr[ $physical_addresses_current_city_arr_key ];

                if ( $maxlen['textbox'] < mb_strlen( ( string ) $submitted_physical_addresses_current_city_value ) ) {
                    $this->profile_update_errors[ $physical_addresses_current_city_arr_key ] = sprintf(
                    /*translators: 1: City where the user currently lives, 2: Number of characters allowed in the city where the user currently lives*/
                        __( '%1$s cannot have more than %2$d characters.', 'describr' ),
                        $submitted_physical_addresses_current_city_value,
                        $maxlen['textbox']
                    );
                }
            } else {
                $this->profile_update_errors[ $physical_addresses_current_city_arr_key ] = sprintf(
                    /*translators: %s: City where the user currently lives*/
                    __( '%s is invalid.', 'describr' ),
                    $submitted_physical_addresses_arr[ $physical_addresses_current_city_arr_key ]
                );
            }
        }
        
        if ( isset( $submitted_physical_addresses_arr[ $physical_addresses_hometown_arr_key ] ) && ! empty( $submitted_physical_addresses_arr[ $physical_addresses_hometown_arr_key ] ) ) {
            if ( $this->is_city( $submitted_physical_addresses_arr[ $physical_addresses_hometown_arr_key ] ) ) {
                $submitted_physical_addresses_hometown_value = $submitted_physical_addresses_arr[ $physical_addresses_hometown_arr_key ];

                if ( $maxlen['textbox'] < mb_strlen( ( string ) $submitted_physical_addresses_hometown_value ) ) {
                    $this->profile_update_errors[ $physical_addresses_hometown_arr_key ] = sprintf(
                        /*translators: 1: Hometown of the user, 2: Number of characters allowed in hometown*/
                        __( '%1$s cannot have more than %2$d characters.', 'describr' ),
                        $submitted_physical_addresses_hometown_value,
                        $maxlen['textbox']
                    );
                }
            } else {
                $this->profile_update_errors[ $physical_addresses_hometown_arr_key ] = sprintf(
                    /*translators: %s: Hometown of the user*/
                    __( '%s is invalid.', 'describr' ),
                    $submitted_physical_addresses_arr[ $physical_addresses_hometown_arr_key ]
                );
            }
        }
        
        $previously_saved_physical_addresses_arr = isset( $previously_saved_userdata[ $physical_addresses_key ] ) ? ( array ) $previously_saved_userdata[ $physical_addresses_key ] : $arr;
        
        //Update current city
        if ( ! isset( $this->profile_update_errors[ $physical_addresses_current_city_arr_key ] ) ) {
            $this->update_user_profile_section( $submitted_physical_addresses_current_city_value, $physical_addresses_current_city_arr_key, $previously_saved_physical_addresses_arr, $change );
        }        
        
        //Update hometown
        if ( ! isset( $this->profile_update_errors[ $physical_addresses_hometown_arr_key ] ) ) {
            $this->update_user_profile_section( $submitted_physical_addresses_hometown_value, $physical_addresses_hometown_arr_key, $previously_saved_physical_addresses_arr, $change );
        }        
        
        //Lived cities begin here
        $physical_addresses_lived_cities_arr_key = 'lived_cities';

        if ( ! isset( $submitted_physical_addresses_arr[ $physical_addresses_lived_cities_arr_key ] ) || ! is_array( $submitted_physical_addresses_arr[ $physical_addresses_lived_cities_arr_key ] ) ) {
            $submitted_physical_addresses_arr[ $physical_addresses_lived_cities_arr_key ] = $arr;
        }
        
        $this->remove_empty_last_key_from_array( $submitted_physical_addresses_arr[ $physical_addresses_lived_cities_arr_key ] );

        $cities_count = count( $submitted_physical_addresses_arr[ $physical_addresses_lived_cities_arr_key ] );
        
        if ( $cities_count ) {
            $duplicate_lived_cities_arr = $arr;

            $submitted_physical_addresses_lived_cities_arr_default_keys = array(
                'city' => '', 
                'moved' => '',
            );

            if ( $maxlen['arraysize'] < $cities_count ) {
                $submitted_physical_addresses_arr[ $physical_addresses_lived_cities_arr_key ] = array_slice( $submitted_physical_addresses_arr[ $physical_addresses_lived_cities_arr_key ], 0, $maxlen['arraysize'] );

                if ( 1 === $maxlen['arraysize'] ) {
                    $this->profile_update_errors[ $physical_addresses_lived_cities_arr_key ] = __( 'You can include only one lived city.', 'describr' );
                } else {
                    $this->profile_update_errors[ $physical_addresses_lived_cities_arr_key ] = sprintf(
                        /*translators: %d: Limit of cities where the user previously lived*/
                        __( 'You can include only %d lived cities.', 'describr' ),
                        $maxlen['arraysize']
                    );
                }
            }
            
            foreach ( $submitted_physical_addresses_arr[ $physical_addresses_lived_cities_arr_key ] as $submitted_lived_cities_arr_key => &$submitted_lived_cities_arr_value ) {
                if ( is_array( $submitted_lived_cities_arr_value ) && ! $this->is_duplicate_array( $duplicate_lived_cities_arr, $submitted_lived_cities_arr_value ) && isset( $submitted_lived_cities_arr_value['city'] ) && ! empty( $submitted_lived_cities_arr_value['city'] ) ) {
                    $duplicate_lived_cities_arr[] = $submitted_lived_cities_arr_value;

                    $unset_city = false;
                
                    foreach ( $submitted_lived_cities_arr_value as $lived_city_key => $lived_city_value ) {
                        if ( isset( $submitted_physical_addresses_lived_cities_arr_default_keys[ $lived_city_key ] ) &&  ! empty( $lived_city_value ) && $this->is_string_or_numeric( $lived_city_value ) ) {
                            if ( 'moved' === ( string ) $lived_city_key ) {
                                if ( ! $this->is_date( $lived_city_value ) ) {
                                    $this->profile_update_errors[ wp_unique_id( $lived_city_key ) ] = sprintf(
                                        /*translators: 1: Date, 2: City where the user previously lived*/
                                        __( 'The date <strong>%1$s</strong> you moved from %2$s is invalid. Supported date format: YYYY-MM-DD.', 'describr' ),
                                        $lived_city_value,
                                        $submitted_lived_cities_arr_value['city']
                                    );
                                    
                                    unset( $submitted_lived_cities_arr_value[ $lived_city_key ] );
                                }
                            } elseif ( ! $this->is_city( $lived_city_value ) ) {
                                $this->profile_update_errors[ $lived_city_key ] = sprintf(
                                    /*translators: %s: City where the user previously lived*/
                                    __( '%s is invalid.', 'describr' ),
                                    $lived_city_value
                                );

                                $unset_city = true;
                            } elseif ( $maxlen['textbox'] < mb_strlen( ( string ) $lived_city_value ) ) {
                                $this->profile_update_errors[ $lived_city_key ] = sprintf(
                                    /*translators: 1: City where the user previously lived, 2: Number of characters allowed in the city where the user previously lived*/
                                    __( '%1$s cannot have more than %2$d characters.', 'describr' ),
                                    $lived_city_value,
                                    $maxlen['textbox']
                                );

                                $unset_city = true;
                            }
                        } else {
                            $unset_city = true;
                        }
                    }

                    if ( $unset_city ) {
                        unset( $submitted_physical_addresses_arr[ $physical_addresses_lived_cities_arr_key ][ $submitted_lived_cities_arr_key ] );
                    }
                } else {
                    unset( $submitted_physical_addresses_arr[ $physical_addresses_lived_cities_arr_key ][ $submitted_lived_cities_arr_key ] );
                }                     
            }

            if ( $cities_count !== count( $submitted_physical_addresses_arr[ $physical_addresses_lived_cities_arr_key ] ) ) {
                $submitted_physical_addresses_arr[ $physical_addresses_lived_cities_arr_key ] = array_values( $submitted_physical_addresses_arr[ $physical_addresses_lived_cities_arr_key ] );
            }
        }
        
        //Update lived cities
        $this->update_user_profile_section( $submitted_physical_addresses_arr[ $physical_addresses_lived_cities_arr_key ], $physical_addresses_lived_cities_arr_key, $previously_saved_physical_addresses_arr, $change );                
        
        $this->add_user_profile_section_controls( $previously_saved_physical_addresses_arr, $submitted_physical_addresses_arr, $change );                    
        
        if ( $change ) {
            if ( isset( $previously_saved_userdata[ $physical_addresses_key ] ) ) {
                unset( $previously_saved_userdata[ $physical_addresses_key ] );
            }
            
            if ( $previously_saved_physical_addresses_arr ) {
                $updated_userdata[ $physical_addresses_key ] = $this->update_user_profile_section_event_log( $previously_saved_physical_addresses_arr );
            }    
        }
    }

    if ( isset( $submitted_data[ $relationship_key ] ) && is_array( $submitted_data[ $relationship_key ] ) ) {
        $relationship_status_arr_key        = 'status';
        $relationship_partner_arr_key       = 'partner';
        $relationship_partner_arr_id_key    = 'id';
        $relationship_partner_arr_name_key  = 'name';
        $relationship_partner_arr_since_key = 'since';

        $submitted_relationship_partner_name  = '';
        $submitted_relationship_partner_id    = '';
        $submitted_relationship_partner_since = '';
        
        $relationship_status = '';

        $change = false;

        $profile_section = isset( $previously_saved_userdata[ $relationship_key ] ) ? ( array ) $previously_saved_userdata[ $relationship_key ] : $arr;
        
        if ( isset( $submitted_data[ $relationship_key ][ $relationship_status_arr_key ] ) && ! empty( $submitted_data[ $relationship_key ][ $relationship_status_arr_key ] ) ) {
            if ( in_array( $submitted_data[ $relationship_key ][ $relationship_status_arr_key ], array( 's', 'm', 'iar', 'eng', 'sep', 'div', 'wid' ,'dr' , 'cu', 'fwb' ), true ) ) {
                $relationship_status = $submitted_data[ $relationship_key ][ $relationship_status_arr_key ];
            } else {
                $this->profile_update_errors[ $relationship_status_arr_key ] = __( 'Your relationship status is invalid.', 'describr' );
            }
        }
        
        if ( ! isset( $this->profile_update_errors[ $relationship_status_arr_key ] ) ) {
            if ( isset( $profile_section[ $relationship_status_arr_key ] ) ) {
                if ( $relationship_status ) {
                    if ( ( string ) $relationship_status !== ( string ) $profile_section[ $relationship_status_arr_key ] ) {
                        $profile_section[ $relationship_status_arr_key ] = $relationship_status;
                        $change = true;
                    }
                } else {
                    unset( $profile_section[ $relationship_status_arr_key ] );
                    $change = true;
                }
            } elseif ( $relationship_status ) {
                $profile_section[ $relationship_status_arr_key ] = $relationship_status;
                $change = true;
            }
        }
        
        if ( isset( $submitted_data[ $relationship_key ][ $relationship_partner_arr_key ] ) && is_array( $submitted_data[ $relationship_key ][ $relationship_partner_arr_key ] ) ) {
            $partner_arr = $submitted_data[ $relationship_key ][ $relationship_partner_arr_key ];
            
            if ( ! empty( $partner_arr[ $relationship_partner_arr_id_key ] ) && is_numeric( $partner_arr[ $relationship_partner_arr_id_key ] ) ) {
                $submitted_relationship_partner_id = ( int ) $partner_arr[ $relationship_partner_arr_id_key ];
            }

            if (  empty( $partner_arr[ $relationship_partner_arr_name_key ] ) ) {
                if ( is_int( $submitted_relationship_partner_id ) ) {
                    $user_partner = get_user_by( 'id', $submitted_relationship_partner_id );

                    if ( $user_partner ) {
                        $submitted_relationship_partner_name = $this->username_to_use( $user_partner );
                    }
                }
            } elseif ( ! $this->is_string_or_numeric( $partner_arr[ $relationship_partner_arr_name_key ] ) ) {
                 $this->profile_update_errors["{$relationship_partner_arr_name_key}__partner"] = sprintf(
                    /*translators: %s: Full name of the spouse of the user*/
                    __( '%s is invalid.', 'describr' ),
                    $partner_arr[ $relationship_partner_arr_name_key ]
                );
            } elseif ( $maxlen['textbox'] < mb_strlen( ( string ) $partner_arr[ $relationship_partner_arr_name_key ] ) ) {
                $this->profile_update_errors["{$relationship_partner_arr_name_key}__partner"] = sprintf(
                    /*translators: 1: Full name of the spouse of the user, 2: Number of characters allowed in the full name of the spouse of the user*/
                    __( '%1$s cannot have more than %2$d characters.', 'describr' ),
                    $partner_arr[ $relationship_partner_arr_name_key ],
                    $maxlen['textbox']
                );
            } else {
                $submitted_relationship_partner_name = $partner_arr[ $relationship_partner_arr_name_key ];
            }

            if ( ! empty( $partner_arr[ $relationship_partner_arr_since_key ] ) ) {
                if ( $this->is_date( $partner_arr[ $relationship_partner_arr_since_key ] ) ) {
                    $submitted_relationship_partner_since = $partner_arr[ $relationship_partner_arr_since_key ];
                } else {
                    $this->profile_update_errors[ $relationship_partner_arr_since_key ] = __( 'The date you started your relationship is invalid. Supported date format: YYYY-MM-DD.', 'describr' );
                }
            }
        }
        
        if ( ! isset( $this->profile_update_errors["{$relationship_partner_arr_name_key}__partner"] ) ) {
            if ( isset( $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_name_key ] ) ) {
                if ( $submitted_relationship_partner_name ) {
                    if ( ( string ) $submitted_relationship_partner_name !== ( string ) $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_name_key ] ) {
                       $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_name_key ] = $submitted_relationship_partner_name;
                       $change = true;
                    }
                } else {
                    unset( $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_name_key ] );
                    $change = true;
                }
            } elseif ( $submitted_relationship_partner_name ) {
                $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_name_key ] = $submitted_relationship_partner_name;
                $change = true;
            }
        }
        
        if ( ! isset( $this->profile_update_errors[ $relationship_partner_arr_since_key ] ) ) {
            if ( isset( $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_since_key ] ) ) {
                if ( $submitted_relationship_partner_since ) {
                    if ( ( string ) $submitted_relationship_partner_since !== ( string ) $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_since_key ] ) {
                       $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_since_key ] = $submitted_relationship_partner_since;
                       $change = true;
                    }
                } else {
                    unset( $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_since_key ] );
                    $change = true;
                }
            } elseif ( $submitted_relationship_partner_since ) {
                $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_since_key ] = $submitted_relationship_partner_since;
                $change = true;
            }
        }       
        
        //Set partner's ID only if the accompanying name is set.        
        if ( isset( $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_name_key ] ) ) {
            if ( isset( $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_id_key ] ) ) {
                if ( is_int( $submitted_relationship_partner_id ) ) {
                    if ( ( string ) $submitted_relationship_partner_id !== ( string ) $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_id_key ] ) {
                        $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_id_key ] = $submitted_relationship_partner_id;
                        $change = true;
                    }
                } else {
                    unset( $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_id_key ] );
                    $change = true;
                }
            } elseif ( $submitted_relationship_partner_id ) {
                $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_id_key ] = $submitted_relationship_partner_id;
                $change = true;
            } 
        } elseif ( isset( $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_id_key ] ) ) {
            unset( $profile_section[ $relationship_partner_arr_key ][ $relationship_partner_arr_id_key ] );
            $change = true;
        }
        
        if ( ! empty( $profile_section[ $relationship_partner_arr_key ] ) || ! empty( $profile_section[ $relationship_status_arr_key ] ) ) {
            $this->add_user_profile_section_controls( $profile_section, $submitted_data[ $relationship_key ], $change );
        }

        if ( $change ) {
            if ( isset( $previously_saved_userdata[ $relationship_key ] ) ) {
                unset( $previously_saved_userdata[ $relationship_key ] );
            }
        
            if ( isset( $profile_section[ $relationship_partner_arr_key ] ) || ! empty( $profile_section[ $relationship_status_arr_key ] ) ) {
                $updated_userdata[ $relationship_key ] = $this->update_user_profile_section_event_log( $profile_section );
            }
        }       
    }

    if ( isset( $submitted_data[ $lang_key ] ) && is_array( $submitted_data[ $lang_key ] ) ) {
        $submitted_langs_value = '';

        if ( ! empty( $submitted_data[ $lang_key ][ $lang_key ] ) ) {
            if ( is_string( $submitted_data[ $lang_key ][ $lang_key ] ) ) {
                $stripped_submit_langs_value = trim( $submitted_data[ $lang_key ][ $lang_key ], ',' );
                
                if ( false === strpos( $stripped_submit_langs_value, ',' ) ) {
                    if ( $maxlen['textbox'] < mb_strlen( $stripped_submit_langs_value ) ) {
                        $this->profile_update_errors["{$lang_key}_invalid"] = sprintf(
                            /*translators: %d: Number of characters allowed in language*/
                            __( 'Language cannot have more than %d characters.', 'describr' ),
                            $maxlen['textbox']
                        );
                    } else {
                        $submitted_langs_value = $stripped_submit_langs_value;
                    }
                } else {
                    $submitted_langs_arr = map_deep( explode( ',', $stripped_submit_langs_value ), 'trim' );
                    
                    $duplicate_langs_arr = $arr;
                    
                    if ( $maxlen['arraysize'] < count( $submitted_langs_arr ) ) {
                        $submitted_langs_arr = array_slice( $submitted_langs_arr, 0, $maxlen['arraysize'] );

                        if ( 1 === $maxlen['arraysize'] ) {
                            $this->profile_update_errors["{$lang_key}_count"] = __( 'You can include only one language.', 'describr' );
                        } else {
                            $this->profile_update_errors["{$lang_key}_count"] = sprintf(
                                /*translators: %d: Number of allowed languages*/
                                __( 'You can include only %d languages.', 'describr' ),
                                $maxlen['arraysize']
                            );
                        }
                    }
                    
                    foreach ( $submitted_langs_arr as $submitted_langs_arr_key => &$submitted_langs_arr_value ) {
                        $submitted_langs_arr_value = ( string ) $submitted_langs_arr_value;

                        if ( empty( $submitted_langs_arr_value ) || in_array( mb_strtolower( $submitted_langs_arr_value ), $duplicate_langs_arr, true ) ) {
                            unset( $submitted_langs_arr[ $submitted_langs_arr_key ] );
                        } else {
                            if ( $maxlen['textbox'] < mb_strlen( $submitted_langs_arr_value ) ) {
                                if ( ! isset( $this->profile_update_errors[ $lang_key ] ) ) {
                                    $this->profile_update_errors[ $lang_key ] = sprintf(
                                        /*translators: %d: Number of characters allowed in language*/
                                        __( 'Language cannot have more than %d characters.', 'describr' ),
                                        $maxlen['textbox']
                                    );
                                }

                                unset( $submitted_langs_arr[ $submitted_langs_arr_key ] );
                            }

                            $duplicate_langs_arr[] = mb_strtolower( $submitted_langs_arr_value );
                        }
                    }
                    
                    if ( count( $submitted_langs_arr ) ) {
                        $submitted_langs_value = implode( ',', $submitted_langs_arr );
                    }
                }
            } else {
                $this->profile_update_errors["{$lang_key}_invalid"] = __( 'One or more of your language selection is invalid.', 'describr' );
            }
        }       
        
        if ( ! isset( $this->profile_update_errors["{$lang_key}_invalid"] ) ) {
            $profile_section = isset( $previously_saved_userdata[ $lang_key ] ) ? ( array ) $previously_saved_userdata[ $lang_key ] : $arr;

            $change = false;

            $this->update_user_profile_section( $submitted_langs_value, $lang_key, $profile_section, $change, $submitted_data[ $lang_key ] );
            $this->commit_changes_made_to_user_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $lang_key, $lang_key, $change );
        }
    }
    
    if ( isset( $submitted_data[ $contact_key ] ) && is_array( $submitted_data[ $contact_key ] ) ) {
        $contact_phone_arr_key        = 'phones';
        $contact_phonenumbers_arr_key = 'numbers';        

        $change = false;

        $profile_section = isset( $previously_saved_userdata[ $contact_key ] ) ? ( array ) $previously_saved_userdata[ $contact_key ] : $arr;

        if ( ! isset( $submitted_data[ $contact_key ][ $contact_phone_arr_key ][ $contact_phonenumbers_arr_key ] ) || ! is_array( $submitted_data[ $contact_key ][ $contact_phone_arr_key ][ $contact_phonenumbers_arr_key ] ) ) {
            $submitted_data[ $contact_key ][ $contact_phone_arr_key ][ $contact_phonenumbers_arr_key ] = $arr;
        }

        $this->remove_empty_last_key_from_array( $submitted_data[ $contact_key ][ $contact_phone_arr_key ][ $contact_phonenumbers_arr_key ] );

        $submitted_phonenumbers_count = count( $submitted_data[ $contact_key ][ $contact_phone_arr_key ][ $contact_phonenumbers_arr_key ] );

        if ( $submitted_phonenumbers_count ) {
            $duplicate_phonenumbers_arr = $arr;

            $valid_phonenumber_char = apply_filters( 'describr_valid_phonenumber_characters', '/[^0-9a-zA-Z\.\(\)\s_-]+/i' );

            if ( $maxlen['arraysize'] < $submitted_phonenumbers_count ) {
                $submitted_data[ $contact_key ][ $contact_phone_arr_key ][ $contact_phonenumbers_arr_key ] = array_slice( $submitted_data[ $contact_key ][ $contact_phone_arr_key ][ $contact_phonenumbers_arr_key ], 0, $maxlen['arraysize'] );

                if ( 1 === $maxlen['arraysize'] ) {
                    $this->profile_update_errors["{$contact_key}_phonenumbers_count"] = __( 'You can include only one phone number.', 'describr' );
                } else {
                    $this->profile_update_errors["{$contact_key}_phonenumbers_count"] = sprintf(
                        /*translators: %d: Number of phone numbers allowed*/
                        __( 'You can include only %d phone numbers.', 'describr' ),
                        $maxlen['arraysize']
                    );
                }
            }
            
            foreach ( $submitted_data[ $contact_key ][ $contact_phone_arr_key ][ $contact_phonenumbers_arr_key ] as $phone_key => $phone_value ) {
                if ( empty( $phone_value ) || in_array( mb_strtolower( ( string ) $phone_value ), $duplicate_phonenumbers_arr, true ) ) {
                    unset( $submitted_data[ $contact_key ][ $contact_phone_arr_key ][ $contact_phonenumbers_arr_key ][ $phone_key ] );
                } elseif ( ! $this->is_string_or_numeric( $phone_value ) || preg_match( $valid_phonenumber_char, $phone_value ) ) {
                    $this->profile_update_errors[ wp_unique_id( $phone_key ) ] = sprintf(
                        /*translators: %s: Phone number*/
                        __( '%s is not a valid phone number.', 'describr' ),
                        $phone_value
                    );

                    unset( $submitted_data[ $contact_key ][ $contact_phone_arr_key ][ $contact_phonenumbers_arr_key ][ $phone_key ] );
                } elseif ( $maxlen['phone'] < mb_strlen( ( string ) $phone_value ) ) {
                    $this->profile_update_errors[ wp_unique_id( $phone_key ) ] = sprintf(
                        /*translators: 1: Phone number, 2: Number of characters allowed in phone number*/
                        __( '%1$s cannot have more than %2$d characters.', 'describr' ),
                        $phone_value,
                        $maxlen['phone']
                    );
                    
                    unset( $submitted_data[ $contact_key ][ $contact_phone_arr_key ][ $contact_phonenumbers_arr_key ][ $phone_key ] );
                }
                
                $duplicate_phonenumbers_arr[] = mb_strtolower( ( string ) $phone_value );
            }
            
            if ( $submitted_phonenumbers_count !== count( $submitted_data[ $contact_key ][ $contact_phone_arr_key ][ $contact_phonenumbers_arr_key ] ) ) {
                $submitted_data[ $contact_key ][ $contact_phone_arr_key ][ $contact_phonenumbers_arr_key ] = array_values( $submitted_data[ $contact_key ][ $contact_phone_arr_key ][ $contact_phonenumbers_arr_key ] );
            }
        }

        if ( isset( $submitted_data[ $contact_key ][ $contact_phone_arr_key ] ) && is_array( $submitted_data[ $contact_key ][ $contact_phone_arr_key ] ) ) {
            $profile_section[ $contact_phone_arr_key ] = isset( $profile_section[ $contact_phone_arr_key ] ) ? ( array ) $profile_section[ $contact_phone_arr_key ] : $arr;

            $this->update_user_profile_section( $submitted_data[ $contact_key ][ $contact_phone_arr_key ][ $contact_phonenumbers_arr_key ], $contact_phonenumbers_arr_key, $profile_section[ $contact_phone_arr_key ], $change, $submitted_data[ $contact_key ][ $contact_phone_arr_key ] );
        
            $this->commit_changes_made_to_user_profile_section( $profile_section, $profile_section, $profile_section[ $contact_phone_arr_key ], $contact_phone_arr_key, $contact_phonenumbers_arr_key, $change );
        }
        
        $contact_email_arr_key         = 'email';
        $contact_email_address_arr_key = 'address';

        $submitted_contact_email_address_value = '';

        if ( isset( $submitted_data[ $contact_key ][ $contact_email_arr_key ][ $contact_email_address_arr_key ] ) && ! $this->empty( $submitted_data[ $contact_key ][ $contact_email_arr_key ][ $contact_email_address_arr_key ] ) ) {
            if ( is_string( $submitted_data[ $contact_key ][ $contact_email_arr_key ][ $contact_email_address_arr_key ] ) && is_email( $submitted_data[ $contact_key ][ $contact_email_arr_key ][ $contact_email_address_arr_key ] ) ) {
                if ( $maxlen['textbox'] < mb_strlen( $submitted_data[ $contact_key ][ $contact_email_arr_key ][ $contact_email_address_arr_key ] ) ) {
                    $this->profile_update_errors[ $contact_email_arr_key ]  = sprintf(
                        /*translators: 1: Email address, 2: Number of characters allowed in email address*/
                        __( '%1$s cannot have more than %2$d characters.', 'describr' ),
                        $submitted_data[ $contact_key ][ $contact_email_arr_key ][ $contact_email_address_arr_key ],
                        $maxlen['textbox']
                    );
                } else {
                    $submitted_contact_email_address_value = $submitted_data[ $contact_key ][ $contact_email_arr_key ][ $contact_email_address_arr_key ];
                }
            } else {
                $this->profile_update_errors[ $contact_email_arr_key ] = sprintf(
                    /*translators: %s: Email address*/
                    __( '%s is not a valid email address.', 'describr' ),
                    $submitted_data[ $contact_key ][ $contact_email_arr_key ][ $contact_email_address_arr_key ]
                );
            }
        }
        
        if ( isset( $submitted_data[ $contact_key ][ $contact_email_arr_key ] ) && is_array( $submitted_data[ $contact_key ][ $contact_email_arr_key ] ) && ! isset( $this->profile_update_errors[ $contact_email_arr_key ] ) ) {
            $profile_section[ $contact_email_arr_key ] = isset( $profile_section[ $contact_email_arr_key ] ) ? ( array )$profile_section[ $contact_email_arr_key ] : $arr;

            $this->update_user_profile_section( $submitted_contact_email_address_value, $contact_email_address_arr_key, $profile_section[ $contact_email_arr_key ], $change, $submitted_data[ $contact_key ][ $contact_email_arr_key ] );
            
            $this->commit_changes_made_to_user_profile_section( $profile_section, $profile_section, $profile_section[ $contact_email_arr_key ], $contact_email_arr_key, $contact_email_address_arr_key, $change );
        }
                
        if ( $change ) {
            if ( isset( $previously_saved_userdata[ $contact_key ] ) ) {
                unset( $previously_saved_userdata[ $contact_key ] );
            }

            if ( isset( $profile_section[ $contact_phone_arr_key ] ) || isset( $profile_section[ $contact_email_arr_key ] ) ) {
                $updated_userdata[ $contact_key ] = $profile_section;
            }
        } 
    }

    if (  isset( $submitted_data[ $timezone_key ] ) && is_array( $submitted_data[ $timezone_key ] ) ) {
        $submitted_timezone_value = '';
        
        if ( isset( $submitted_data[ $timezone_key ][ $name ] ) && ! $this->empty( $submitted_data[ $timezone_key ][ $name ] ) ) {
            if ( $this->is_timezone( $submitted_data[ $timezone_key ][ $name ] ) || $this->is_utc( $submitted_data[ $timezone_key ][ $name ] ) ) {
                $submitted_timezone_value = $submitted_data[ $timezone_key ][ $name ];
            } else {
                $this->profile_update_errors[ $timezone_key ] = sprintf(
                    /*translators: %s: Time zone or UTC of the user*/
                    __( '%s is not a valid time zone or UTC.', 'describr' ),
                    $submitted_data[ $timezone_key ][ $name ]
                );
            }
        }
                
        if ( ! isset( $this->profile_update_errors[ $timezone_key ] ) ) {
            $profile_section = isset( $previously_saved_userdata[ $timezone_key ] ) ? ( array ) $previously_saved_userdata[ $timezone_key ] : $arr;
            
            $change = false;

            $this->update_user_profile_section( $submitted_timezone_value, $name, $profile_section, $change, $submitted_data[ $timezone_key ] );
            
            $this->commit_changes_made_to_user_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $timezone_key, $name, $change );
        }       
    }

    if ( isset( $submitted_data[ $social_networks_key ] ) && is_array( $submitted_data[ $social_networks_key ] ) ) {
        $social_networks_arr_key = 'networks';     

        if ( isset( $submitted_data[ $social_networks_key ][ $social_networks_arr_key ] ) && is_array( $submitted_data[ $social_networks_key ][ $social_networks_arr_key ] ) ) {
            $this->remove_empty_last_key_from_array( $submitted_data[ $social_networks_key ][ $social_networks_arr_key ] );
            
            $social_networks_count = count( $submitted_data[ $social_networks_key ][ $social_networks_arr_key ] );
            
            if ( $social_networks_count ) {
                $duplicate_social_networks = $arr;

                if ( $maxlen['arraysize'] < $social_networks_count ) {
                    $submitted_data[ $social_networks_key ][ $social_networks_arr_key ] = array_slice( $submitted_data[ $social_networks_key ][ $social_networks_arr_key ], 0, $maxlen['arraysize'] );

                    if ( 1 === $maxlen['arraysize'] ) {
                        $this->profile_update_errors[ $social_network_key ] = __( 'You can include only one social network.', 'describr' );
                    } else {
                        $this->profile_update_errors[ $social_network_key ] = sprintf(
                            /*translators: %d: Number of social networks allowed*/
                            __( 'You can include only %d social networks.', 'describr' ),
                            $maxlen['arraysize']
                        );
                    }
                }
                
                foreach ( $submitted_data[ $social_networks_key ][ $social_networks_arr_key ] as $social_network_key => $social_network ) {
                    if ( empty( $social_network )  || in_array( mb_strtolower( ( string ) $social_network ), $duplicate_social_networks, true )  ) {
                        unset( $submitted_data[ $social_networks_key ][ $social_networks_arr_key ][ $social_network_key ] );
                    } elseif ( ! $this->is_string_or_numeric( $social_network ) || 1 !== preg_match( '#^[a-z]{2,3}/[a-zA-Z0-9_\.]+$#', $social_network ) ) {
                        $this->profile_update_errors[ wp_unique_id( $social_network_key ) ] = sprintf(
                            /*translators: %s: Social network*/
                            __( '%s is not a valid social network.', 'describr' ),
                            $social_network
                        );
                    
                        unset( $submitted_data[ $social_networks_key ][ $social_networks_arr_key ][ $social_network_key ] );
                    } elseif ( $maxlen['url'] < mb_strlen( ( string ) $phone_value ) ) {
                        $this->profile_update_errors[ wp_unique_id( $social_network_key ) ] = sprintf(
                            /*translators: 1: Social network, 2: Number of characters allowed in social network*/
                            __( '%1$s cannot have more than %2$d characters.', 'describr' ),
                            $social_network,
                            $maxlen['url']
                        );
                    
                        unset( $submitted_data[ $social_networks_key ][ $social_networks_arr_key ][ $social_network_key ] );
                    }

                    $duplicate_social_networks[] = mb_strtolower( ( string ) $social_network );      
                }
                
                if ( $social_networks_count !== count( $submitted_data[ $social_networks_key ][ $social_networks_arr_key ] ) ) {
                    $submitted_data[ $social_networks_key ][ $social_networks_arr_key ] = array_values( $submitted_data[ $social_networks_key ][ $social_networks_arr_key ] );
                }
            }
        }
        
        if ( isset( $submitted_data[ $social_networks_key ][ $social_networks_arr_key ] ) && is_array( $submitted_data[ $social_networks_key ][ $social_networks_arr_key ] ) ) {

            $profile_section = isset( $previously_saved_userdata[ $social_networks_key ] ) ? $previously_saved_userdata[ $social_networks_key ] : $arr;
            
            $change = false;
            
            $this->update_user_profile_section( $submitted_data[ $social_networks_key ][ $social_networks_arr_key ], $social_networks_arr_key, $profile_section, $change, $submitted_data[ $social_networks_key ] );
            
            $this->commit_changes_made_to_user_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $social_networks_key, $social_networks_arr_key, $change );
        }
    }

    if ( isset( $submitted_data[ $websites_key ] ) && is_array( $submitted_data[ $websites_key ] ) ) {
        $websites_addresses_arr_key = 'addresses';
        
        if ( isset( $submitted_data[ $websites_key ][ $websites_addresses_arr_key ] ) && is_array( $submitted_data[ $websites_key ][ $websites_addresses_arr_key ] ) ) {
            $this->remove_empty_last_key_from_array( $submitted_data[ $websites_key ][ $websites_addresses_arr_key ] );

            $websites_addresses_count = count( $submitted_data[ $websites_key ][ $websites_addresses_arr_key ] );
            
            if ( $websites_addresses_count ) {
                $duplicate_websites_addresses_arr = $arr;

                if ( $maxlen['arraysize'] < $websites_addresses_count ) {
                    $submitted_data[ $websites_key ][ $websites_addresses_arr_key ] = array_slice( $submitted_data[ $websites_key ][ $websites_addresses_arr_key ], 0, $maxlen['arraysize'] );
                
                    if ( 1 === $maxlen['arraysize'] ) {
                        $this->profile_update_errors[ $websites_key ] = __( 'You can include only one Web address.', 'describr' );
                    } else {
                        $this->profile_update_errors[ $websites_key ] = sprintf(
                            /*translators: %d: Number of Web addresses allowed*/
                            __( 'You can include only %d Web addresses.', 'describr' ),
                            $maxlen['arraysize']
                        );
                    } 
                }
                
                foreach ( $submitted_data[ $websites_key ][ $websites_addresses_arr_key ] as $website_address_key => $website_address_url ) {
                    if ( empty( $website_address_url ) || in_array( mb_strtolower( ( string ) $website_address_url ), $duplicate_websites_addresses_arr, true ) ) {
                        unset( $submitted_data[ $websites_key ][ $websites_addresses_arr_key ][ $website_address_key ] );
                    } elseif ( $maxlen['url'] < mb_strlen( ( string ) $website_address_url ) ) {
                        $this->profile_update_errors[ wp_unique_id( $website_address_key ) ] = sprintf(
                            /*translators: 1: Web address, 2: Number of characters allowed in Web address*/
                            __( '%1$s cannot have more than %2$d characters.', 'describr' ),
                            $website_address_url,
                            $maxlen['url']
                        );

                        unset( $submitted_data[ $websites_key ][ $websites_addresses_arr_key ][ $website_address_key ] );  
                    } else {
                        $parsed_url = $this->validate_url( $website_address_url );
                
                        if ( $parsed_url ) {
                            $submitted_data[ $websites_key ][ $websites_addresses_arr_key ][ $website_address_key ] = $parsed_url;
                        } else {
                            $this->profile_update_errors[ wp_unique_id( $website_address_key ) ] = sprintf(
                                /*translators: %s: Web address*/
                                __( '%s is not a valid Web address.', 'describr' ),
                                $website_address_url
                            );

                            unset( $submitted_data[ $websites_key ][ $websites_addresses_arr_key ][ $website_address_key ] );
                        }
                    }

                    $duplicate_websites_addresses_arr[] = mb_strtolower( ( string ) $website_address_url );
                }

                if ( $websites_addresses_count !== count( $submitted_data[ $websites_key ][ $websites_addresses_arr_key ] ) ) {
                    $submitted_data[ $websites_key ][ $websites_addresses_arr_key ] = array_values( $submitted_data[ $websites_key ][ $websites_addresses_arr_key ] );
                }
            }
        }
        
        if ( isset( $submitted_data[ $websites_key ][ $websites_addresses_arr_key ] ) && is_array( $submitted_data[ $websites_key ][ $websites_addresses_arr_key ] ) ) {
            $profile_section = isset( $previously_saved_userdata[ $websites_key ] ) ? ( array ) $previously_saved_userdata[ $websites_key ] : $arr;
            
            $change = false;

            $this->update_user_profile_section( $submitted_data[ $websites_key ][ $websites_addresses_arr_key ], $websites_addresses_arr_key, $profile_section, $change, $submitted_data[ $websites_key ] );
        
            $this->commit_changes_made_to_user_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $websites_key, $websites_addresses_arr_key, $change );
        }
    }

    if ( isset( $submitted_data[ $work_history_key ] ) && is_array( $submitted_data[ $work_history_key ] ) ) {
        $submitted_work_history_value_arr = $submitted_data[ $work_history_key ];
        
        if ( isset( $submitted_work_history_value_arr[ $privacy_key ] ) ) {
            unset( $submitted_work_history_value_arr[ $privacy_key ] );
        }

        if ( isset( $submitted_work_history_value_arr[ $approval_key ] ) ) {
            unset( $submitted_work_history_value_arr[ $approval_key ] );
        }
        
        $this->remove_empty_last_key_from_array( $submitted_work_history_value_arr );
        
        $submitted_work_history_count = count( $submitted_work_history_value_arr );
        
        if ( $submitted_work_history_count ) {
            $work_history_arr_company_name_key = 'company';
        
            $work_history_jobs_key = 'jobs';
        
            $submitted_work_history_value_arr_default_keys = array(
                'title' => $maxlen['textbox'],
                'city'     => $maxlen['textbox'],
                'present'  => '',
            );
        
            $submitted_work_history_value_arr_default_keys[ $work_history_arr_company_name_key ] = $maxlen['textbox'];
            $submitted_work_history_value_arr_default_keys[ $description_key ]                   = $maxlen['textarea_LG'];

            $submitted_work_history_value_arr_default_keys = $submitted_work_history_value_arr_default_keys + $time_span_arr;

            $duplicate_work_history_arr = $arr;

            if ( $maxlen['arraysize'] < $submitted_work_history_count ) {
                $submitted_work_history_value_arr = array_slice( $submitted_work_history_value_arr, 0, $maxlen['arraysize'] );
                
                if ( 1 === $maxlen['arraysize'] ) {
                    $this->profile_update_errors[ $work_history_key ] = __( 'You can include only one job.', 'describr' );
                } else {
                    $this->profile_update_errors[ $work_history_key ] = sprintf(
                        /*translators: %d: Number of jobs allowed*/
                        __( 'You can include only %d jobs.', 'describr' ),
                        $maxlen['arraysize']
                    );
                }
            }
            
            foreach ( $submitted_work_history_value_arr as $work_key => &$work_value ) {
                if ( is_array( $work_value ) && ! $this->is_duplicate_array( $duplicate_work_history_arr, $work_value ) && isset( $work_value[ $work_history_arr_company_name_key ] ) && ! empty( $work_value[ $work_history_arr_company_name_key ] ) ) {
                    $duplicate_work_history_arr[] = $work_value;

                    foreach( $work_value as $job_key => $job_value ) {
                        if ( isset( $submitted_work_history_value_arr_default_keys[ $job_key ] ) && $this->is_string_or_numeric( $job_value ) ) {
                            if ( $this->empty( $job_value ) ) {
                                unset( $work_value[ $job_key ] );
                            } else {
                                if ( 'from' === ( string ) $job_key ) {
                                    if ( ! $this->is_date( $job_value ) ) {
                                        $this->profile_update_errors[ wp_unique_id( $high_school_key ) ] = sprintf(
                                            /*translators: 1: Date, 2: Company name*/
                                            __( 'Started date <strong>%1$s</strong> at %2$s is invalid. Supported date format: YYYY-MM-DD.', 'describr' ),
                                            $job_value,
                                            $work_value[ $work_history_arr_company_name_key ]
                                        );

                                        unset( $work_value[ $job_key ] );
                                    }
                                } elseif ( 'to' === ( string ) $job_key ) {
                                    $unset_to = false;

                                    if ( ! isset( $work_value['from'] ) || empty( $work_value['from'] ) || ! $this->is_date( $work_value['from'] ) ) {
                                        $unset_to = true;
                                        
                                        $this->profile_update_errors[ wp_unique_id( $job_key ) ] = sprintf(
                                            /*translators: %s: Company name*/
                                            __( 'You have to set the date you started working at %s before you can set the date you stopped working.', 'describr' ),
                                            $work_value[ $work_history_arr_company_name_key ]
                                        );
                                    }

                                    if ( ! $unset_to &&  ! $this->is_date( $job_value ) ) {
                                        $this->profile_update_errors[ wp_unique_id( $job_key ) ] = sprintf(
                                            /*translators: 1: Date, 2: Company name*/
                                            __( 'The date <strong>%1$s</strong> you stop working at %2$s is invalid. Supported date format: YYYY-MM-DD.', 'describr' ),
                                            $job_value,
                                            $work_value[ $work_history_arr_company_name_key ]
                                        );
                                    }

                                    if ( $unset_to ) {
                                        unset( $work_value[ $job_key ] );
                                    }
                                } elseif ( 'present' === ( string ) $job_key ) {
                                    if ( 1 !== ( int ) $job_value ) {
                                        unset( $work_value[ $job_key ] );
                                    }
                                } elseif ( ! empty( $submitted_work_history_value_arr_default_keys[ $job_key ] ) ) {
                                    if ( $submitted_work_history_value_arr_default_keys[ $job_key ] < mb_strlen( ( string ) $job_value ) ) {
                                        if ( $work_history_arr_company_name_key === ( string ) $job_key ) {
                                            $error_message = sprintf(
                                                /*translators: 1: Number of characters allowed in company name, 2: Company name*/
                                                __( 'Company name cannot have more than %1$d characters: %2$s.', 'describr' ),
                                                $submitted_work_history_value_arr_default_keys[ $job_key ],
                                                $job_value
                                            );
                                        } elseif ( 'title' === ( string ) $job_key ) {
                                            $error_message = sprintf(
                                                /*translators: 1: Number of characters allowed in job title, 2: Job title*/
                                                __( 'Job title cannot have more than %1$d characters: %2$s.', 'describr' ),
                                                $submitted_work_history_value_arr_default_keys[ $job_key ],
                                                $job_value
                                            );
                                        } elseif ( 'city' === ( string ) $job_key ) {
                                            $error_message = sprintf(
                                                /*translators: 1: City where the user's job is located, 2: Number of characters allowed in the city where the user's job is located*/
                                                __( '%1$s cannot have more than %2$d characters.', 'describr' ),
                                                $job_value,
                                                $submitted_work_history_value_arr_default_keys[ $job_key ]
                                            );
                                        } else {
                                            $error_message = sprintf(
                                               /*translators: 1: Number of characters allowed in job description, 2: Job description*/
                                                __( 'Job description cannot have more than %1$d characters: %2$s.', 'describr' ),
                                                $submitted_work_history_value_arr_default_keys[ $job_key ],
                                                $job_value
                                            );
                                        }
                                        
                                        $this->profile_update_errors[ wp_unique_id( $job_key ) ] = $error_message;
                                        
                                        if ( $work_history_arr_company_name_key === ( string ) $job_key ) {
                                            unset( $submitted_work_history_value_arr[ $work_key ] );
                                        } else {
                                            unset( $work_value[ $job_key ] );
                                        }
                                    } 
                                }
                            }
                        } else {
                            unset( $submitted_work_history_value_arr[ $work_key ] );
                        }
                    }
                    
                    if ( 0 === count( $work_value ) ) {
                        unset( $submitted_work_history_value_arr[ $work_key ] );
                    }
                } else {
                    unset( $submitted_work_history_value_arr[ $work_key ] );
                }
            }
            
            if ( $submitted_work_history_count !== count( $submitted_work_history_value_arr ) ) {
                $submitted_work_history_value_arr = array_values( $submitted_work_history_value_arr );
            }
        }
        
        $profile_section = isset( $previously_saved_userdata[ $work_history_key ] ) ? ( array ) $previously_saved_userdata[ $work_history_key ] : $arr;

        $change = false;

        $this->update_user_profile_section( $submitted_work_history_value_arr, $work_history_jobs_key, $profile_section, $change, $submitted_data[ $work_history_key ] );
        $this->commit_changes_made_to_user_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $work_history_key, $work_history_jobs_key, $change );
    }
    
    //See work history for explanation on how College is updated.
    if ( isset( $submitted_data[ $colleges_key ] ) && is_array( $submitted_data[ $colleges_key ] ) ) {
        $submitted_colleges_value_arr = $submitted_data[ $colleges_key ];

        if ( isset( $submitted_colleges_value_arr[ $privacy_key ] ) ) {
            unset( $submitted_colleges_value_arr[ $privacy_key ] );
        }

        if ( isset( $submitted_colleges_value_arr[ $approval_key ] ) ) {
            unset( $submitted_colleges_value_arr[ $approval_key ] );
        }

        $this->remove_empty_last_key_from_array( $submitted_colleges_value_arr );
        
        $submitted_colleges_count = count( $submitted_colleges_value_arr );
        
        if ( $submitted_colleges_count ) {
            $submitted_colleges_arr_default_keys = array(
                'major'  => $maxlen['textbox'],
                'minor'  => $maxlen['textbox'],
                'degree' => $maxlen['textbox'],
            );
        
            $submitted_colleges_arr_default_keys[ $name ]            = $maxlen['textbox'];
            $submitted_colleges_arr_default_keys[ $description_key ] = $maxlen['textarea_LG'];
            $submitted_colleges_arr_default_keys[ $graduated_key ]   = '';

            $submitted_colleges_arr_default_keys = $submitted_colleges_arr_default_keys + $time_span_arr;
        
            $duplicate_colleges_arr = $arr;

            if ( $maxlen['arraysize'] < $submitted_colleges_count ) {
                $submitted_colleges_value_arr = array_slice( $submitted_colleges_value_arr, 0, $maxlen['arraysize'] );

                if ( 1 === $maxlen['arraysize'] ) {
                    $this->profile_update_errors[ $colleges_key ] = __( 'You can include only one college.', 'describr' );
                } else {
                    $this->profile_update_errors[ $colleges_key ] = sprintf(
                        /*translators: %d: Number of colleges allowed*/
                        __( 'You can include only %d colleges.', 'describr' ),
                        $maxlen['arraysize']
                    );
                }
            }

            foreach( $submitted_colleges_value_arr as $submitted_college_key => &$submitted_college_value ) {
                if ( is_array( $submitted_college_value ) && ! $this->is_duplicate_array( $duplicate_colleges_arr, $submitted_college_value ) && isset( $submitted_college_value[ $name ] ) && ! empty( $submitted_college_value[ $name ] ) ) {
                    $duplicate_colleges_arr[] = $submitted_college_value;
                    
                    foreach( $submitted_college_value as $college_key => $college_value ) {
                        if ( isset( $submitted_colleges_arr_default_keys[ $college_key ] ) ) {
                            if ( $this->is_string_or_numeric( $college_value ) ) {
                                if ( $this->empty( $college_value) ) {
                                    unset( $submitted_college_value[ $college_key ] );
                                } else {
                                    if ( 'from' === ( string ) $college_key ) {
                                        if ( ! $this->is_date( $college_value ) ) {
                                            $this->profile_update_errors[ wp_unique_id( $college_key ) ] = sprintf(
                                                /*translators: 1: Date, 2: College name*/
                                                __( 'The date <strong>%1$s</strong> you started attending %2$s is invalid. Supported date format: YYYY-MM-DD.', 'describr' ),
                                                $college_value,
                                                $submitted_college_value[ $name ]
                                            );
                                      
                                            unset( $submitted_college_value[ $college_key ] );
                                        }
                                    } elseif ( 'to' === ( string ) $college_key ) {
                                        $unset_to = false;

                                        if ( ! isset( $submitted_college_value['from'] ) || empty( $submitted_college_value['from'] ) || ! $this->is_date( $submitted_college_value['from'] ) ) {
                                            $unset_to = true;

                                            $this->profile_update_errors[ wp_unique_id( $college_key ) ] = sprintf(
                                                /*translators: %s: College name*/
                                                __( 'The <strong>to</strong> date must be accompanied by <strong>from</strong> date at %s.', 'describr' ),
                                                $submitted_college_value[ $name ]
                                            );
                                        }

                                        if ( ! $unset_to && ! $this->is_date( $college_value ) ) {
                                            $this->profile_update_errors[ wp_unique_id( $college_key ) ] = sprintf(
                                                /*translators: 1: Date, 2: College name*/
                                                __( 'The date <strong>%1$s</strong> you stopped attending %2$s is invalid. Supported date format: YYYY-MM-DD.', 'describr' ),
                                                $college_value,
                                                $submitted_college_value[ $name ]
                                            );

                                            $unset_to = true;
                                        }

                                        if ( $unset_to ) {
                                            unset( $submitted_college_value[ $college_key ] );
                                        }
                                    } elseif ( $graduated_key === ( string ) $college_key ) {
                                        if ( 1 !== ( int ) $college_value ) {
                                            unset( $submitted_college_value[ $college_key ] );
                                        }
                                    } elseif ( ! empty( $submitted_colleges_arr_default_keys[ $college_key ] ) ) {
                                        if ( $submitted_colleges_arr_default_keys[ $college_key ] < mb_strlen( ( string ) $college_value ) ) {
                                            if ( $name === ( string ) $college_key ) {
                                                $error_message = sprintf(
                                                    /*translators: 1: College name, 2: Number of characters allowed in college name*/
                                                    __( '%1$s cannot have more than %2$d characters.', 'describr' ),
                                                    $college_value,
                                                    $submitted_colleges_arr_default_keys[ $college_key ]
                                                );
                                            } elseif ( 'major' === ( string ) $college_key ) {
                                                $error_message = sprintf(
                                                    /*translators: 1: Number of characters allowed in college major, 2: College major*/
                                                    __( 'College major cannot have more than %1$d characters: %2$s.', 'describr' ),
                                                    $submitted_colleges_arr_default_keys[ $college_key ],
                                                    $college_value
                                                );
                                            } elseif ( 'minor' === ( string ) $college_key ) {
                                                $error_message = sprintf(
                                                    /*translators: 1: Number of characters allowed in college minor, 2: College minor*/
                                                    __( 'College minor cannot have more than %1$d characters: %2$s.', 'describr' ),
                                                    $submitted_colleges_arr_default_keys[ $college_key ],
                                                    $college_value
                                                );
                                            } elseif ( 'degree' === ( string ) $college_key ) {
                                                $error_message = sprintf(
                                                    /*translators: 1: Number of characters allowed in college degree, 2: College degree*/
                                                    __( 'Degree cannot have more than %1$d characters: %2$s.', 'describr' ),
                                                    $submitted_colleges_arr_default_keys[ $college_key ],
                                                    $college_value
                                                );
                                            } else {
                                                $error_message = sprintf(
                                                    /*translators: 1: Number of characters allowed in the description of the college experience of the user, 2: Description of the college experience of the user*/
                                                    __( 'College experience cannot have more than %1$d characters: %2$s.', 'describr' ),
                                                    $submitted_colleges_arr_default_keys[ $college_key ],
                                                    $college_value,
                                                );
                                            }
                                        
                                            $this->profile_update_errors[ wp_unique_id( $college_key ) ] = $error_message;

                                            if ( $name === ( string ) $high_school_value_key ) {
                                                unset( $submitted_colleges_value_arr[ $submitted_college_key ] );
                                            } else {
                                                unset( $submitted_college_value[ $college_key ] );
                                            }
                                        }
                                    }
                                }
                            } else {
                                unset( $submitted_colleges_value_arr[ $submitted_college_key ] );
                            }
                        } else {
                            unset( $submitted_colleges_value_arr[ $submitted_college_key ] );
                        }
                    }

                    if ( 0 === count( $submitted_college_value ) ) {
                        unset( $submitted_colleges_value_arr[ $submitted_college_key ] );
                    }  
                } else {
                    unset( $submitted_colleges_value_arr[ $submitted_college_key ] );
                }
            }

            if ( $submitted_colleges_count !== count( $submitted_colleges_value_arr ) ) {
                $submitted_colleges_value_arr = array_values( $submitted_colleges_value_arr );
            }
        }
        
        $profile_section = isset( $previously_saved_userdata[ $colleges_key ] ) ? ( array ) $previously_saved_userdata[ $colleges_key ] : $arr;

        $change = false;

        $this->update_user_profile_section( $submitted_colleges_value_arr, $school_key, $profile_section, $change, $submitted_data[ $colleges_key ] );
        
        $this->commit_changes_made_to_user_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $colleges_key, $school_key, $change );
    }
    
    if ( isset( $submitted_data[ $high_school_key ] ) && is_array( $submitted_data[ $high_school_key ] ) ) {
        $submitted_high_school_value_arr = $submitted_data[ $high_school_key ];
        
        if ( isset( $submitted_high_school_value_arr[ $privacy_key ] ) ) {
            unset( $submitted_high_school_value_arr[ $privacy_key ] );
        }

        if ( isset( $submitted_high_school_value_arr[ $approval_key ] ) ) {
            unset( $submitted_high_school_value_arr[ $approval_key ] );
        }

        $this->remove_empty_last_key_from_array( $submitted_high_school_value_arr );

        $submitted_high_schools_count = count( $submitted_high_school_value_arr );

        if ( $submitted_high_schools_count ) {
            $submitted_high_school_arr_default_keys = $arr;

            $submitted_high_school_arr_default_keys[ $name ]            = $maxlen['textbox'];
            $submitted_high_school_arr_default_keys[ $description_key ] = $maxlen['textarea_LG'];
            $submitted_high_school_arr_default_keys[ $graduated_key ]   = ''; 

            $submitted_high_school_arr_default_keys = $submitted_high_school_arr_default_keys + $time_span_arr;
        
            $duplicate_high_school_names_arr = $arr;

            if ( $maxlen['arraysize'] < $submitted_high_schools_count ) {
                $submitted_high_school_value_arr = array_slice( $submitted_high_school_value_arr, 0, $maxlen['arraysize'] );

                if ( 1 === $maxlen['arraysize'] ) {
                    $this->profile_update_errors[ $high_school_key ] = __( 'You can include only one high school.', 'describr' );
                } else {
                    $this->profile_update_errors[ $high_school_key ] = sprintf(
                        /*translators: %d: Number of high schools allowed*/
                        __( 'You can include only %d high schools.', 'describr' ),
                        $maxlen['arraysize']
                    );
                }
            }

            foreach( $submitted_high_school_value_arr as $submitted_high_school_key => $submitted_high_school_value ) {
                if ( is_array( $submitted_high_school_value ) && ! $this->is_duplicate_array( $duplicate_high_school_names_arr, $submitted_high_school_value ) && isset( $submitted_high_school_value[ $name ] ) && ! empty( $submitted_high_school_value[ $name ] ) ) {
                    $duplicate_high_school_names_arr[] = $submitted_high_school_value;

                    foreach( $submitted_high_school_value as $high_school_value_key => $high_school_value ) {
                        if ( isset( $submitted_high_school_arr_default_keys[ $high_school_value_key ] ) ) {
                            if ( $this->is_string_or_numeric( $high_school_value ) ) {
                                if ( $this->empty( $high_school_value ) ) {
                                    unset( $submitted_high_school_value[ $high_school_value_key ] );
                                } else {
                                    if ( 'from' === ( string ) $high_school_value_key ) {
                                        if ( ! $this->is_date( $high_school_value ) ) {
                                            $this->profile_update_errors[ wp_unique_id( $high_school_key ) ] = sprintf(
                                                    /*translators: 1: Date, 2: High school name*/
                                                    __( 'The date <strong>%1$s</strong> you started attending %2$s is invalid. Supported date format: YYYY-MM-DD.', 'describr' ),
                                                    $high_school_value,
                                                    $submitted_high_school_value[ $name ]
                                                );
                                        
                                            unset( $submitted_high_school_value[ $high_school_value_key ] );
                                        }
                                    } elseif ( 'to' === ( string ) $high_school_value_key ) {
                                        $unset_to = false;

                                        if ( ! isset( $submitted_high_school_value['from'] ) || empty( $submitted_high_school_value['from'] ) || ! $this->is_date( $submitted_high_school_value['from'] ) ) {
                                            $this->profile_update_errors[ wp_unique_id( $high_school_key ) ] = sprintf(
                                                    /*translators: %s: High school name*/
                                                    __( 'The <strong>to</strong> date must be accompanied by <strong>from</strong> date at %s.', 'describr' ),
                                                    $submitted_high_school_value[ $name ]
                                                );

                                            $unset_to = true;
                                        }

                                        if ( ! $unset_to &&  ! $this->is_date( $high_school_value ) ) {
                                            $this->profile_update_errors[ wp_unique_id( $high_school_key ) ] = sprintf(
                                                    /*translators: 1: Date, 2: High school name*/
                                                    __( 'The date <strong>%1$s</strong> you stopped attending %2$s is invalid. Supported date format: YYYY-MM-DD.', 'describr' ),
                                                    $high_school_value,
                                                    $submitted_high_school_value[ $name ]
                                                );

                                            $unset_to = true;
                                        }

                                        if ( $unset_to ) {
                                            unset( $submitted_high_school_value[ $high_school_value_key ] );
                                        }
                                    } elseif ( $graduated_key === ( string ) $high_school_value_key ) {
                                        if ( 1 !== ( int ) $high_school_value ) {
                                            unset( $submitted_high_school_value[ $high_school_value_key ] );
                                        }
                                    } elseif( ! empty( $submitted_high_school_arr_default_keys[ $high_school_value_key ] ) ) {
                                        if ( $submitted_high_school_arr_default_keys[ $high_school_value_key ] < mb_strlen( ( string ) $high_school_value ) ) {
                                            if ( $description_key === ( string ) $high_school_value_key ) {
                                                $error_message = sprintf(
                                                    /*translators: 1: Number of characters allowed in the description of the high school experience of the user, 2: Description of the high school experience of the user*/
                                                    __( 'High school experience cannot have more than %1$d characters: %2$s.', 'describr' ),
                                                    $submitted_high_school_arr_default_keys[ $high_school_value_key ],
                                                    $high_school_value
                                                );
                                            } else {
                                                $error_message = sprintf(
                                                    /*translators: 1: High school name, 2: Number of characters allowed in high school name*/
                                                    __( '%1$s cannot have more than %2$d characters.', 'describr' ),
                                                    $high_school_value,
                                                    $submitted_high_school_arr_default_keys[ $high_school_value_key ]
                                                );
                                            }
                                        
                                            $this->profile_update_errors[ wp_unique_id( $high_school_key ) ] = $error_message;

                                            if ( $name === ( string ) $high_school_value_key ) {
                                                unset( $submitted_high_school_value_arr[ $submitted_high_school_key ] );
                                            } else {
                                                unset( $submitted_high_school_value[ $high_school_value_key ] );
                                            }
                                        }
                                    }
                                }
                            } else {
                                unset( $submitted_high_school_value_arr[ $submitted_high_school_key ] );
                            }
                            
                        } else {
                            unset( $submitted_high_school_value_arr[ $submitted_high_school_key ] );
                        }
                    }
                    
                    if ( 0 === count( $submitted_high_school_value ) ) {
                        unset( $submitted_high_school_value_arr[ $submitted_high_school_key ] );
                    }
                } else {
                    unset( $submitted_high_school_value_arr[ $submitted_high_school_key ] );
                }
            }

            if ( $submitted_high_schools_count !== count( $submitted_high_school_value_arr ) ) {
                $submitted_high_school_value_arr =  array_values( $submitted_high_school_value_arr );
            }
        }
            
        $profile_section = isset( $previously_saved_userdata[ $high_school_key ] ) ? ( array ) $previously_saved_userdata[ $high_school_key ] : $arr;
        
        $change = false;

        $this->update_user_profile_section( $submitted_high_school_value_arr, $school_key, $profile_section, $change, $submitted_data[ $high_school_key ] );
        
        $this->commit_changes_made_to_user_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $high_school_key, $school_key, $change );
    }
}

if ( $updated_userdata ) {
    $this->plugin_update_user_meta( $user_id, $previously_saved_userdata, $updated_userdata );
} elseif ( $previously_saved_userdata_count !== count( $previously_saved_userdata ) ) {
    $this->plugin_update_user_meta( $user_id, $previously_saved_userdata );
}

/**
 * Credit to Simple Local Avatars for how to upload avatar
 * 
 * @see https://10up.com/plugins/simple-local-avatars-wordpress/
 */
if ( isset( $_FILES['describr_avatar'] ) && ! empty( $_FILES['describr_avatar']['name'] ) && $this->can_upload_files() ) {
    
    $filename = sanitize_text_field( $_FILES['describr_avatar']['name'] );
    
    $upload_size_limit = $this->upload_size_limit();

    if ( isset( $_FILES['describr_avatar']['size'] ) && absint( $_FILES['describr_avatar']['size'] ) > $upload_size_limit ) {
        $this->profile_update_errors['avatar_errors'] = sprintf(
            /*translators: 1: File name, 2: upload_max_filesize*/
            __( '%1$s exceeds the maximum upload size for this site. The maximum upload file size is %2$s.', 'describr' ),
            wp_basename( $this->uniform_directory_separator( $filename ) ),
            size_format( $upload_size_limit )
        );
        return;
    }
    
    if ( ! $this->is_image( $filename ) ) {
        $this->profile_update_errors['avatar_errors'] = sprintf(
            /*translators: 1: File name, 2: File extensions*/
            __( '%1$s file type is not supported. Supported image file types: %2$s.', 'describr' ),
            wp_basename( $this->uniform_directory_separator( $filename ) ),
            implode( ', ', $this->supported_image_types() ) 
        );

        return;
    }
    
    //Support for files being uploaded from front-end
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    
    $this->upload_avatar_user_id = $user_id;//Used in unique_filename_callback function 
        
    //Uploading of avatar is handled by WordPress' media_handle_upload function
    $avatar_id = media_handle_upload(
        'describr_avatar',
        0,
        array(),
        array(
        'mimes' => array(
            'jpg|jpeg|jpe' => 'image/jpeg',
            'gif'          => 'image/gif',
            'png'          => 'image/png',
        ),
        'test_form'                => false,
        'unique_filename_callback' => array( $this, 'unique_filename_callback' ),
        )
    );
                
    if ( is_wp_error( $avatar_id ) ) {
        $this->profile_update_errors['avatar_errors'] = $avatar_id->get_error_message();
    } else{
        $this->assign_avatar( $avatar_id, $user_id );
    }
}

