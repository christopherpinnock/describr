<?php
//Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit; 
}

/**
 * Translates texts that are displayed by JavaScript
 * 
 * @return array
 */
function describr_translated_texts () {
    return array(
        'privacy' => array(
            __( 'Everyone', 'describr' ), 
            __( 'Only me', 'describr' ), 
        ),
        'choose' => array(
            __( 'Choose an image', 'describr' ),
            __( 'Choose a country', 'describr' ),
            __( 'Choose your gender', 'describr' ),
            __( 'Choose an image from your computer:', 'describr' ),
            __( 'Choose your time zone', 'describr' ),
            /*translators: %s: Profile section*/
            __( 'Choose a privacy status for %s', 'describr' ),
            __( 'Choose a Partner', 'describr' ),
            __( 'Choose a Language', 'describr' ),
            __( 'Choose a City', 'describr' ),
            __( 'Choose your relationship status', 'describr' ),
            __( 'Choose a year', 'describr' ),
            __( 'Choose a month', 'describr' ),
            __( 'Choose a day', 'describr' ),
            ),
        'general' => array(
            __( 'Upload Avatar', 'describr' ),
            __( 'Update profile picture', 'describr' ),
            __( 'Remove profile picture', 'describr' ),               
            __( 'Set as profile picture', 'describr' ),
            __( 'Country', 'describr' ),                
            __( 'Phone number', 'describr' ),
            __( 'Please try again.', 'describr' ),
            __( 'Cancel', 'describr' ),
            __( 'extension', 'describr' ),                
            __( 'to', 'describr' ),
            __( 'by', 'describr' ),
            __( 'from', 'describr' ),
            __( 'with', 'describr' ),
            __( 'First name', 'describr' ),
            __( 'Last name', 'describr' ),
            __( 'Enter your current city', 'describr' ),
            __( 'Enter your hometown', 'describr' ),      
            __( 'This profile is inappropriate for public viewing. An explanation was sent to the email on file.', 'describr'),
            __( 'Search languages', 'describr' ),
            __( 'Search', 'describr' ),
            __( 'Selected values', 'describr' ),
            __( 'Remove', 'describr' ),
            __( 'Edit', 'describr' ),
            __( 'City', 'describr' ),
            __( 'Enter a city', 'describr' ),
            __( 'Moved', 'describr' ),
            __( 'Biography', 'describr' ),
            __( 'Unpublished', 'describr' ),
            __( 'Clear', 'describr' ),
            __( 'Time period', 'describr' ),
            __( 'Description', 'describr' ),
            __( 'in', 'describr' ),
            __( 'Share a little about you', 'describr' ),
            __( 'Profile data has been loaded.', 'describr' ),
            /*translators: %s: Profile section*/
            __( '%s has been unpublished by the administrator of this site.' ,'describr' ),              
            __( 'The website URL you provided is invalid. Please enter a correct URL and try again.', 'describr' ),
            __( 'Social network', 'describr' ),
            __( 'Username', 'describr' ),
            __( 'Website address', 'describr' ),
            __( 'Profile picture actions', 'describr' ),
            __( 'No profile picture actions approved', 'describr' ),
            __( 'This profile is published.', 'describr' ),
            __( 'This profile is unpublished.', 'describr' ),
            __( 'Male', 'describr' ),
            __( 'Female', 'describr' ),
            __( 'and', 'describr' ),
            __( 'Privacy', 'describr' ),
            __( 'Last updated', 'describr' ),
            __( 'Basic Info', 'describr' ),
            __( 'Dismiss this notice.', 'describr' ),
            ),
        'placeholders' => array(
            /*translators: %d: Number of characters*/
            __( '%d characters', 'describr' ),
            /*translators: 1: Number of typed characters, 2: Number of characters allowed*/
            __( 'You have typed %1$d of the %2$d characters allowed.', 'describr' ),
            /*translators: 1 File name, 2: File extensions*/
            __( '%1$s file type not supported. Supported file types: %2$s.', 'describr' ),
            /*translators: 1 File name, 2: upload_max_filesize*/
            __( '%1$s exceeds the maximum upload size for this site. The maximum upload file size is %2$s.', 'describr' ),
            /*translators: %s: Profile section*/ 
            __( 'Privacy status for %s', 'describr' ),       
            /*translators: %s: Profile section*/ 
            __( '%s is published', 'describr' ),       
            /*translators: %s: Profile section*/ 
            __( '%s is unpublished', 'describr' ),
            /*translators: %s: Profile section*/ 
            __( 'Unpublish %s', 'describr' ),
            /*translators: %s: Profile section*/ 
            __( 'Publish %s', 'describr' ),
            /*translators: %s: User's name*/
            __( '%s Is Not Logged In', 'describr' ),
            /*translators: %s: User's name*/
            __( '%s Is Logged In', 'describr' ),
            /*translators: %s: User's name*/ 
            __( '%s picture actions', 'describr' ), 
            /*translators: %s: User's name*/ 
            __( 'Remove %s profile picture', 'describr'  ),
            /*translators: %s: Plugin name*/ 
            __( 'You can set %s Avatar as your default avatar in settings>discussion>avatars.', 'describr'  ),
            /*translators: %s Date*/
            __( 'Moved %s', 'describr' ), 
            /*translators: %s: User's name*/
            __( '%s profile data has been loaded.', 'describr' ),
        ),
        'labels'  => array(
            'sections' => array(
                __( 'Published', 'describr' ),
                __( 'Avatar', 'describr' ),
                __( 'Tagline', 'describr' ),
                __( 'Name', 'describr' ),
                __( 'Gender', 'describr' ), 
                __( 'Birthdate', 'describr' ),
                __( 'Bio', 'describr' ),
                __( 'Addresses', 'describr' ),
                __( 'Hometown', 'describr' ),
                __( 'Current City', 'describr' ),
                __( 'Cities Lived', 'describr'), 
                __( 'Relationship', 'describr' ),
                __( 'Languages', 'describr' ),
                __( 'Contact', 'describr' ),
                __( 'Phone', 'describr' ),
                __( 'Email Address', 'describr' ),
                __( 'Time Zone', 'describr' ),
                __( 'Social Networks' , 'describr' ),
                __( 'Websites', 'describr' ),
                __( 'Work', 'describr' ),
                __( 'Education', 'describr' ),
                __( 'College', 'describr' ),
                __( 'High School', 'describr' ),
            ),
            'section_events' => array(
                /*translators: %s: User's name*/
                __( 'View %s colleges editors', 'describr' ),
                /*translators: %s: User's name*/
                __( '%s colleges editors', 'describr' ),
                /*translators: %s: User's name*/
                __( 'View %s high schools editors', 'describr' ),
                /*translators: %s: User's name*/
                __( '%s high school editors', 'describr' ),
                /*translators: %s: User's name*/
                __( '%s profile photo editors', 'describr' ),                
                /*translators: %s: User's name*/
                __( 'View %s profile photo editors', 'describr' ),            
                /*translators: %s: User's name*/
                __( '%s addresses editors', 'describr' ),
                /*translators: %s: User's name*/
                __( 'View %s addresses editors', 'describr' ),             
                /*translators: %s: User's name*/
                __( '%s phone number editors', 'describr' ),                  
                /*translators: %s: User's name*/
                __( 'View %s phone numbers editors', 'describr' ),                    
                /*translators: %s: User's name*/
                __( '%s email editors', 'describr' ),                    
                /*translators: %s: User's name*/
                __( 'View %s email editors', 'describr' ),                    
                /*translators: %s: User's name*/
                __( '%s name editors', 'describr' ),                   
                /*translators: %s: User's name*/
                __( 'View %s name editors', 'describr' ),
                /*translators: %s: User's name*/
                __( '%s gender editors', 'describr' ),                   
                /*translators: %s: User's name*/
                __( 'View %s gender editors', 'describr' ),                    
                /*translators: %s: User's name*/
                __( '%s birthdate editors', 'describr' ),                    
                /*translators: %s: User's name*/
                __( 'View %s birthdate editors', 'describr' ),                
                /*translators: %s: User's name*/
                __( '%s biography editors', 'describr' ),                   
                /*translators: %s: User's name*/
                __( 'View %s biography editors', 'describr' ),                    
                /*translators: %s: User's name*/
                __( '%s time zone editors', 'describr' ),                    
                /*translators: %s: User's name*/
                __( 'View %s time zone editors', 'describr' ),                   
                /*translators: %s: User's name*/
                __( '%s social networks editors', 'describr' ),                   
                /*translators: %s: User's name*/
                __( 'View %s social networks editors', 'describr' ),                    
                /*translators: %s: User's name*/
                __( '%s Web site editors', 'describr' ),                    
                /*translators: %s: User's name*/
                __( 'View %s Web site editors', 'describr' ),                    
                /*translators: %s: User's name*/
                __( '%s Work editors', 'describr' ),
                /*translators: %s: User's name*/
                __( 'View %s Work editors', 'describr' ),
            ),
        ),
        'contact' => array(
            'phones' => array(
                'country' => __( 'Phone number country', 'describr' ),
                'types'  => array(
                    'MOBILE'               => __( 'Mobile', 'describr' ),
                    'FIXED_LINE'           => __( 'Fixed line', 'describr' ),
                    'FIXED_LINE_OR_MOBILE' => __( 'Fixed line or mobile', 'describr' ),
                    'PREMIUM_RATE'         => __( 'Premium rate', 'describr' ),
                    'SHARED_COST'          => __( 'Shared cost', 'describr' ),
                    'VOIP'                 => __( 'VOIP', 'describr' ),
                    'PERSONAL_NUMBER'      => __( 'Personal number', 'describr' ),
                    'PAGER'                => __( 'Pager', 'describr' ),
                    'VOICEMAIL'            => __( 'Voicemail', 'describr' ),
                ),
                'errors' => array(
                    'NOT_A_NUMBER'     => __( 'No phone number was supplied. Phone number must have area code and cannot include alphabetic characters.', 'describr' ),
                    'INVALID_COUNTRY'  => __( 'The country is invalid for this phone number. Make sure to add the correct area code.', 'describr' ),
                    'TOO_SHORT'        => __( 'The phone number is too short.', 'describr' ),
                    'TOO_LONG'         => __( 'The phone number is too long.', 'describr' ),
                    'INCORRECT_FORMAT' => __( 'Phone number format does not match that of the country selected.', 'describr' ),
                ),
            ),
            'email' => array(
                'placeholder' => __( 'Enter your email address', 'describr' ),
                'errors' => array(
                    __( 'Email address must be at least three characters in length.', 'describr' ),
                    __( 'Email address must have at least one @ character.', 'describr' ),
                    __( 'Invalid email address format.' , 'describr' ),
                ),
            ),
        ),
        'relationship' => array(
            'labels' => array(
                __( 'Relationship status', 'describr' ),
                __( 'Status', 'describr' ),
                __( 'Partner', 'describr' ),
                __( 'Search for partner', 'describr' ),
                __( 'Since', 'describr' ),
                __( 'since', 'describr' ),
            ),
            'status' => array(
                   __( 'Single', 'describr' ),
                   __( 'In a relationship', 'describr' ),
                   __( 'Engaged', 'describr' ),
                   __( 'Married', 'describr' ),
                   __( 'Separated', 'describr' ),
                   __( 'Divorced', 'describr' ),
                   __( 'Widowed', 'describr' ),
                   __( 'In a domestic partnership', 'describr' ),
                   __( 'In a civil union', 'describr' ),
                   __( 'Friends with benifits', 'describr' ),
               ),
           ),
           'date' => array(
               __( 'Year', 'describr' ),
               __( 'Month', 'describr' ),
               __( 'Day', 'describr' ),
           ),
           'company' => array(
               __( 'Job description', 'describr' ),
               __( 'at', 'describr' ),
               __( 'present', 'describr' ),
               __( 'Company name', 'describr' ),
               __( 'Company', 'describr' ),
               __( 'Title', 'describr' ),
               __( 'I still work here', 'describr' ),
           ),
           'schools' => array(
            'general' => array(
                __( 'Graduated', 'describr' ),
            ),
            'highschool' => array(
                /*translators: %s: Name of college or name of high school*/
                __( 'Went to %s', 'describr' ),
                /*translators: %s: Name of college or name of high school*/
                __( 'Attending %s', 'describr' ),
                __( 'High school experience', 'describr' ),
            ),
            'college' => array(
                /*translators: %s: College minor*/
                __( 'Also studied %s', 'describr' ),
                /*translators: %s: College minor*/
                __( 'Also studying %s', 'describr' ),
                __( 'Major', 'describr' ),
                __( 'Minor', 'describr' ),
                __( 'Degree', 'describr' ),
                __( 'College experience', 'describr' ),
            ),
        ),
        'timezone' => array(
            __( 'Manual UTC Offsets', 'describr' ),
            /*translators: %s: Name of continent*/ 
            __( '%s time zones', 'describr' ),
        ),
        'months' => array(
            __( 'Jan', 'describr' ),
            __( 'Feb', 'describr' ),
            __( 'Mar', 'describr' ),
            __( 'Apr', 'describr' ),
            __( 'May', 'describr' ),
            __( 'Jun', 'describr' ),
            __( 'Jul', 'describr' ),
            __( 'Aug', 'describr' ),
            __( 'Sept', 'describr' ),
            __( 'Oct', 'describr' ),
            __( 'Nov', 'describr' ),
            __( 'Dec', 'describr' ),
        ),
    );
}