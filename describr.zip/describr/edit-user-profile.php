<?php
if (  ! current_user_can( 'edit_user', $user_id )  ) {
    return;
}

$plugin = self::$plugin;

$nonce = $plugin . '_update_profile_nonce';

if ( empty( $_POST[ $nonce ] ) ) {
    return;
} elseif( ! wp_verify_nonce( $_POST[ $nonce ], $nonce ) ) {
    return;
}

//Main keys for locating the sections in both $user->describr and $_POST 
$avatar_key             = 'avatar';
$tagline_key            = 'tagline';
$badge_key              = 'badge';
$gender_key             = 'gender';
$birthdate_key          = 'birthdate';
$bio_key                = 'bio';
$physical_addresses_key = 'addresses';
$relationship_key       = 'relationship';
$language_key           = 'langs';
$contact_key            = 'contact';
$timezone_key           = 'timezone';
$social_networks_key    = 'socialnetwrks';
$websites_key           = 'websites';
$work_history_key       = 'workhistory';
$colleges_key           = 'colleges';
$high_school_key        = 'highschools';

$description_key = 'description';
$graduated_key   = 'graduated' ;
$school_key      = 'schools';
$name = 'name';

$privacy_key  = self::$visibility_key;
$approval_key = self::$approval_key;

$errors_key = '_errors';

$change = false;

$post = $_POST;

$published = $plugin . '_published';

$casting_array = array();//will always be empty, as it is used to declare variables as arrays.

/**
 * Stores updated user data that will be added to the database
 * 
 * @var array
 */
$updated_userdata = $casting_array;

$user = get_user_by( 'id', $user_id );

if ( ! $user ) {
    return;
}

$previously_saved_userdata  = ( array ) $user->$plugin;

/**
 * All other user-supplied information is submitted by the way of the $_POST[$plugin] array.
 * 
 * The general principles are new fields will be created, already saved values will
 * be updated, and empty fields coming from the browser will be set to empty in the 
 * database if the fields in the database were previously not empty.
 */

if ( isset( $post[ $plugin ] ) ) {
    $post = ( array ) $post[ $plugin ];
    
    if ( current_user_can( 'edit_others_posts' ) ) {
        $submitted_published_value = isset( $post['profile']['published'] ) ? ( int ) $post['profile']['published'] : 0;    
    
        if ( (int) $user->$published !== $submitted_published_value ) {
            update_user_meta( $user_id, $published, $submitted_published_value );
        }
    }
    
    //Uploading of the avatar is done at the bottom of this page.
    if ( isset( $post[ $avatar_key ] ) ) {
        $submitted_avatar_array = ( array ) $post[ $avatar_key ];

        $profile_section = isset( $previously_saved_userdata[ $avatar_key ] ) ? $previously_saved_userdata[ $avatar_key ] : $casting_array;
        
        $this->add_profile_section_controls( $profile_section, $submitted_avatar_array, $change );
        
        if ( $change ) {
            if ( isset( $previously_saved_userdata[ $avatar_key ] ) ) {
                unset( $previously_saved_userdata[ $avatar_key ] );
            }

            $updated_userdata[ $avatar_key ] = $this->update_profile_section_event_log( $profile_section );
        }
    }//avatar

    if ( isset( $post[ $tagline_key ] ) ) {
        $submitted_tagline_array = ( array ) $post[ $tagline_key ];

        $change = false;

        $submitted_tagline_value = '';

        $profile_section = isset( $previously_saved_userdata[ $tagline_key ] ) ? $previously_saved_userdata[ $tagline_key ] : $casting_array;
        
        if ( ! empty( $submitted_tagline_array[ $description_key ] ) ) {
            $submitted_tagline_value = $this->trunc( $submitted_tagline_array[ $description_key ], 'Tagline', 20 );
            $submitted_tagline_value = $this->sanitize_txt( $submitted_tagline_value );            
        }
        
        $this->update_profile_section( $submitted_tagline_value, $description_key, $profile_section, $change, $submitted_tagline_array );
        
        $this->commit_changes_made_to_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $tagline_key, $description_key, $change );       
    }//tagline
    
    if ( isset( $post[ $badge_key ] ) ) {
        $submitted_badge_array = ( array ) $post[ $badge_key ];

        $badge_first_name_key = 'first_' . $name;
        $badge_last_name_key  = 'last_' . $name;
        
        $submitted_badge_first_name_value = '';
        $submitted_badge_last_name_value = '';

        $change = false;
        
        $profile_section = isset( $previously_saved_userdata[ $badge_key ] ) ? $previously_saved_userdata[ $badge_key ] : $casting_array;

        $this->add_profile_section_controls( $profile_section, $submitted_badge_array, $change );
        
        if ( isset( $submitted_badge_array[ $badge_first_name_key ] ) ) {
            $submitted_badge_first_name_value = $this->sanitize_txt( $submitted_badge_array[ $badge_first_name_key ] );
            
            if ( '' === $submitted_badge_first_name_value ) {
                //Remove first name from db if there's an existing first name, but the field coming from client is empty.
                if ( isset( $profile_section[ $badge_first_name_key ] ) ) { 
                    unset( $profile_section[ $badge_first_name_key ] );
                    
                    $change = true;
                }
            } elseif ( isset( $profile_section[ $badge_first_name_key ] ) ) {
                //Update pre-existing first name only if it's different from new first name.
                if ( ( string ) $submitted_badge_first_name_value !== ( string ) $profile_section[ $badge_first_name_key ] ) {
                    $profile_section[ $badge_first_name_key ] = $submitted_badge_first_name_value;

                    $change = true;
                }
            } else {
                $profile_section[ $badge_first_name_key ] = $submitted_badge_first_name_value;

                $change = true;
            }
        }//first name

        if ( isset( $submitted_badge_array[ $badge_last_name_key ] ) ) {
            $submitted_badge_last_name_value = $this->sanitize_txt( $submitted_badge_array[ $badge_last_name_key ]  );
            
            if ( '' === $submitted_badge_last_name_value  ) {
                if ( isset( $profile_section[ $badge_last_name_key ] ) ) { 
                    unset( $profile_section[ $badge_last_name_key ] );
                    
                    $change = true;
                }
            } elseif ( isset( $profile_section[ $badge_last_name_key ] ) ) {
                if ( ( string ) $submitted_badge_last_name_value !== ( string ) $profile_section[ $badge_last_name_key ] ) {
                    $profile_section[ $badge_last_name_key  ] = $submitted_badge_last_name_value ;

                    $change = true;
                }
            } else {
                $profile_section[ $badge_last_name_key ] = $submitted_badge_last_name_value ;

                $change = true;
            }
        }//last name

        if ( $change ) {
            if ( isset( $previously_saved_userdata[ $badge_key ] ) ) {
                unset( $previously_saved_userdata[ $badge_key ] );
            }
        
            if (  isset( $profile_section[ $badge_first_name_key ] ) || isset( $profile_section[ $badge_last_name_key ] ) ) {
                $updated_userdata[ $badge_key ] = $this->update_profile_section_event_log( $profile_section );
            }
        }
    }//badge
    
    if ( isset( $post[ $gender_key ] ) ) {
        $submitted_gender_array = ( array ) $post[ $gender_key ];

        $gender_type_key = 'type';

        $gender_type_value = '';

        if ( isset( $submitted_gender_array[ $gender_type_key ] ) && in_array( $submitted_gender_array[ $gender_type_key ], array( 'm', 'f' ) ) ) {
            $gender_type_value = $submitted_gender_array[ $gender_type_key ];
        }

        $profile_section = isset( $previously_saved_userdata[ $gender_key ] ) ? $previously_saved_userdata[ $gender_key ] : $casting_array;
        
        $change = false;
        
        $this->update_profile_section( $gender_type_value, $gender_type_key, $profile_section, $change, $submitted_gender_array );
        $this->commit_changes_made_to_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $gender_key, $gender_type_key, $change );
    }//gender

    if ( isset( $post[ $birthdate_key ] ) ) {
        $submitted_birthdate_array = ( array ) $post[ $birthdate_key ];
        
        $date_key = 'date';

        $change = false;

        $birthdate = '';

        if ( isset( $submitted_birthdate_array[ $date_key ] ) && $this->is_date( $submitted_birthdate_array[ $date_key ] ) ) {
             $birthdate = $submitted_birthdate_array[ $date_key ];            
        }

        $profile_section = isset( $previously_saved_userdata[ $birthdate_key ] ) ? $previously_saved_userdata[ $birthdate_key ] : $casting_array;
        
        $this->update_profile_section( $birthdate, $date_key, $profile_section, $change, $submitted_birthdate_array );
        $this->commit_changes_made_to_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $birthdate_key, $date_key, $change );
    }//birthdate

    if ( isset( $post[ $bio_key ] ) ) {
        $submitted_bio_array = ( array ) $post[ $bio_key ];

        $change = false;

        $submitted_bio_value = '';

        $profile_section = isset( $previously_saved_userdata[ $bio_key ] ) ? $previously_saved_userdata[ $bio_key ] : $casting_array;
        
        if ( ! empty( $submitted_bio_array[ $description_key ] ) ) {
            $submitted_bio_value = $this->trunc( $submitted_bio_array[ $description_key ], 'Bio', 300 );
            $submitted_bio_value = $this->sanitize_txt( $submitted_bio_value );                        
        }

        $this->update_profile_section( $submitted_bio_value, $description_key, $profile_section, $change, $submitted_bio_array );
        
        $this->commit_changes_made_to_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $bio_key, $description_key, $change );
    }//bio

    if ( isset( $post[ $physical_addresses_key ] ) ) {
        $submitted_physical_addresses_array = ( array ) $post[ $physical_addresses_key ];
                
        $previously_saved_physical_addresses_array = $casting_array;

        $submitted_physical_addresses_lived_cities_array_default_args = array( 'city' => '', 'moved' => '' );
            
        $change = false;

        $duplicate_lived_cities_array = $casting_array;

        $submitted_lived_cities_errors_array = $casting_array;

        $physical_addresses_current_city_array_key = 'current_city';
        $physical_addresses_hometown_array_key     = 'hometown';
        $physical_addresses_lived_cities_array_key = 'lived_cities';
        
        $submitted_physical_addresses_current_city_value = isset( $submitted_physical_addresses_array[ $physical_addresses_current_city_array_key ] ) ? $this->sanitize_city( $submitted_physical_addresses_array[ $physical_addresses_current_city_array_key ] ) : '';

        $submitted_physical_addresses_hometown_value = isset( $submitted_physical_addresses_array[ $physical_addresses_hometown_array_key ] ) ? $this->sanitize_city( $submitted_physical_addresses_array[ $physical_addresses_hometown_array_key ] ) : '';

        $submitted_physical_addresses_lived_cities_array = isset( $submitted_physical_addresses_array[ $physical_addresses_lived_cities_array_key ] ) ? ( array ) $submitted_physical_addresses_array[ $physical_addresses_lived_cities_array_key ] : $casting_array;

        $previously_saved_physical_addresses_array = isset( $previously_saved_userdata[ $physical_addresses_key ] ) ? $previously_saved_userdata[ $physical_addresses_key ] : $casting_array;
        
        $this->update_profile_section( $submitted_physical_addresses_current_city_value, $physical_addresses_current_city_array_key, $previously_saved_physical_addresses_array, $change );
        
        $this->update_profile_section( $submitted_physical_addresses_hometown_value, $physical_addresses_hometown_array_key, $previously_saved_physical_addresses_array, $change );
        
        foreach( $submitted_physical_addresses_lived_cities_array as $submitted_physical_addresses_lived_cities_array_key => &$lived_city ) {
            if ( is_array( $lived_city ) ) {
                foreach ( $lived_city as $lived_city_key => $lived_city_key_value ) {
                    if ( isset( $submitted_physical_addresses_lived_cities_array_default_args[ $lived_city_key ] ) ) {
                        if ( 'moved' === $lived_city_key ) {
                            if ( ! $this->is_date( $lived_city_key_value ) ) {
                                unset( $lived_city[ $lived_city_key ] );
                            }
                        } else {
                            $lived_city_key_value = $this->sanitize_city( $lived_city_key_value );
                            
                            if ( '' === $lived_city_key_value ) {
                                unset( $submitted_physical_addresses_lived_cities_array[ $submitted_physical_addresses_lived_cities_array_key ] );
                                break;
                            } else {
                                $lowercased_lived_city_key_value = strtolower( $lived_city_key_value );

                                if ( in_array( $lowercased_lived_city_key_value, $duplicate_lived_cities_array ) ) {
                                    $submitted_lived_cities_errors_array[] = $lived_city_key_value;

                                    unset( $submitted_physical_addresses_lived_cities_array[ $submitted_physical_addresses_lived_cities_array_key ] );
                                    break;
                                } else {
                                    $lived_city[ $lived_city_key ] = $lived_city_key_value;
                                    $duplicate_lived_cities_array[] = $lowercased_lived_city_key_value;
                                }
                            }
                        }
                    }//if ( isset( $submitted_physical_addresses_lived_cities_array_default_args[ $lived_city_key ] ) )
                }//foreach
            }//if ( is_array( $lived_city ) ) {                     
        }//foreach

        $this->update_profile_section( array_values( $submitted_physical_addresses_lived_cities_array ), $physical_addresses_lived_cities_array_key, $previously_saved_physical_addresses_array, $change );        
        
        $this->add_profile_section_controls( $previously_saved_physical_addresses_array, $submitted_physical_addresses_array, $change );                    
        
        if ( $submitted_lived_cities_errors_array ) {
            $submitted_lived_cities_errors_array = $this->unique_array_values( $submitted_lived_cities_errors_array );

            if ( 1 === count( $submitted_lived_cities_errors_array ) ) {
                $error_message = sprintf(
                    /*translators: %s: City's name*/
                    __( 'You have a lived city that is included more than once: %s.', 'describr' ),
                    $submitted_lived_cities_errors_array[0]
                );
            } else {
                $error_message = sprintf(
                    /*translators: %s: Multiple cities' names*/
                    __( 'You have several lived cities that are included more than once: %s.', 'describr' ),
                    implode( ', ', $submitted_lived_cities_errors_array )
                );
            }

            if ( $error_message ) {
                $this->profile_update_errors[ $physical_addresses_key . $errors_key ] = $error_message;
            }
        }

        if ( $change ) {
            if ( isset( $previously_saved_userdata[ $physical_addresses_key ] ) ) {
                unset( $previously_saved_userdata[ $physical_addresses_key ] );
            }
            
            if ( $previously_saved_physical_addresses_array ) {
                $updated_userdata[ $physical_addresses_key ] = $this->update_profile_section_event_log( $previously_saved_physical_addresses_array );
            }    
        }
    }//addresses

    if ( isset( $post[ $relationship_key ] ) ) {
        $submitted_relationship_array = ( array ) $post[ $relationship_key ];

        $relationship_status_array_key        = 'status';
        $relationship_partner_array_key       = 'partner';
        $relationship_partner_array_id_key    = 'id';
        $relationship_partner_array_name_key  = 'name';
        $relationship_partner_array_since_key = 'since';

        $submitted_relationship_partner_name  = '';
        $submitted_relationship_partner_id    = '';
        $submitted_relationship_partner_since = '';
        
        $relationship_status = '';

        $change = false;
        
        $profile_section = isset( $previously_saved_userdata[ $relationship_key ] ) ? $previously_saved_userdata[ $relationship_key ] : $casting_array;
        
        if ( isset( $submitted_relationship_array[ $relationship_status_array_key ] ) && in_array( $submitted_relationship_array[ $relationship_status_array_key ], array( 's', 'm', 'iar', 'eng', 'sep', 'div', 'wid' ,'dr' , 'cu', 'fwb' ) ) ) {
            $relationship_status = $submitted_relationship_array[ $relationship_status_array_key ];
        }

        if ( isset( $profile_section[ $relationship_status_array_key ] ) ) {
            if ( $relationship_status ) {
                if ( ( string ) $relationship_status !== ( string ) $profile_section[ $relationship_status_array_key ] ) {
                       $profile_section[ $relationship_status_array_key ] = $relationship_status;
                       $change = true;
                }
            } else {
                unset( $profile_section[ $relationship_status_array_key ] );
                $change = true;
            }
        } elseif ( $relationship_status ) {
            $profile_section[ $relationship_status_array_key ] = $relationship_status;
            $change = true;
        }//status

        if ( isset( $submitted_relationship_array[ $relationship_partner_array_key ] ) ) {
            $partner_array = $submitted_relationship_array[ $relationship_partner_array_key ];
            
            if ( ! empty( $partner_array[ $relationship_partner_array_id_key ] ) ) {
                $submitted_relationship_partner_id = ( int ) $partner_array[ $relationship_partner_array_id_key ];
            }

            if (  empty( $partner_array[ $relationship_partner_array_name_key ] ) ) {
                if ( $submitted_relationship_partner_id ) {
                    $user = get_user_by( 'ID', $submitted_relationship_partner_id );

                    $submitted_relationship_partner_name = $this->username_to_use( $user );
                }
            } else {
                $submitted_relationship_partner_name = $partner_array[ $relationship_partner_array_name_key ]; 
            }
            
            if ( $submitted_relationship_partner_name ) {
                $submitted_relationship_partner_name = $this->sanitize_txt( $submitted_relationship_partner_name );
            }

            if ( ! empty( $partner_array[ $relationship_partner_array_since_key ] ) && $this->is_date( $partner_array[ $relationship_partner_array_since_key ] ) ) {
                $submitted_relationship_partner_since = $partner_array[ $relationship_partner_array_since_key ];
            }
        }
        
        if ( isset( $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_name_key ] ) ) {
            if ( $submitted_relationship_partner_name ) {
                if ( ( string ) $submitted_relationship_partner_name !== ( string ) $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_name_key ]) {
                       $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_name_key ] = $submitted_relationship_partner_name;
                       $change = true;
                }
            } else {
                unset( $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_name_key ] );
                $change = true;
            }
        } elseif ( $submitted_relationship_partner_name ) {
            $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_name_key ] = $submitted_relationship_partner_name;
            $change = true;
        }//partner's name
        
        if ( isset( $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_since_key ] ) ) {
            if ( $submitted_relationship_partner_since ) {
                if ( ( string ) $submitted_relationship_partner_since !== ( string ) $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_since_key ] ) {
                       $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_since_key ] = $submitted_relationship_partner_since;
                       $change = true;
                }
            } else {
                unset( $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_since_key ] );
                $change = true;
            }
        } elseif ( $submitted_relationship_partner_since ) {
            $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_since_key ] = $submitted_relationship_partner_since;
            $change = true;
        }//since

        //Set partner's ID only if partner's name exists.        
        if ( isset( $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_name_key ] ) ) {
            if ( isset( $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_id_key ] ) ) {
                if ( $submitted_relationship_partner_id ) {
                    if ( ( string ) $submitted_relationship_partner_id !== ( string ) $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_id_key ] ) {
                        $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_id_key ] = $submitted_relationship_partner_id;
                        $change = true;
                    }
                } else {
                    unset( $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_id_key ] );
                    $change = true;
                }
            } elseif ( $submitted_relationship_partner_id ) {
                $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_id_key ] = $submitted_relationship_partner_id;
                $change = true;
            } 
        } elseif ( isset( $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_id_key ] ) ) {
            unset( $profile_section[ $relationship_partner_array_key ][ $relationship_partner_array_id_key ] );
            $change = true;
        }
        
        if ( ! empty( $profile_section[ $relationship_partner_array_key ] ) || isset( $profile_section[ $relationship_status_array_key ] ) ) {
            $this->add_profile_section_controls( $profile_section, $submitted_relationship_array, $change );
        }

        if ( $change ) {
            if ( isset( $previously_saved_userdata[ $relationship_key ] ) ) {
                unset( $previously_saved_userdata[ $relationship_key ] );
            }
        
            if ( isset( $profile_section[ $relationship_partner_array_key ] ) || isset( $profile_section[ $relationship_status_array_key ] ) ) {
                $updated_userdata[ $relationship_key ] = $this->update_profile_section_event_log( $profile_section );
            }
        }       
    }//relationship

    if ( isset( $post[ $language_key ] ) ) {
        $submitted_language_array = ( array ) $post[ $language_key ];

        $change = false;
        
        $submitted_languages_value = '';

        if ( isset( $submitted_language_array[ $language_key ] ) ) {
            $submitted_languages_value = $this->sanitize_txt( $submitted_language_array[ $language_key ] );
        }       

        $profile_section = isset( $previously_saved_userdata[ $language_key ] ) ? $previously_saved_userdata[ $language_key ] : $casting_array;

        $this->update_profile_section( $submitted_languages_value, $language_key, $profile_section, $change, $submitted_language_array );
        $this->commit_changes_made_to_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $language_key, $language_key, $change );
    }//languages
    
    if ( isset( $post[ $contact_key ] ) ) {
        $submitted_contact_array = ( array ) $post[ $contact_key ];
        
        $contact_phone_array_key = 'phones';
        $contact_email_array_key = 'email';

        $contact_phonenumbers_array_key  = 'numbers';
        $contact_email_address_array_key = 'address';

        $submitted_contact_email_address_value = '';

        $change = false;
        
        $duplicate_phonenumbers_array = $casting_array;
        
        //$_POST['describr']['contact']['phones']
        if ( isset( $submitted_contact_array[ $contact_phone_array_key ] ) ) {
            $submitted_contact_phonenumbers_array = ( array ) $submitted_contact_array[ $contact_phone_array_key ];
        } else {
            $submitted_contact_phonenumbers_array = $casting_array;
        }

        if ( isset( $submitted_contact_phonenumbers_array[ $contact_phonenumbers_array_key ] ) ) {
            $submitted_contact_phonenumbers_array[ $contact_phonenumbers_array_key ] = ( array ) $submitted_contact_phonenumbers_array[ $contact_phonenumbers_array_key ];
        } else {
            $submitted_contact_phonenumbers_array[ $contact_phonenumbers_array_key ] = $casting_array;
        }
        
        foreach( $submitted_contact_phonenumbers_array[ $contact_phonenumbers_array_key ] as $phone_key => &$phone_value ) {
            if ( empty( $phone_value ) ||  in_array( $phone_value, $duplicate_phonenumbers_array ) ) {
                unset( $submitted_contact_phonenumbers_array[ $contact_phonenumbers_array_key ][ $phone_key ] );
            } else {
                $duplicate_phonenumbers_array[] = $phone_value;
                
                $phone_value = preg_replace( '/[^0-9a-zA-Z\.\(\)\s_\-]+/', '', $phone_value );
            }
        }
        
        //$_POST['describr']['contact']['email']
        if ( isset( $submitted_contact_array[ $contact_email_array_key ] ) ) {
            $submitted_contact_email_address_array = ( array ) $submitted_contact_array[ $contact_email_array_key ];
        } else {
            $submitted_contact_email_address_array = $casting_array;
        }
            
        if ( ! empty( $submitted_contact_email_address_array[ $contact_email_address_array_key ] ) ) {
            $submitted_contact_email_address_value = $submitted_contact_email_address_array[ $contact_email_address_array_key ];
        }

        $profile_section = isset( $previously_saved_userdata[ $contact_key ] ) ? $previously_saved_userdata[ $contact_key ] : $casting_array;
        
        $profile_section[ $contact_phone_array_key ] = isset( $profile_section[ $contact_phone_array_key ] ) ? $profile_section[ $contact_phone_array_key ] : $casting_array;

        $profile_section[ $contact_email_array_key ] = isset( $profile_section[ $contact_email_array_key ] ) ? $profile_section[ $contact_email_array_key ] : $casting_array;      
        
        $this->update_profile_section( array_values( $submitted_contact_phonenumbers_array[ $contact_phonenumbers_array_key ] ), $contact_phonenumbers_array_key, $profile_section[ $contact_phone_array_key ], $change, $submitted_contact_phonenumbers_array );
        
        $this->commit_changes_made_to_profile_section( $profile_section, $profile_section, $profile_section[ $contact_phone_array_key ], $contact_phone_array_key, $contact_phonenumbers_array_key, $change );
         
        //Update email if either no email address has been submitted or the email address has been validated.
        if ( '' === ( string ) $submitted_contact_email_address_value || $this->validate_email( $submitted_contact_email_address_value ) ) {
            $this->update_profile_section( $submitted_contact_email_address_value, $contact_email_address_array_key, $profile_section[ $contact_email_array_key ], $change, $submitted_contact_email_address_array );
            
            $this->commit_changes_made_to_profile_section( $profile_section, $profile_section, $profile_section[ $contact_email_array_key ], $contact_email_array_key, $contact_email_address_array_key, $change );
        }
        
        if ( $change ) {
            if ( isset( $previously_saved_userdata[ $contact_key ] ) ) {
                unset( $previously_saved_userdata[ $contact_key ] );
            }

            if ( isset( $profile_section[ $contact_phone_array_key ] ) || isset( $profile_section[ $contact_email_array_key ] ) ) {
                $updated_userdata[ $contact_key ] = $profile_section;
            }
        } 
    }//contact

    if (  isset( $post[ $timezone_key ] ) ) {
        $submitted_timezone_array = ( array ) $post[ $timezone_key ];

        $change = false;

        $timezone_name_array_key = $name;//This key to locate the actual time zone is "name"

        $timezone_error_key = $timezone_key . $errors_key;

        $submitted_timezone_value = isset( $submitted_timezone_array[ $timezone_name_array_key ] ) ? trim( $submitted_timezone_array[ $timezone_name_array_key ] ) :  '';

        $profile_section = isset( $previously_saved_userdata[ $timezone_key ] ) ? $previously_saved_userdata[ $timezone_key ] : $casting_array;
       
        if ( '' !== ( string ) $submitted_timezone_value && ! $this->is_timezone( $submitted_timezone_value ) && ! $this->is_utc( $submitted_timezone_value ) ) {
            $this->profile_update_errors[ $timezone_error_key ] = sprintf(
                /*translators: %s: Time zone*/
                __( 'Invalid time zone or UTC: %s.', 'describr' ),
                $submitted_timezone_value
            );
        }         
        
        if ( ! isset( $this->profile_update_errors[ $timezone_error_key ] ) ) {
            $this->update_profile_section( $submitted_timezone_value, $timezone_name_array_key, $profile_section, $change, $submitted_timezone_array );
            
            $this->commit_changes_made_to_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $timezone_key, $timezone_name_array_key, $change );
        }       
    }//timezone

    if ( isset( $post[ $social_networks_key ] ) ) {
        $submitted_social_networks_array = ( array ) $post[ $social_networks_key ];
        
        $social_networks_array_key = 'netwrks';
        
        $social_networks_array = ( array ) $submitted_social_networks_array[ $social_networks_array_key ];

        $social_networks_errors_array = $casting_array;

        $duplicate_social_networks = $casting_array; 

        $change = false;

        $profile_section = isset( $previously_saved_userdata[ $social_networks_key ] ) ? $previously_saved_userdata[ $social_networks_key ] : $casting_array;

        foreach ( $social_networks_array as $social_network_key => &$social_network ) {
            if ( empty( $social_network ) || in_array( $social_network, $duplicate_social_networks )  ) {
                unset( $social_networks_array[ $social_network_key ] );
            } elseif ( 1 !== preg_match( '/^([a-z]){2,3}\/([a-zA-Z0-9_\.])+$/', $social_network ) ) {
                $social_networks_errors_array[] = $social_network;
                unset( $social_networks_array[ $social_network_key ] );
            } else {
                $duplicate_social_networks[] = $social_network;
            }        
        }

        $this->update_profile_section( array_values( $social_networks_array ), $social_networks_array_key, $profile_section, $change, $submitted_social_networks_array );
        
        $this->commit_changes_made_to_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $social_networks_key, $social_networks_array_key, $change );
        
        if ( $social_networks_errors_array ) {
            if ( 1 === count( $social_networks_errors_array ) ) {
                $error_message = sprintf(
                    /*translators: %s: One invalid URL*/
                    __( 'Invalid social media network: %s.', 'describr' ),
                    $social_networks_errors_array[0]
                );
            } else {
                $error_message = sprintf(
                    /*translators: %s: Multiple invalid URLs*/
                    __( 'Invalid social media networks: %s.', 'describr' ),
                    implode( ', ', $social_networks_errors_array )
                );
            }
            
            $this->profile_update_errors[ $social_networks_key . $errors_key ] = $error_message;
        }
    }//social networks

    if ( isset( $post[ $websites_key ] ) ) {
        $submitted_websites_array = ( array ) $post[ $websites_key ];
        
        $websites_addresses_array_key = 'addresses';

        $submitted_websites_addresses_array_values = ( array ) $submitted_websites_array[ $websites_addresses_array_key ];

        $duplicate_websites_addresses_array = $casting_array;

        $websites_addresses_errors_array = $casting_array;         

        $change = false;

        $profile_section = isset( $previously_saved_userdata[ $websites_key ] ) ? $previously_saved_userdata[ $websites_key ] : $casting_array;

        foreach ( $submitted_websites_addresses_array_values as $website_address_key => &$website_address_url ) {
            $website_address_url = trim( $website_address_url );
            $website_address_url = strtolower( $website_address_url );
            
            if ( empty( $website_address_url ) || in_array( $website_address_url, $duplicate_websites_addresses_array ) ) {
                unset( $submitted_websites_addresses_array_values[ $website_address_key ] );
            } else {
                $parsed_url = $this->validate_url( $website_address_url );
                
                if ( $parsed_url ) {
                    $website_address_url = $parsed_url;
                    $duplicate_websites_addresses_array[] = $parsed_url;
                } else {
                    $websites_addresses_errors_array[] = $website_address_url;
                    unset( $submitted_websites_addresses_array_values[ $website_address_key ] );
                }
            }
        }
        
        $this->update_profile_section( array_values( $submitted_websites_addresses_array_values ), $websites_addresses_array_key, $profile_section, $change, $submitted_websites_array );
        
        $this->commit_changes_made_to_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $websites_key, $websites_addresses_array_key, $change );
        
        if ( $websites_addresses_errors_array ) {
            if ( 1 == count( $websites_addresses_errors_array ) ) {
                $error_message = sprintf(
                    /*translators: %s: One invalid URL*/
                    __( 'Invalid Web address: %s.', 'describr' ),
                    $websites_addresses_errors_array[0]
                );
            } else {
                $error_message = sprintf(
                    /*translators: %s: Multiple invalid URLs*/
                    __( 'Invalid Web addresses: %s.', 'describr' ),
                    implode( ', ', $websites_addresses_errors_array )
                );
            }
            
            $this->profile_update_errors[ $websites_key . $errors_key ] = $error_message;
        }
    }//Web sites

    if ( isset( $post[ $work_history_key ] ) ) {
        $submitted_work_history_array = ( array ) $post[ $work_history_key ];

        $work_history_array_company_name_key = 'company';
        
        $work_history_jobs_key = 'jobs';
        
        $submitted_work_history_array_default_args = array(
            'position' => '',
            'city'     => '',
            'present'  => '',            
        );
        
        $submitted_work_history_array_default_args[ $work_history_array_company_name_key ] = '';
        $submitted_work_history_array_default_args[ $description_key ]  = '';

        $duplicate_work_history_companies_names_array = $casting_array;
        
        $work_history_errors_array = $casting_array;

        $change = false;

        $profile_section = isset( $previously_saved_userdata[ $work_history_key ] ) ? $previously_saved_userdata[ $work_history_key ] : $casting_array;

        foreach( $submitted_work_history_array as $work_key => &$work_value ) {
            if ( is_array( $work_value ) ) {
                foreach( $work_value as $job_key => $job_value ) {
                    if ( 'frm' === $job_key ) {
                        if ( ! $this->is_date( $job_value ) ) {
                            unset( $work_value[ $job_key ] );
                        }
                    } elseif ( 'to' === $job_key ) {
                         if ( ! isset( $work_value['frm'] ) || ! $this->is_date( $job_value ) ) {
                            unset( $work_value[ $job_key ] );
                        }
                    } elseif ( isset( $submitted_work_history_array_default_args[ $job_key ] ) ) {
                        //If we are at description field and text's length is greater than 1000 characters, truncate text.
                        if ( $description_key === $job_key ) {
                            $job_value = $this->trunc( $job_value, __( 'Work description', 'describr' ) );
                        }

                        $job_value = $this->sanitize_txt( $job_value );

                        if ( '' === $job_value ) {
                            if ( $work_history_array_company_name_key === $job_key ) {
                                unset( $submitted_work_history_array[ $work_key ] ); 
                                break;
                            }
                        } else {
                            $work_value[ $job_key ] = $job_value;

                            if ( $work_history_array_company_name_key === $job_key ) {
                                $lowercased_company = strtolower( $job_value );
                                    
                                //Company names must be unique, but this would not be the case if this company's name is already in stored in $duplicate_work_history_companies_names_array.
                                if ( in_array( $lowercased_company, $duplicate_work_history_companies_names_array ) ) {
                                    unset( $submitted_work_history_array[ $work_key ] );
                                    $work_history_errors_array[] = $job_value;
                                    break;
                                } else {
                                    $duplicate_work_history_companies_names_array[] = $lowercased_company;
                                } 
                            }
                        }
                    } else {
                        unset( $work_value[ $job_key ] );
                    }
                }//foreach
            }//if ( is_array( $work_value ) )
        }//foreach
        
        $submitted_work_history_array_no_controls = $submitted_work_history_array;

        if ( isset( $submitted_work_history_array_no_controls[ $privacy_key ] ) ) {
            unset( $submitted_work_history_array_no_controls[ $privacy_key ] );
        }

        if ( isset( $submitted_work_history_array_no_controls[ $approval_key ] ) ) {
            unset( $submitted_work_history_array_no_controls[ $approval_key ] );
        }
        
        $this->update_profile_section( array_values( $submitted_work_history_array_no_controls ), $work_history_jobs_key, $profile_section, $change, $submitted_work_history_array );
        $this->commit_changes_made_to_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $work_history_key, $work_history_jobs_key, $change );
        
        if ( $work_history_errors_array ) {
            $work_history_errors_array = $this->unique_array_values( $work_history_errors_array );

            if ( 1 === count( $work_history_errors_array ) ) {
                $error_message = sprintf(
                    /*translators: %s: company's name*/
                    __( 'You have a company that is included more than once: %s.', 'describr' ),
                    $work_history_errors_array[0]
                );
            } else {
                $error_message = sprintf(
                    /*translators: %s: multiple companies' names*/
                    __( 'You have several companies that are included more than once: %s.', 'describr' ),
                    implode( ', ', $work_history_errors_array )
                );
            }

            $this->profile_update_errors[ $work_history_key . $errors_key ] = $error_message;
        }
    }//workhistory
    
    //See work history for explanation on how College is updated.
    if ( isset( $post[ $colleges_key ] ) ) {
        $submitted_colleges_array = ( array ) $post[ $colleges_key ];
        
        $submitted_colleges_array_default_args = array(
            'major'  => '',
            'minor'  => '',
            'degree' => '',            
        );
        
        $submitted_colleges_array_default_args[ $name ]            = '';
        $submitted_colleges_array_default_args[ $graduated_key ]   = '';
        $submitted_colleges_array_default_args[ $description_key ] = '';
        
        $duplicate_colleges_names_array = $casting_array;
        
        $colleges_errors_array = $casting_array;

        $change = false;

        $profile_section = isset( $previously_saved_userdata[ $colleges_key ] ) ? $previously_saved_userdata[ $colleges_key ] : $casting_array;

        foreach( $submitted_colleges_array as $submitted_college_key => &$submitted_college_value ) {
            if ( is_array( $submitted_college_value ) ) {
                foreach( $submitted_college_value as $college_key => $college_value ) {
                    if ( 'frm' === $college_key ) {
                        if ( ! $this->is_date( $college_value ) ) {
                            unset( $submitted_college_value[ $college_key ] );
                        }
                    } elseif ( 'to' === $college_key ) { 
                        if ( ! isset( $submitted_college_value['frm'] ) || ! $this->is_date( $college_value ) ) {
                            unset( $submitted_college_value[ $college_key ] );
                        }
                    } elseif ( isset( $submitted_colleges_array_default_args[ $college_key ] ) ) {
                        if ( $description_key === $college_key ) {
                            $college_value = $this->trunc( $college_value, __( 'College description', 'describr' ) );
                        }

                        $college_value = $this->sanitize_txt( $college_value );

                        if ( '' === $college_value ) {
                            if ( $name === $college_key ) {
                                unset( $submitted_colleges_array[ $submitted_college_key ] ); 
                                break; 
                            }
                        } else {
                            $submitted_college_value[ $college_key ] = $college_value;

                            if ( $name === $college_key ) {
                                $lowercased_college_name = strtolower( $college_value );

                                if ( in_array( $lowercased_college_name, $duplicate_colleges_names_array ) ) {
                                    unset( $submitted_colleges_array[ $submitted_college_key ] ); 
                                    $colleges_errors_array[] = $college_value;
                                    break;
                                } else {
                                    $duplicate_colleges_names_array[] = $lowercased_college_name;
                                } 
                            }
                        } 
                    } else {
                        unset( $submitted_college_value[ $college_key ] );
                    }
                }//foreach
            }//if ( is_array( $submitted_college_value ) )
        }//foreach

        $submitted_colleges_array_no_controls = $submitted_colleges_array;

        if ( isset( $submitted_colleges_array_no_controls[ $privacy_key ] ) ) {
            unset( $submitted_colleges_array_no_controls[ $privacy_key ] );
        }

        if ( isset( $submitted_colleges_array_no_controls[ $approval_key ] ) ) {
            unset( $submitted_colleges_array_no_controls[ $approval_key ] );
        }
        
        $this->update_profile_section( array_values( $submitted_colleges_array_no_controls ), $school_key, $profile_section, $change, $submitted_colleges_array );
        
        $this->commit_changes_made_to_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $colleges_key, $school_key, $change );

        if ( $colleges_errors_array ) {
            $colleges_errors_array = $this->unique_array_values( $colleges_errors_array );

            if ( 1 === count( $colleges_errors_array ) ) {
                $error_message = sprintf(
                    /*translators: %s: College's name*/
                    __( 'You have a college that is included more than once: %s.', 'describr' ),
                    $colleges_errors_array[0]
                );
            } else {
                $error_message = sprintf(
                    /*translators: %s: Multiple colleges' names*/
                    __( 'You have several colleges that are included more than once: %s.', 'describr' ),
                    implode( ', ', $colleges_errors_array )
                );
            }
            
            $this->profile_update_errors[ $colleges_key . $errors_key ] = $error_message;
        }
    }//colleges
    
    //See work history for explanation on how High School is updated.
    if ( isset( $post[ $high_school_key ] ) ) {
        $submitted_high_school_array = ( array ) $post[ $high_school_key ];
        
        $submitted_high_school_array_default_args = $casting_array;

        $submitted_high_school_array_default_args[ $name ]            = '';
        $submitted_high_school_array_default_args[ $graduated_key ]   = '';        
        $submitted_high_school_array_default_args[ $description_key ] = '';
        
        $duplicate_high_school_names_array = $casting_array;
        
        $high_school_errors_array = $casting_array;

        $change = false;

        $profile_section = isset( $previously_saved_userdata[ $high_school_key ] ) ? $previously_saved_userdata[ $high_school_key ] : $casting_array;

        foreach( $submitted_high_school_array as $submitted_high_school_key => &$submitted_high_school_value ) {
            if ( is_array( $submitted_high_school_value ) ) {
                foreach( $submitted_high_school_value as $high_school_value_key => $high_school_value ) {
                    if ( 'frm' === $high_school_value_key ) {
                        if ( ! $this->is_date( $high_school_value ) ) {
                            unset( $submitted_high_school_value[ $high_school_value_key ] );
                        }
                    } elseif ( 'to' === $high_school_value_key ) {
                        if ( ! isset( $submitted_high_school_value['frm'] ) || ! $this->is_date( $high_school_value ) ) {
                            unset( $submitted_high_school_value[ $high_school_value_key ] );
                        }
                    } elseif ( isset( $submitted_high_school_array_default_args[ $high_school_value_key ] ) ) {
                        if ( $description_key === $high_school_value_key ) {
                            $high_school_value = $this->trunc( $high_school_value, __( 'High school description', 'describr' ) );
                        }

                        $high_school_value = $this->sanitize_txt( $high_school_value );

                        if ( '' === $high_school_value ) {
                            if ( $name === $high_school_value_key ) {
                                unset( $submitted_high_school_array[ $submitted_high_school_key ] ); 
                                break; 
                            }
                        } else {
                            $submitted_high_school_value[ $high_school_value_key ] = $high_school_value;

                            if ( $name === $high_school_value_key ) {
                                $lowercased_high_school_name = strtolower( $high_school_value );
                                    
                                if ( in_array( $lowercased_high_school_name, $duplicate_high_school_names_array ) ) {
                                    unset( $submitted_high_school_array[ $submitted_high_school_key ] ); 
                                    $high_school_errors_array[] = $high_school_value;
                                    break;
                                } else {
                                    $duplicate_high_school_names_array[] = $lowercased_high_school_name;
                                } 
                            }
                        }
                    } else {
                        unset( $submitted_high_school_value[ $high_school_value_key ] );
                    }
                }//foreach
            }//if ( is_array( $submitted_high_school_value ) )
        }//foreach
        
        $submitted_high_school_array_no_controls = $submitted_high_school_array;

        if ( isset( $submitted_high_school_array_no_controls[ $privacy_key ] ) ) {
            unset( $submitted_high_school_array_no_controls[ $privacy_key ] );
        }

        if ( isset( $submitted_high_school_array_no_controls[ $approval_key ] ) ) {
            unset( $submitted_high_school_array_no_controls[ $approval_key ] );
        }
        
        $this->update_profile_section( array_values( $submitted_high_school_array_no_controls ), $school_key, $profile_section, $change, $submitted_high_school_array );
        
        $this->commit_changes_made_to_profile_section( $previously_saved_userdata, $updated_userdata, $profile_section, $high_school_key, $school_key, $change );

        if ( $high_school_errors_array ) {
            $high_school_errors_array = $this->unique_array_values( $high_school_errors_array );

            if ( 1 === count( $high_school_errors_array ) ) {
                $error_message = sprintf(
                    /*translators: %s: high school's name*/
                    __( 'You have a high school that is included more than once: %s.', 'describr' ),
                    $high_school_errors_array[0]
                );
            } else {
                $error_message = sprintf(
                    /*translators: %s: Multiple high schools' names*/
                    __( 'You have several high schools that are included more than once: %s.', 'describr' ),
                    implode( ', ', $high_school_errors_array )
                );
            }

            $this->profile_update_errors[ $high_school_key . $errors_key ] = $error_message;
        }
    }//high schools
}//if ( isset( $post[ $plugin ] ) )

//Do updates exist?
if ( $updated_userdata ) {
    self::update_user_meta( $user_id, $previously_saved_userdata, $updated_userdata );
}

require_once ( dirname( __FILE__ ) . '/upload-avatar.php' );
