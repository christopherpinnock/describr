=== Describr ===
Contributors: profiletoggler
Donate link: https://www.paypal.com/donate/?hosted_button_id=MEB7PGVTDJG7Q
Tags: profile, user profile, users, bio, avatar, gravatar, profile photos, upload photos, describr
Requires at least: 4.7
Tested up to: 6.4.3
Requires PHP: 7.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Adds personal information and photo upload fields to user profiles.

== Description ==

Adds more personal information fields to user profiles than those provided by WordPress. Avatar field gives users the ability to upload a profile photo and create photos of different sizes.

= Special Features =

1. Fields added to users profiles: Profile photo, Tagline, First and Last name, Gender, Birthdate, Bio, Addresses (currenty city, hometown, and cities lived), Relationship status, Languages, Contacts (phone number and email address), Time zone, Social networks, Websites, Work history, and Education (Colleges and High schools).
2. User profile fields data are shown without the ability to be edited if either the current user does not have permission to edit user profiles or the user is logged out.
3. View information about users from the users screen: login status, most recent login date, user profiles published status.
4. Change publish status from either the users screen or the user profiles.
5. Users can set privacy status on individual fields.
6. Users with editor capability can approve/unapprove individual fields as well as override users settings.

= Localization =

* English (US) - default
* .pot file (`describr.pot`) for translators

= Permissions: Filters and the Features They Can Override =

1. **describr_files_upload_limit:** maximum file size for photo upload.
2. **describr_can_upload_files:** users who can upload profile photos (Default is only those with upload_files capability can upload photos).
3. **describr_avatars_dynamic_resize:** create photos of different sizes.
4. **describr_avatar_change_alt:** HTML img tag alt attribute value.
5. **describr_avatar:** display a different avatar from the one created by Describr.
6. **describr_can_edit_profiles:** users who have edit_others_post capability.
7. **describr_enqueue_scripts:** on what screens the plugin's scripts can be loaded (Defaults are profile.php, user-edit.php, users.php).
8. **describr_maxlen_tagline:** the maximum number of characters in tagline saved in the database, with the default being 20.
9. **describr_maxlen_textbox:** the maximum number of characters saved in the database when sent from an HTML input element of type text box, with the default being 150.
10. **describr_maxlen_textarea_LG:** the maximum number of characters saved in the database when sent from a large HTML textarea element, with the default being 1000.
11. **describr_maxlen_textarea_SM:** the maximum number of characters saved in the database when sent from a small HTML textarea element, with the default being 300.
12. **describr_maxlen_phonenumber:** the maximum number of characters in phone numbers saved in the database, with the default being 50.
13. **describr_maxlen_url:** the maximum number of characters in urls saved in the database, with the default being 100.
14. **describr_maxlen_arraysize:** the maximum number of arrays saved in the database when the individual values are of type array, with the default being 100.
15. **describr_valid_phonenumber_characters:** regular expression that checks for disallowed phone number characters, with the default being `/[^0-9a-zA-Z\.\(\)\s_-]+/`.

= Links to Non-compressed Source Code of JavaScript and CSS Files =

1. [jquery-ui](https://github.com/jquery/jquery-ui)
2. [Freak Flags](http://www.freakflagsprite.com)
3. [Describr-CSS and JavaScript](https://github.com/codei/describr)
4. [libphonenumber-js](https://github.com/catamphetamine/libphonenumber-js)
5. [DOMPurify](https://github.com/cure53/DOMPurify)

= More =

* User profile fields can be loaded on any screen by both adding the screen name to the **describr_enqueue_scripts** filter and instantiating the describrUserProfile.init(CSSClassOrID) JavaScript object.

**Note:** JavaScript is required to display the user profile fields and their data.
 
= Plugin Support =

Like This Plugin? You can show your support by:

* [Rating the plugin](https://wordpress.org/support/plugin/describr/reviews/?filter=5#new-post) or [Donating to the developer](https://www.paypal.com/donate/?hosted_button_id=MEB7PGVTDJG7Q).

== Installation ==

1. Upload the entire `describr` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin by way of the 'Plugins' menu in WordPress.
3. Go to your user profile to see the new profile fields.
4. Go to Settings>Discussion>Avatars>Describr Avatar to set the default avatar.

== Translations ==

* English (US) - default

*Note:* Describr is translateable by default. You are welcome to contribute your language to the plugin.