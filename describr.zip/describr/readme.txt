=== Describr ===
Contributors: Chris
Tags: profile, user profile, social network, avatar, profile photo, profile picture, bio, user account
Requires at least: 4.7
Tested up to: 6.4
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Describr extends the features of WordPress' default profile page by giving users the ability to add more personal information than that provided by WordPress.

== Description ==

Describr extends the features of WordPress' default profile page by giving users the ability to add more personal information than that provided by WordPress. Also, the **Avatar** feature provides the ability to upload a profile photo, delete photo, and set a default photo if no photo has been uploaded.

### Plugin Features:
* **All users:** Post a profile photo, Tagline, First and Last name, Gender, Birthdate, Bio, Addresses (currenty city, hometown, and cities lived), Relationship status, Languages, Contacts (phone number and email address), Timezone, Social networks handles, Websites, Work history, and Education (Colleges and High schools), as well as set privacy status for each section.
* **Role Editor:** Allows you to take full control over profiles as well as publish/unpublish each section of a profile, publish/unpublish an entire profile, view published/unpublished status of users' profiles, view users who are logged in, view most recent log-in dates and times of users, and set WordPress default Avatar as the Avatar to use if users have not uploaded their own Avatars.
* **Language:** Spanish and Japanese, as well as the ability to be translated into other languages.

###Avatar:
* To upload a profile photo, the user must be assigned the `upload_files` capability.

### Like This Plugin?
The Describr plugin took over a year to develop and involves over 10,000 lines of code. However, we do not make any money from this plugin, but you can show your support by:

* [Rating the plugin](https://wordpress.org/support/plugin/describr/reviews/?filter=5#new-post) or [Donating to the developer](https://www.paypal.com/donate/?hosted_button_id=MEB7PGVTDJG7Q).

== Installation ==
Upload the Describr plugin to your blog, activate it, and you are done:
1. Upload `Describr` to the `/wp-content/plugins/` directory.
2. Activate the plugin by way of the 'Plugins' menu in WordPress.
3. Go to "Settings > Discussion > Avatars >  Describr Avatar" to set the default avatar.