<?php
/*
 * Plugin Name: Describr
 * Description: A plugin that extends the features of WordPress' default profile page by giving users the ability to add more personal information than that provided by WordPress. Also, the <strong>Avatar</strong> feature provides the ability to upload a profile photo, delete photo, and set a default photo if no photo has been uploaded.
 * Version: 1.0.0
 * Requires at least: 4.7
 * Requires PHP: 7.0
 * Author: Describr
 * Author URI: https://facebook.com/plzr
 * Text Domain: describr
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) or die( __( 'You are not authorized to access this file.', 'describr' ) );

register_activation_hook( __FILE__, array( 'Describr', 'plugin_activation' ) );
register_uninstall_hook( __FILE__, array( 'Describr', 'plugin_deactivation' ) );

//Include main class file
require_once ( plugin_dir_path( __FILE__ ) . '/class.describr.php' );

if ( class_exists( 'Describr' ) ) {
	new Describr();
}
