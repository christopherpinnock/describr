<?php
/**
 * Plugin Name: Describr
 * Description: Adds personal information and photo upload fields to user profiles.
 * Version: 1.0.0
 * Requires at least: 4.7
 * Requires PHP: 7.0
 * Author: profiletoggler
 * Author URI: https://facebook.com/plzr
 * Text Domain: describr
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) or die( esc_html__( 'You are not authorized to access this file.', 'describr' ) );

define( 'DESCRIBR_VERSION', '1.0.0' );

register_activation_hook( __FILE__, array( 'Describr', 'plugin_activation' ) );
register_uninstall_hook( __FILE__, array( 'Describr', 'plugin_deactivation' ) );

require_once plugin_dir_path( __FILE__ ) . 'translations-describr.php';
require_once plugin_dir_path( __FILE__ ) . 'class.describr.php';

new DESCRIBR;
